#!/usr/bin/env bash
# 整片恢复（0x0 的 factory 镜像）。
# ⚠️ 会覆盖 NVS：Wi-Fi 凭据、Mac 地址都会丢，刷完要重新配网。
set -euo pipefail
PORT="${1:-/dev/cu.usbmodem1101}"
DIR="$(cd "$(dirname "$0")" && pwd)"
python3 -m esptool --chip esp32s3 -p "$PORT" write-flash 0x0 "$DIR/firmware/firmware.factory.bin"
