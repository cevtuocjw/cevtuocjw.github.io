/* 自动生成，不要手改。
 * 改清单：device/assets/pet/manifest.json
 * 重新生成：/opt/homebrew/bin/python3 device/tools/make-pet-frames.py
 *
 * ⚠️ 每帧都是**已经合成到背景色 (#0B0D10) 上**的实心图，没有 alpha。
 *    所以画的时候不能让别的图形压在它下面 —— 那会被这块方形区域盖掉。
 *    设计里圆屏正中 Ø140 是它的位置，径向环在 r168~188，两者不重叠。
 */
#pragma once
#include <stdint.h>

typedef struct { const char* id; const char* nm; uint16_t w, h, frames; uint32_t bytes; } PetClip;


static const PetClip PET_CLIP_MUSHROOM = { "mushroom", "Mushroom", 64, 64, 24, 196608 };

static const PetClip PET_CLIPS[] = {
  PET_CLIP_MUSHROOM
};
#define PET_CLIP_COUNT 1
