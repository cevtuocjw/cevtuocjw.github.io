#!/opt/homebrew/bin/python3
"""把屏幕录制的 flush 钩子接进 hal_display.cpp（幂等）。"""
import pathlib, sys
up = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else
                  pathlib.Path.home() / "Documents/Cevtuo-X-D/device/upstream/M5StopWatch-UserDemo")
p = up / "main/hal/hal_display.cpp"
s = p.read_text()
if "grooved_capture_push" in s:
    print("  = hal_display.cpp 已有录制钩子")
    sys.exit(0)
if '#include "utils/settings/settings.h"' not in s:
    sys.exit("✗ hal_display.cpp 的 include 锚点变了")
s = s.replace('#include "utils/settings/settings.h"',
              '#include "utils/settings/settings.h"\n#include <apps/grooved_capture.h>', 1)
old = "    gfx.endWrite();\n\n    lv_display_flush_ready(disp);"
new = "    gfx.endWrite();\n\n    grooved_capture_push(area->x1, area->y1, w, h, px_map);\n\n    lv_display_flush_ready(disp);"
if old not in s:
    sys.exit("✗ hal_display.cpp 的 flush 锚点变了")
s = s.replace(old, new, 1)
p.write_text(s)
print("  + hal_display.cpp 挂上录制钩子")
