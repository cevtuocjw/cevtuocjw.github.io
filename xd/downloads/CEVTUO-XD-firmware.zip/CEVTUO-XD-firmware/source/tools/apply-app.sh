#!/usr/bin/env bash
# 把我们的 app + 宠物素材接进上游固件树，然后（可选）构建。
#
#   bash device/tools/apply-app.sh            # 只接，不构建
#   bash device/tools/apply-app.sh --build    # 接完再 pio run
#
# ⚠️ 为什么要有这一层：`device/upstream/` 是一个 clone（自带 .git），
#    在里面手改的东西一次 re-clone 就没了。我们的源码住在 device/app/，
#    这个脚本负责**幂等地**把它接进去 —— 跑一百遍结果一样。
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
UP="${XD_UPSTREAM:-$ROOT/device/upstream/M5StopWatch-UserDemo}"

[ -d "$UP/main/apps" ] || { echo "✗ 找不到上游固件树：$UP"; exit 1; }

APP_SRC="$ROOT/device/app/app_grooved"
ASSETS="$ROOT/device/assets/pet"
[ -d "$APP_SRC" ] || { echo "✗ 找不到 $APP_SRC"; exit 1; }
[ -f "$ASSETS/pet_frames.h" ] || {
  echo "✗ 还没有 pet_frames.h —— 先跑：/opt/homebrew/bin/python3 device/tools/make-pet-frames.py"; exit 1; }

# ① 所有 app 源码（device/app/app_*/ → main/apps/app_*/）
for d in "$ROOT"/device/app/app_*; do
  [ -d "$d" ] || continue
  n="$(basename "$d")"
  rm -rf "$UP/main/apps/$n"
  mkdir -p "$UP/main/apps/$n"
  cp "$d"/* "$UP/main/apps/$n/"
  echo "  + $n"
done

# ①b 双系统分区表（ota_0 = Watch，ota_1 = Muse）。
#     ⚠️ 前四行和原厂表一致（nvs/otadata/phy 的偏移不变）⇒ 换表**不会动到闹钟/设置**。
if [ -f "$ROOT/device/partitions_dual.csv" ]; then
  if [ ! -f "$UP/partitions.single.csv.bak" ]; then
    cp "$UP/partitions.csv" "$UP/partitions.single.csv.bak"
    echo "  + 备份原分区表 → partitions.single.csv.bak"
  fi
  cp "$ROOT/device/partitions_dual.csv" "$UP/partitions.csv"
  echo "  + 分区表换成双系统（ota_0 4.5MB / ota_1 4MB）"
fi

# ①c 共享资源（线稿 logo + 应用图标）
cp "$ROOT/device/app/logos/grooved_logos.h" "$UP/main/apps/grooved_logos.h"
cp "$ROOT/device/app/icons/grooved_icons.h" "$UP/main/apps/grooved_icons.h"
cp "$ROOT/device/app/icons/grooved_icons.c" "$UP/main/apps/grooved_icons.c"
# 屏幕录制（给分发页做 GIF）
cp "$ROOT/device/app/shared/grooved_capture.h" "$UP/main/apps/grooved_capture.h"
cp "$ROOT/device/app/shared/grooved_capture.cpp" "$UP/main/apps/grooved_capture.cpp"

# ② 宠物素材（头文件 + 所有已生成的 rgb565）
mkdir -p "$UP/main/assets/pet"
cp "$ASSETS/pet_frames.h" "$UP/main/assets/pet/"
cp "$ASSETS"/pet-*.rgb565 "$UP/main/assets/pet/"

# ③ 注册（apps.h 一行 / main.cpp 一行 / CMake 的 EMBED_FILES）—— 全部幂等
/opt/homebrew/bin/python3 - "$UP" "$ASSETS/built.json" <<'PY'
import json, pathlib, sys

up = pathlib.Path(sys.argv[1])
built = json.loads(pathlib.Path(sys.argv[2]).read_text())

# apps.h：每个 device/app/app_* 一行 include
p = up / "main/apps/apps.h"
s = p.read_text()
for d in sorted((up.parent.parent / "app").glob("app_*")):
    if not d.is_dir():
        continue
    n = d.name
    line = f'#include "{n}/{n}.h"'
    if line not in s:
        s = s.rstrip() + "\n" + line + "\n"
        print(f"  + apps.h 注册 {n}")
p.write_text(s)

# main.cpp
p = up / "main/main.cpp"
s = p.read_text()
anchor = "GetMooncake().installApp(std::make_unique<AppSetup>());"
if anchor not in s:
    raise SystemExit("✗ main.cpp 里找不到 AppSetup 那行，注册锚点变了 —— 先看文件，别猜")
for d in sorted((up.parent.parent / "app").glob("app_*")):
    if not d.is_dir():
        continue
    n = d.name
    cls = "App" + "".join(part.capitalize() for part in n[4:].split("_"))
    line = f"    GetMooncake().installApp(std::make_unique<{cls}>());"
    if cls not in s:
        s = s.replace(anchor, anchor + "\n" + line, 1)
        print(f"  + main.cpp 安装 {cls}")
p.write_text(s)

# ⚠️⚠️ 启动最前面：把 M5IOE1 的电源轨恢复成上电默认。
#    Muse 休息时会关掉 OLED/音频的 L3B 轨（IO8/IO3）并把 LCD/TP reset 拉低，
#    而原厂 HAL 默认"上电就是开的"，不会重新打开 ⇒ **屏幕一直黑**（2026-10-19 实测）。
#    必须在 GetHAL().init() 之前写，否则显示初始化时面板还没电。
if "grooved_restore_ioe_rails" not in s:
    if '#include <apps/apps.h>' not in s:
        raise SystemExit("✗ main.cpp 找不到 apps.h include")
    s = s.replace("#include <apps/apps.h>",
                  "#include <apps/apps.h>\n#include <driver/i2c_master.h>\n#include <driver/gpio.h>", 1)
    fn = """
/* GrooveD：把 M5IOE1（0x4F）的输出恢复成上电默认。
 * 位定义（和 Muse 的 board_m5stack_stopwatch.c 对齐）：
 *   IO3=AU_L3B(音频) IO4=TP_RST IO5=LCD_RST IO8=3V3_L3B(OLED) IO9=马达 IO10=功放
 * 目标：3/4/5/8/10 高，9 低。两个 16 位寄存器按小端写。
 */
static void grooved_restore_ioe_rails()
{
    i2c_master_bus_config_t bus = {};
    bus.i2c_port = I2C_NUM_0;
    bus.sda_io_num = GPIO_NUM_47;
    bus.scl_io_num = GPIO_NUM_48;
    bus.clk_source = I2C_CLK_SRC_DEFAULT;
    bus.glitch_ignore_cnt = 7;
    bus.flags.enable_internal_pullup = true;
    i2c_master_bus_handle_t h = nullptr;
    if (i2c_new_master_bus(&bus, &h) != ESP_OK) return;

    i2c_device_config_t dev = {};
    dev.dev_addr_length = I2C_ADDR_BIT_LEN_7;
    dev.device_address = 0x4F;
    dev.scl_speed_hz = 100000;
    i2c_master_dev_handle_t d = nullptr;
    if (i2c_master_bus_add_device(h, &dev, &d) == ESP_OK) {
        // 0x03 MODE = 0x039C（六个脚都设为输出）；0x05 OUT = 0x029C（马达低，其余高）
        uint8_t mode[3] = { 0x03, 0x9C, 0x03 };
        uint8_t out[3]  = { 0x05, 0x9C, 0x02 };
        i2c_master_transmit(d, mode, sizeof(mode), 50);
        i2c_master_transmit(d, out, sizeof(out), 50);
        i2c_master_bus_rm_device(d);
    }
    i2c_del_master_bus(h);
}

"""
    s = s.replace('extern "C" void app_main(void)', fn + 'extern "C" void app_main(void)', 1)
    s = s.replace("    // HAL init\n    GetHAL().init();",
                  "    // GrooveD: 先把 Muse 关掉的电源轨恢复，再初始化 HAL（否则黑屏）\n"
                  "    grooved_restore_ioe_rails();\n\n    // HAL init\n    GetHAL().init();", 1)
    p.write_text(s)
    print("  + main.cpp 启动前恢复 IOE 电源轨")
else:
    print("  = main.cpp 已有电源轨恢复")

# ⚠️ 启动时确认"本次启动成功"。不写这句，从 Muse 切回来后引导器会认为
#    Watch 没通过验证，几次重启又自动滚回 Muse（实测发生过一次）。
if "esp_ota_mark_app_valid_cancel_rollback" not in s:
    if "#include <apps/apps.h>" not in s or "GetHAL().init();" not in s:
        raise SystemExit("✗ main.cpp 的锚点变了 —— 先看文件，别猜")
    s = s.replace("#include <apps/apps.h>",
                  "#include <apps/apps.h>\n#include <esp_ota_ops.h>", 1)
    s = s.replace("GetHAL().init();",
                  "GetHAL().init();\n\n    // 双系统：确认本次启动成功，禁止回滚到另一个系统\n"
                  "    esp_ota_mark_app_valid_cancel_rollback();", 1)
    p.write_text(s)
    print("  + main.cpp 启动确认（禁止回滚）")
else:
    print("  = main.cpp 已有启动确认")

# CMakeLists：EMBED_FILES 里补上每只宠物的 .rgb565
p = up / "main/CMakeLists.txt"
s = p.read_text()
want = [f'"assets/pet/{b["file"]}"' for b in built["pets"]]
missing = [w for w in want if w not in s]
if missing:
    anchor = '"assets/sfx/boot_sfx.bin"'
    if anchor not in s:
        raise SystemExit("✗ CMakeLists 里找不到 EMBED_FILES 锚点 boot_sfx.bin")
    s = s.replace(anchor, anchor + "\n        " + "\n        ".join(missing), 1)
    p.write_text(s)
    print(f"  + EMBED_FILES：{len(missing)} 个")
else:
    print("  = EMBED_FILES 已齐")
PY

/opt/homebrew/bin/python3 "$ROOT/device/tools/patch-capture-hook.py" "$UP"

echo "✓ 接好了：$UP"

if [ "${1:-}" = "--build" ]; then
  echo "→ pio run -e m5stack-stopwatch"
  cd "$UP"
  pio run -e m5stack-stopwatch
fi
