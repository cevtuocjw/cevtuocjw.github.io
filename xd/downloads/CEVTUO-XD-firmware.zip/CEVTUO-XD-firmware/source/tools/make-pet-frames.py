#!/opt/homebrew/bin/python3
"""
设备端宠物素材的**唯一入口** —— 从清单生成，不是从代码里写死的一份名单。

用法：
    make-pet-frames.py                 # 按 manifest.json 重新生成全部
    make-pet-frames.py --list          # 看看现在有哪几只、多大
    make-pet-frames.py --add <id> --name <中文名> --src <来源> [--frames 32] [--max 140]
    make-pet-frames.py --remove <id>
    make-pet-frames.py --check         # 只做预算与自检，不写文件

── 来源怎么写（这是"从电脑或从手机加一只"的关键）──────────────
    pet-app:<文件名>      cevtuo-pet.app 里的素材，例如 mineral-silver-loop.mp4
    file:<路径>           本机任意文件（电脑上拖来的）
    model:<id>            3D 模型 ~/.c4emem/pets/<id>.glb（第一次会自动烘帧，缓存不丢）
    https://…            直接抓（手机上传后拿到的链接）

── 为什么是清单驱动 ──────────────────────────────────────────
读者 2026-10-16：「做好一个机制，**未来我能很容易的增加过去**，从电脑或者从手机，
这个根据以后我们分析 M5stack 的能力以及存储能力再说。」

⇒ 所以三件事必须分开：
  · **清单**（要哪几只）—— 数据，人手改，或者以后手机上一个按钮改
  · **生成器**（这份脚本）—— 把任意素材变成设备吃得下的格式
  · **预算**（app 分区多大）—— 一个数，超了就拒绝，**不靠人记得**

⚠️ 曾经这只脚本把三只矿物**写死在代码里**。那意味着"再加一只"要改 Python ——
而改代码这件事，正是"以后很容易增加"的反面。

── 两种模式：photo 与 pixel ────────────────────────────────────
    photo  原样缩到 ≤140，保留照片质感。**实测三只 = 2695KB**，而且白底浅色主体抠不干净
           （珍珠：主体 226 / 背景 242，**只差 16 级**，阈值法分不开）。
    pixel  缩到小画布（默认 64）+ 量化到有限色阶 + **硬边**。
           ⇒ 一个 64×64×24 帧的宠物只要 ~192KB，**五只不到 1MB**。
           ⇒ 而且"换一只"变成"换一个文件 + 一行清单"，这才是能长期用的机制。

   ⭐ 为什么默认走 pixel：圆屏正中 Ø140 放一张照片，在这个尺寸下
      **看不出是照片**，只看得出"糊"；而像素风是**故意的**，糊不了。

── 五个决定，以及为什么 ──────────────────────────────────────
1. **白底靠"离背景色多远"键出。** 实测矿物那三只背景是干净的 253/253/253
   （77.6% 的像素落在 ±2 内），而 T 从 6 取到 16 前景占比都在 20.9~21.1%
   —— 一个很宽的**平台**。阈值不敏感才敢写死。
   ⚠️ 但**珍珠那只不行**：白球 + 白底，颜色上分不开。脚本会量"键出来之后还剩多少"
   并且在看起来不对的时候**拒绝生成**（见 `check_separation`）。
2. **裁剪框取所有帧的并集。** 逐帧各自裁剪 = 逐帧各自居中/缩放 ⇒ 东西**自己抖**
   （缩放比例每帧差一点，看起来像在呼吸，其实是数据在动）。源里看不出来，放大就明显。
3. **合成到背景色上，不带 alpha。** 省一半 flash，而且圆屏上它永远落在那个平的底色上。
   代价写进头文件：**它就不能压在别的东西上面**了。
4. **RGB565 大端。** M5GFX 的 `pushImage` 吃这个。
5. **每只的尺寸按最长边 ≤140 缩**（设计文档 §3.1 的 Ø140）。宽高比保留。
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
ASSETS = HERE.parent / "assets" / "pet"
MANIFEST = ASSETS / "manifest.json"

# 设计文档 §2.1 定的全场底色。合成到它上面，设备端就不用处理 alpha。
BG = (0x0B, 0x0D, 0x10)
T_FG = 10            # 前景判据：与背景的最大通道差
T_SOFT_LO, T_SOFT_HI = 4, 24   # 羽化区间

PET_APP = Path("/Applications/cevtuo-pet.app/Contents/Resources/app/src/ui/assets")
# 3D 模型（GLB）烘出来的帧住这里。**不是 /tmp** —— /tmp 重启就没了，
# 而清单里写着一个 /tmp 路径的后果是「下次生成：来源找不到」，看起来像素材丢了。
BAKE_CACHE = HERE.parent / ".cache" / "pet-bake"
PET_MODELS = Path.home() / ".c4emem" / "pets"

DEFAULT_MANIFEST = {
    "budgetKB": 1600,
    "_note": "预算 = 这些素材一共允许占多少 KB。app 分区实测 5056KB，当前固件 537KB。"
             "超了脚本会拒绝生成 —— 不靠人记得。",
    "pets": [],
}


# ───────────────────────── 清单 ─────────────────────────

def load() -> dict:
    if MANIFEST.exists():
        return json.loads(MANIFEST.read_text())
    return json.loads(json.dumps(DEFAULT_MANIFEST))


def save(m: dict) -> None:
    ASSETS.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(m, ensure_ascii=False, indent=2) + "\n")


def resolve(src: str, count: int = 24) -> Path:
    """把清单里的来源写成一个本地路径。抓不到就抛，**不返回假路径**。"""
    if src.startswith("pet-app:"):
        p = PET_APP / src[len("pet-app:"):]
    elif src.startswith("file:"):
        p = Path(src[len("file:"):]).expanduser()
    elif src.startswith("seq:"):
        # 帧序列目录（`bake-pet.mjs` 烘出来的那些）—— 见下面的 load 分支
        p = Path(src[len("seq:"):]).expanduser()
    elif src.startswith("model:"):
        # 3D 模型（`~/.c4emem/pets/<id>.glb`）—— 缓存里没有就先烘一次。
        # ⚠️ 这才是"从电脑加一只"的完整路径：清单里只写**模型 id**，
        #    而不是一个烘好的目录路径（后者换个机器/重启就找不到）。
        mid = src[len("model:"):]
        glb = PET_MODELS / f"{mid}.glb"
        if not glb.exists():
            raise FileNotFoundError(f"模型找不到：{glb}（先在 cevtuo-pet 里导入，或用 file: 指到 .glb）")
        p = BAKE_CACHE / mid
        if not (p.is_dir() and any(p.glob("f-*.png"))):
            p.parent.mkdir(parents=True, exist_ok=True)
            print(f"    烘 {mid}（{count} 帧）…")
            env = dict(os.environ, XD_BAKE_OUT=str(BAKE_CACHE))
            r = subprocess.run(
                ["node", str(HERE / "bake-pet.mjs"), "--one", mid, "--n", str(count)],
                capture_output=True, text=True, env=env)
            if r.returncode != 0:
                raise RuntimeError(f"{mid}: 烘帧失败\n{r.stdout[-800:]}{r.stderr[-800:]}")
    elif src.startswith(("http://", "https://")):
        ASSETS.mkdir(parents=True, exist_ok=True)
        p = ASSETS / ("src-" + src.rsplit("/", 1)[-1].split("?")[0])
        if not p.exists():
            subprocess.run(["curl", "-fsSL", "--max-time", "120", "-o", str(p), src], check=True)
            print(f"    下载 → {p.name} ({p.stat().st_size // 1024}KB)")
    else:
        p = Path(src).expanduser()
    if not p.exists():
        raise FileNotFoundError(f"来源找不到：{src}  →  {p}")
    return p


# ───────────────────────── 抽帧 ─────────────────────────

def extract(video: Path, count: int, tmp: Path) -> list[np.ndarray]:
    """均匀取 count 帧。⚠️ 等间隔取，不是取前 count 帧（那只是整段的头 1/8）。"""
    tmp.mkdir(parents=True, exist_ok=True)
    for f in tmp.glob("*.png"):
        f.unlink()
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0", "-count_frames",
         "-show_entries", "stream=nb_read_frames", "-of", "csv=p=0", str(video)],
        capture_output=True, text=True, check=True)
    total = int(probe.stdout.strip())
    idx = [round(i * total / count) for i in range(count)]
    expr = "+".join(f"eq(n\\,{i})" for i in idx)
    # ⚠️ `-vsync 0` 在 ffmpeg 9 已删（现在叫 `-fps_mode passthrough`）。
    # 不写的话 select 出来的帧会被按帧率重排 ⇒ 输出帧序号和 select 下标**对不上**，
    # 而那是静默的偏移。
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(video),
                    "-vf", f"select='{expr}'", "-fps_mode", "passthrough",
                    "-frames:v", str(count), str(tmp / "f-%03d.png")], check=True)
    files = sorted(tmp.glob("f-*.png"))
    if len(files) != count:
        raise RuntimeError(f"抽出来 {len(files)} 帧，要的是 {count}")
    return [np.asarray(Image.open(p).convert("RGB"), dtype=np.int16) for p in files]


def check_separation(frames: list[np.ndarray], bg: np.ndarray, tag: str) -> None:
    """
    键背景这一步**可能是无声失效的** —— 白底上的白球就会。

    ⚠️ 症状：抠完还剩一大片（背景没掉）或者一片不剩（把主体也吃了），
    而两条都**不报错**。这里量出来，越界就拒绝生成。
    """
    cov = []
    for f in frames:
        d = np.abs(f - bg).max(axis=2)
        cov.append(float((d > T_FG).mean()))
    lo, hi = min(cov), max(cov)
    if lo < 0.02:
        raise RuntimeError(
            f"{tag}: 前景占比最低只有 {lo:.1%} —— 键背景把主体也吃掉了。"
            f"（白底 + 浅色主体时最常见，需要换成连通性抠图）")
    if hi > 0.92:
        raise RuntimeError(
            f"{tag}: 前景占比最高到 {hi:.1%} —— 背景基本没掉。"
            f"（多半是背景不是纯色，或者主体铺满了整幅）")
    # 抖动也要看一眼：全帧一样说明这是张静态图，不是循环动画。
    spread = float(np.mean([np.abs(frames[i] - frames[i + 1]).mean() for i in range(len(frames) - 1)]))
    if spread < 0.4:
        raise RuntimeError(f"{tag}: 相邻帧平均差只有 {spread:.2f} —— 这看起来是**静态图**，不是循环素材")


# ───────────────────────── 生成一只 ─────────────────────────

def build_pixel(frames: list[np.ndarray], bg: np.ndarray, pet: dict) -> tuple[bytearray, int, int, int]:
    """
    像素模式：小画布 + 量化 + 硬边。

    ⚠️ 三个细节都不是随手写的：
      · **缩放到小尺寸用 BOX（面积平均）而不是 NEAREST** —— 先用最近邻会
        随机丢像素，一张石头照片缩到 64 会变成雪花。面积平均再量化才干净。
      · **alpha 硬切到 0/1**，不羽化 —— 羽化出来的是"小尺寸照片"，
        硬边才是像素画。而且硬边顺带把白底那点没抠净的残留一起吃掉。
      · **调色板从这几帧里一起统计**（不是逐帧各自量化）—— 逐帧各自量化会让
        颜色在帧之间**跳**（同一块石头这一帧偏蓝下一帧偏黄），看着像在闪。
    """
    size = int(pet.get("size", 64))
    colors = int(pet.get("colors", 16))
    h0, w0 = frames[0].shape[:2]

    solid = np.zeros((h0, w0), dtype=bool)
    for f in frames:
        solid |= np.abs(f - bg).max(axis=2) > T_FG
    ys, xs = np.where(solid)
    if len(ys) == 0:
        raise RuntimeError("没有前景")
    y0, y1, x0, x1 = int(ys.min()), int(ys.max()) + 1, int(xs.min()), int(xs.max()) + 1
    ch, cw = y1 - y0, x1 - x0
    scale = size / max(ch, cw)
    th, tw = max(1, round(ch * scale)), max(1, round(cw * scale))

    # 先把每一帧做成 RGB + 硬 alpha，再一起统计调色板
    rgba = []
    for f in frames:
        d = np.abs(f - bg).max(axis=2)
        a = np.clip((d - T_SOFT_LO) / (T_SOFT_HI - T_SOFT_LO), 0.0, 1.0)
        crop = f[y0:y1, x0:x1].astype(np.float32)
        ac = a[y0:y1, x0:x1]
        # 先在原分辨率合成到背景色（羽化区才不会带进白边），再缩
        comp = crop * ac[..., None] + np.array(BG, dtype=np.float32) * (1 - ac[..., None])
        rgb = Image.fromarray(np.clip(comp, 0, 255).astype(np.uint8), "RGB").resize((tw, th), Image.BOX)
        harsh = Image.fromarray((ac * 255).astype(np.uint8), "L").resize((tw, th), Image.BOX)
        rgba.append((rgb, np.asarray(harsh) > 127))

    # 一起量化：把所有帧的**不透明**像素拼起来统计一张调色板
    opaques = []
    for rgb, m in rgba:
        arr = np.asarray(rgb)
        if m.any():
            opaques.append(arr[m])
    if not opaques:
        raise RuntimeError("全透明 —— alpha 阈值切没了")
    allpx = np.concatenate(opaques, axis=0)
    sample = Image.fromarray(allpx.reshape(-1, 1, 3).astype(np.uint8), "RGB")
    pal_img = sample.quantize(colors=colors, method=Image.MEDIANCUT).convert("RGB")
    # ⚠️⚠️ **去重**，不是 `reshape(-1, 3)`：后者是"每个像素一行"（这里 9 万多行），
    #       于是 `allpx[:, None, :] - palette[None]` 变成 98k×98k 的广播
    #       —— 实测吃到 46GB、卡在 array_sum 上，而且**不报错**，只是"跑不完"。
    #       量化图里真正的颜色最多 `colors` 个。
    palette = np.unique(np.asarray(pal_img).reshape(-1, 3), axis=0)
    if len(palette) < 2:
        raise RuntimeError(f"量化只剩 {len(palette)} 种颜色 —— 素材几乎是纯色，像素模式没有意义")
    # 每个不透明像素映射到最近的调色板项。⚠️ int32：255² = 65025 > int16 上限，会溢出。
    idx = np.argmin(((allpx[:, None, :].astype(np.int32) - palette[None].astype(np.int32)) ** 2).sum(-1), axis=1)
    palette = palette[np.unique(idx)]  # 丢掉没用上的（量化常常多给几档）

    buf = bytearray()
    for rgb, m in rgba:
        arr = np.asarray(rgb).reshape(-1, 3).astype(np.int32)
        d2 = ((arr[:, None, :] - palette[None].astype(np.int32)) ** 2).sum(-1)
        q = palette[np.argmin(d2, axis=1)].reshape(th, tw, 3).astype(np.uint16)
        q[~m] = np.array(BG, dtype=np.uint16)
        v = ((q[..., 0] >> 3) << 11) | ((q[..., 1] >> 2) << 5) | (q[..., 2] >> 3)
        buf += v.astype(">u2").tobytes()
    return buf, tw, th, len(palette)


def build_one(pet: dict, tmp: Path, write: bool = True) -> dict:
    tag = f"{pet['id']}({pet.get('nm', '')})"
    mode = pet.get("mode", "pixel")
    count = int(pet.get("frames") or (24 if mode == "pixel" else 32))
    src = resolve(pet["src"], count)
    maxpx = int(pet.get("max", 140))
    seq_dir = False
    print(f"  {tag:16s} ← {src.name}")

    if src.is_dir():
        # 帧序列：目录里按名字排序的 f-*.png。**帧数就是目录里的文件数** ——
        # 不在这里再抽一次（那等于对已经均匀采样过的序列又采一遍，会丢帧）。
        files = sorted(src.glob("f-*.png")) or sorted(src.glob("*.png"))
        if not files:
            raise RuntimeError(f"{tag}: 目录里没有 PNG：{src}")
        frames = [np.asarray(Image.open(f).convert("RGB"), dtype=np.int16) for f in files]
        count = len(frames)
        print(f"    帧序列 {count} 张 ← {src.name}/")
    elif src.suffix.lower() in (".mp4", ".mov", ".webm", ".webp", ".gif"):
        frames = extract(src, count, tmp)
    elif src.suffix.lower() in (".mp4", ".mov", ".webm", ".webp", ".gif"):
        raise RuntimeError("unreachable")
    else:
        # 静态图也支持 —— 它会被当成"32 帧全一样"，而脚本的自检会**拒绝**它。
        # 这是刻意的：设备上跑一个不动的东西 = 用户以为坏了。要静态就明说 `static: true`。
        im = np.asarray(Image.open(src).convert("RGB"), dtype=np.int16)
        if not pet.get("static"):
            raise RuntimeError(
                f"{tag}: 源是静态图（{src.suffix}）。设备上放一张不动的图，"
                f"用户会以为它坏了 —— 要么给视频/动图，要么在清单里显式写 \"static\": true。")
        frames = [im] * count

    h0, w0 = frames[0].shape[:2]
    bgs = [np.median(np.concatenate([f[0], f[-1], f[:, 0], f[:, -1]]), axis=0) for f in frames]
    bg = np.median(np.array(bgs), axis=0)
    check_separation(frames, bg, tag)

    solid = np.zeros((h0, w0), dtype=bool)
    for f in frames:
        solid |= np.abs(f - bg).max(axis=2) > T_FG
    ys, xs = np.where(solid)
    if len(ys) == 0:
        raise RuntimeError(f"{tag}: 一帧里都没找到前景")
    y0, y1, x0, x1 = int(ys.min()), int(ys.max()) + 1, int(xs.min()), int(xs.max()) + 1
    if y0 == 0 or x0 == 0 or y1 == h0 or x1 == w0:
        print(f"    ⚠️ 前景贴到了画面边缘 ({x0},{y0})-({x1},{y1}) —— 可能被裁掉了")

    mode = pet.get("mode", "pixel")
    if mode == "pixel":
        buf, tw, th, ncol = build_pixel(frames, bg, pet)
        out = ASSETS / f"pet-{pet['id']}.rgb565"
        if write:
            out.write_bytes(buf)
        print(f"    pixel {tw}×{th} ×{count} 帧  {len(buf)/1024:.0f}KB  {ncol} 色  （源裁 {x1-x0}×{y1-y0}）")
        return {"id": pet["id"], "nm": pet.get("nm", pet["id"]), "w": tw, "h": th,
                "frames": count, "bytes": len(buf), "file": out.name, "mode": "pixel", "colors": ncol}

    ch, cw = y1 - y0, x1 - x0
    scale = maxpx / max(ch, cw)
    th, tw = max(1, round(ch * scale)), max(1, round(cw * scale))

    buf = bytearray()
    for f in frames:
        d = np.abs(f - bg).max(axis=2)
        a = np.clip((d - T_SOFT_LO) / (T_SOFT_HI - T_SOFT_LO), 0.0, 1.0)
        crop_rgb = f[y0:y1, x0:x1].astype(np.float32)
        crop_a = a[y0:y1, x0:x1]
        comp = crop_rgb * crop_a[..., None] + np.array(BG, dtype=np.float32) * (1 - crop_a[..., None])
        img = Image.fromarray(np.clip(comp, 0, 255).astype(np.uint8), "RGB").resize((tw, th), Image.LANCZOS)
        arr = np.asarray(img, dtype=np.uint16)
        v = ((arr[..., 0] >> 3) << 11) | ((arr[..., 1] >> 2) << 5) | (arr[..., 2] >> 3)
        buf += v.astype(">u2").tobytes()

    expect = tw * th * 2 * count
    if len(buf) != expect:
        raise RuntimeError(f"{tag}: 数据长度 {len(buf)} != {expect}")

    # ⚠️ 「有 32 帧」这件事，32 份一模一样的拷贝也能满足。必须**它们真的不一样**。
    uniq = {hash(bytes(buf[i * tw * th * 2:(i + 1) * tw * th * 2])) for i in range(count)}
    if len(uniq) < max(2, count // 2):
        raise RuntimeError(f"{tag}: {count} 帧里只有 {len(uniq)} 种内容 —— 序列退化了")

    out = ASSETS / f"pet-{pet['id']}.rgb565"
    if write:
        out.write_bytes(buf)
    print(f"    photo {tw}×{th} ×{count} 帧  {len(buf)/1024:.0f}KB  （源裁 {cw}×{ch}）")
    return {"id": pet["id"], "nm": pet.get("nm", pet["id"]), "w": tw, "h": th,
            "frames": count, "bytes": len(buf), "file": out.name, "mode": "photo"}


# ───────────────────────── 头文件 ─────────────────────────

HEAD = """/* 自动生成，不要手改。
 * 改清单：device/assets/pet/manifest.json
 * 重新生成：/opt/homebrew/bin/python3 device/tools/make-pet-frames.py
 *
 * ⚠️ 每帧都是**已经合成到背景色 (#0B0D10) 上**的实心图，没有 alpha。
 *    所以画的时候不能让别的图形压在它下面 —— 那会被这块方形区域盖掉。
 *    设计里圆屏正中 Ø140 是它的位置，径向环在 r168~188，两者不重叠。
 */
#pragma once
#include <stdint.h>

typedef struct { const char* id; const char* nm; uint16_t w, h, frames; uint32_t bytes; } PetClip;

"""


def write_header(built: list[dict]) -> None:
    lines = [HEAD]
    for b in built:
        lines.append(f'static const PetClip PET_CLIP_{b["id"].upper()} = '
                     f'{{ "{b["id"]}", "{b["nm"]}", {b["w"]}, {b["h"]}, {b["frames"]}, {b["bytes"]} }};')
    lines.append("")
    lines.append("static const PetClip PET_CLIPS[] = {")
    lines.append("  " + ",\n  ".join(f'PET_CLIP_{b["id"].upper()}' for b in built))
    lines.append("};")
    lines.append(f"#define PET_CLIP_COUNT {len(built)}")
    lines.append("")
    (ASSETS / "pet_frames.h").write_text("\n".join(lines))
    (ASSETS / "built.json").write_text(json.dumps(
        {"pets": built, "totalKB": round(sum(b["bytes"] for b in built) / 1024)},
        ensure_ascii=False, indent=2) + "\n")


# ───────────────────────── main ─────────────────────────

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--add")
    ap.add_argument("--remove")
    ap.add_argument("--name", default="")
    ap.add_argument("--src", default="")
    ap.add_argument("--frames", type=int, default=0, help="0 = 用模式默认（pixel 24 / photo 32）")
    ap.add_argument("--max", type=int, default=140)
    ap.add_argument("--mode", default="pixel", choices=["pixel", "photo"])
    ap.add_argument("--size", type=int, default=64, help="pixel 模式的小画布边长")
    ap.add_argument("--colors", type=int, default=16)
    ap.add_argument("--budget", type=int, default=0, help="改预算（KB）")
    a = ap.parse_args()

    m = load()
    if a.budget:
        m["budgetKB"] = a.budget
        save(m)
        print(f"预算改为 {a.budget}KB")

    if a.remove:
        before = len(m["pets"])
        m["pets"] = [p for p in m["pets"] if p["id"] != a.remove]
        if len(m["pets"]) == before:
            print(f"清单里没有 {a.remove}；现有：" + ", ".join(p["id"] for p in m["pets"]))
            return 1
        save(m)
        old = ASSETS / f"pet-{a.remove}.rgb565"
        if old.exists():
            old.unlink()
        print(f"✓ 移除了 {a.remove}（生成物也删了）")

    if a.add:
        if not a.src:
            print("--add 要配 --src（pet-app:xxx.mp4 / file:/path / model:<id> / https://…）")
            return 1
        if any(p["id"] == a.add for p in m["pets"]):
            print(f"{a.add} 已经在清单里了 —— 先 --remove 再来")
            return 1
        m["pets"].append({"id": a.add, "nm": a.name or a.add, "src": a.src,
                          "mode": a.mode,
                          "frames": a.frames or (24 if a.mode == "pixel" else 32),
                          "size": a.size, "colors": a.colors, "max": a.max})
        save(m)
        print(f"✓ 加了 {a.add}（{a.name or a.add}）")

    if a.list:
        if not m["pets"]:
            print("清单是空的。用 --add 加一只。")
            return 0
        built = {}
        bj = ASSETS / "built.json"
        if bj.exists():
            built = {b["id"]: b for b in json.loads(bj.read_text())["pets"]}
        print(f"预算 {m['budgetKB']}KB")
        for p in m["pets"]:
            b = built.get(p["id"])
            size = f"{b['bytes']/1024:6.0f}KB  {b['w']}×{b['h']}×{b['frames']}" if b else "   ——  还没生成"
            print(f"  {p['id']:10s} {p.get('nm',''):8s} {size}   ← {p['src']}")
        return 0

    if not m["pets"]:
        print("清单是空的 —— 先 --add 一只，再跑生成。")
        return 0

    tmp = Path("/tmp/xd-petframes")
    print(f"生成 {len(m['pets'])} 只（预算 {m['budgetKB']}KB）")
    built, failed = [], []
    for p in m["pets"]:
        try:
            built.append(build_one(p, tmp, write=not a.check))
        except Exception as e:
            failed.append(p["id"])
            print(f"    ✗ {e}")

    if failed:
        # ⚠️ **一只失败就整体失败。** 生成一半的产物烧进板子，症状是
        # "板子上少了一只宠物"，而没人会知道是生成的时候漏的。
        print(f"\n✗ {len(failed)} 只没生成出来：{failed}。**没有写头文件** —— "
              f"半份产物比没有更糟。")
        return 1

    total = sum(b["bytes"] for b in built)
    budget = int(m["budgetKB"]) * 1024
    pct = 100 * total / budget
    print(f"\n合计 {total/1024:.0f}KB / 预算 {m['budgetKB']}KB（{pct:.0f}%）")
    if total > budget:
        print(f"✗ 超预算 {((total-budget)/1024):.0f}KB。"
              f"减帧数（--frames）或减尺寸（--max），或者 --budget 调大。")
        return 1
    if a.check:
        print("（--check：没有写任何文件）")
        return 0
    write_header(built)
    print(f"✓ 写了 {ASSETS}/pet_frames.h 和 built.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
