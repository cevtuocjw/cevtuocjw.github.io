#!/opt/homebrew/bin/python3
"""
给 Muse 固件加两件事（**幂等**，跑一百遍结果一样）：

1. **回原厂 Watch**：两只边键同时按住 3 秒 ⇒ 恢复电源域 + 切回 ota_0 + 重启。
2. **禁止回滚**：启动时 `esp_ota_mark_app_valid_cancel_rollback()`。
   不写这句，切槽后引导器会认为新系统"没通过验证"，几次重启后自动滚回另一个系统。
   （实测过一次：切回 Watch 后重启又进了 Muse。）

用法：
    python3 device/tools/patch-muse-return.py [muse-sdk 路径]
    默认：~/Documents/Codex/2026-10-14/new-chat/work/muse-sdk/esp32
"""
import pathlib
import sys

SDK = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else
                   pathlib.Path.home() / "Documents/Codex/2026-10-14/new-chat/work/muse-sdk/esp32")
BOARD = SDK / "components/muse/boards/board_m5stack_stopwatch.c"
MUSE_CMAKE = SDK / "components/muse/CMakeLists.txt"
MAIN = SDK / "main/main.c"

for p in (BOARD, MUSE_CMAKE, MAIN):
    if not p.exists():
        sys.exit(f"✗ 找不到 {p}")

# ── ① 依赖：board 文件 include 了 esp_ota_ops.h ⇒ muse 组件必须声明 app_update ──
c = MUSE_CMAKE.read_text()
if "app_update" not in c:
    anchor = "set(muse_priv_requires"
    if anchor not in c:
        sys.exit("✗ 找不到 muse_priv_requires —— 先看文件，别猜")
    MUSE_CMAKE.write_text(c.replace(anchor, anchor + "\n    app_update", 1))
    print("✓ 已给 muse 组件加 app_update 依赖")
else:
    print("= muse 组件已有 app_update")

# ── ② Muse 启动时确认本次启动成功（禁止回滚） ──
m = MAIN.read_text()
if "esp_ota_mark_app_valid_cancel_rollback" not in m:
    if '#include "app.h"' not in m or "void app_main(void) {" not in m:
        sys.exit("✗ main.c 的锚点变了 —— 先看文件，别猜")
    m = m.replace('#include "app.h"', '#include "app.h"\n#include "esp_ota_ops.h"', 1)
    m = m.replace(
        "void app_main(void) {",
        "void app_main(void) {\n"
        "    /* GROOVE_D_DUAL_BOOT: 告诉引导器本次启动成功，禁止回滚 */\n"
        "    esp_ota_mark_app_valid_cancel_rollback();", 1)
    MAIN.write_text(m)
    print("✓ 已给 Muse 加启动确认（禁止回滚）")
else:
    print("= Muse 已有启动确认")

# ── ③ board：两只边键按住 3 秒回 ota_0（含电源域恢复） ──
s = BOARD.read_text()
if "GROOVE_D_DUAL_BOOT" in s:
    print("= 回切补丁已经打过")
    sys.exit(0)

anchor_inc = '#include "esp_timer.h"'
if anchor_inc not in s:
    sys.exit("✗ 找不到 esp_timer.h 的 include 锚点 —— 先看文件，别猜")
s = s.replace(anchor_inc, anchor_inc + '\n#include "esp_ota_ops.h"   /* GROOVE_D_DUAL_BOOT */', 1)

old = """static unsigned poll_buttons(void)
{
    return muse_gpio_button_poll(&s_talk) |
           muse_gpio_button_poll(&s_speaker) << 13 | poll_power_button();
}"""
new = """static unsigned poll_buttons(void)
{
    unsigned ev = muse_gpio_button_poll(&s_talk) |
                  muse_gpio_button_poll(&s_speaker) << 13 | poll_power_button();

    /* GROOVE_D_DUAL_BOOT: 两只边键同时按住 3 秒 ⇒ 切回 ota_0（原厂 Watch）并重启。
     * ⚠️ 这是这台表"两个系统"的返回路。没有它，进了 Muse 就只能靠电脑切回来。
     * ⚠️ 只在**两只都按住**时计时，单按不触发；松开即清零。 */
    static int64_t s_dual_since = 0;
    if (s_talk.pressed && s_speaker.pressed) {
        int64_t now = esp_timer_get_time();
        if (s_dual_since == 0) {
            s_dual_since = now;
        } else if (now - s_dual_since > 3000000) {
            const esp_partition_t *p = esp_partition_find_first(
                ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_0, NULL);
            if (p != NULL && esp_ota_set_boot_partition(p) == ESP_OK) {
                /* ⚠️ 先把电源域恢复成原厂上电默认再重启：
                 * Muse 休息时关掉了 OLED/音频的 L3B 轨（IO8/IO3），而原厂 HAL 默认
                 * "上电就是开的"，不一定会重新打开它们。 */
                ioe_set(IOE_L3B | IOE_AUDIO | IOE_SPK, true);
                ioe_set(IOE_TP_RST | IOE_LCD_RST, true);
                ioe_set(IOE_MOTOR, false);
                vTaskDelay(pdMS_TO_TICKS(50));
                ESP_LOGI(TAG, "dual boot: back to watch (ota_0 @ 0x%lx)", (unsigned long)p->address);
                esp_restart();
            }
            s_dual_since = 0;
        }
    } else {
        s_dual_since = 0;
    }
    return ev;
}"""
if old not in s:
    sys.exit("✗ poll_buttons 的原文变了 —— 先看文件，别猜")
BOARD.write_text(s.replace(old, new, 1))
print(f"✓ 已打回切补丁：{BOARD}")
