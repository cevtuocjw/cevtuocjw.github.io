/**
 * 把 ~/.c4emem/pets/ 里的 3D 模型（GLB）烘成 PNG 帧序列，交给
 * `make-pet-frames.py` 转成设备格式。
 *
 * 用法：
 *   node device/tools/bake-pet.mjs --list
 *   node device/tools/bake-pet.mjs --all
 *   node device/tools/bake-pet.mjs --one mushroom-58lp
 *   node device/tools/bake-pet.mjs --all --n 24 --size 192
 *
 * 输出：/tmp/xd-bake/<id>/f-000.png …（每只一个目录）
 *
 * ── 为什么用 Playwright（这台机器上哪里来的）────────────────────────
 * Playwright **不在全局**，而在 `~/Documents/CEVTUO-Z/node_modules` 里
 * （CEVTUO-Z 的验证脚本在用）。所以这里直接从那个绝对路径 import ——
 * ⚠️ 不写死版本号，写死的话它一升级就 ENOENT，而"找不到模块"和
 * "页面没起来"报出来长得一样。
 *
 * ── 为什么需要本地 HTTP 服务器 ────────────────────────────────
 * GLB 用 `file://` 加载会被 CORS 拦；就算绕过去，**画布会被污染**，
 * 于是 `toDataURL` 抛 SecurityError。同源 HTTP 两个问题都没有。
 * （本机没有 PNG 解码器，所以只能走 data URL 这条路。）
 */
import { createServer } from "node:http";
import { readFile, writeFile, mkdir, readdir, rm } from "node:fs/promises";
import { existsSync } from "node:fs";
import { join, extname, basename } from "node:path";
import { homedir } from "node:os";

const PETS = join(homedir(), ".c4emem/pets");
const TOOLS = new URL(".", import.meta.url).pathname.replace(/\/$/, "");
/** ⚠️ 可以被 `XD_BAKE_OUT` 覆盖：`make-pet-frames.py` 要把它指到仓库里的缓存目录，
 *  这样"重新生成"不依赖 `/tmp`（重启就没了，而清单里写着那个路径会**静默失效**）。 */
const OUT_ROOT = process.env.XD_BAKE_OUT || "/tmp/xd-bake";

/** ⚠️ 路径写死在这里是有意的：它就是要能被一眼看见、被 grep 到、被改。
 *  写成"自动找"会让"找不到"变成一个静默的失败。 */
const PLAYWRIGHT_CANDIDATES = [
  join(homedir(), "Documents/CEVTUO-Z/node_modules/playwright/index.mjs"),
  join(homedir(), "node_modules/playwright/index.mjs"),
];

function findPlaywright() {
  for (const p of PLAYWRIGHT_CANDIDATES) if (existsSync(p)) return p;
  throw new Error(
    "找不到 playwright。找过：\n  " + PLAYWRIGHT_CANDIDATES.join("\n  ") +
    "\n（它是 CEVTUO-Z 的依赖，不是全局的。）");
}

const argv = process.argv.slice(2);
const flag = (n, d) => { const i = argv.indexOf(n); return i >= 0 ? argv[i + 1] : d; };
const has = (n) => argv.includes(n);

const N = Number(flag("--n", 24));
const SIZE = Number(flag("--size", 192));

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".glb": "model/gltf-binary",
  ".gltf": "model/gltf+json",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".wasm": "application/wasm",
};

const server = createServer(async (req, res) => {
  try {
    const u = new URL(req.url, "http://x");
    let p = decodeURIComponent(u.pathname);
    // 两个根：/glb/** → 宠物目录；其余 → tools（要放 vendor/）
    let file;
    if (p.startsWith("/glb/")) file = join(PETS, p.slice(5));
    else file = join(TOOLS, p === "/" ? "pet-bake.html" : p.slice(1));
    const buf = await readFile(file);
    res.writeHead(200, { "content-type": MIME[extname(file)] || "application/octet-stream" });
    res.end(buf);
  } catch (e) {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end("not found");
  }
});
await new Promise((r) => server.listen(0, "127.0.0.1", r));
const PORT = server.address().port;

const ids = (await readdir(PETS))
  .filter((f) => f.endsWith(".glb"))
  .map((f) => basename(f, ".glb"))
  .sort();

if (has("--list") || (!has("--all") && !flag("--one"))) {
  console.log(`${ids.length} 个模型（${PETS}）：`);
  for (const id of ids) {
    const thumb = join(PETS, `${id}.thumb.png`);
    console.log(`  ${id}${existsSync(thumb) ? "" : "   (没有缩略图)"}`);
  }
  if (!has("--list")) console.log("\n用 --all 或 --one <id> 来烘。");
  server.close();
  process.exit(0);
}

const want = flag("--one") ? [flag("--one")] : ids;
const { chromium } = await import(findPlaywright());
const browser = await chromium.launch({ args: ["--enable-unsafe-swiftshader", "--use-gl=angle", "--use-angle=swiftshader"] });

await mkdir(OUT_ROOT, { recursive: true });
// ⚠️ **只删这一只的目录**，不要 `rm -rf OUT_ROOT` —— 那样"烘第二只"会把
//    第一只的帧一起删掉，而清单里还记着它，下次生成报"来源找不到"。
//    （和"一个文件里两处各写一份"是同一族：看不见的连带破坏。）

const ok = [], bad = [];
for (const id of want) {
  const glb = join(PETS, `${id}.glb`);
  if (!existsSync(glb)) { bad.push([id, "没有 .glb"]); console.log(`✗ ${id}: 没有 .glb`); continue; }
  const page = await browser.newPage({ viewport: { width: SIZE, height: SIZE } });
  let errs = [];
  page.on("pageerror", (e) => errs.push(String(e.message)));
  await page.goto(`http://127.0.0.1:${PORT}/pet-bake.html?src=/glb/${encodeURIComponent(id)}.glb&n=${N}&size=${SIZE}`, { waitUntil: "load" });
  try {
    // ⚠️ 等**条件**，不等固定秒数：等固定秒数的话，"没等够"和"加载失败"
    // 在输出里长得一模一样。
    await page.waitForFunction(() => window.__bakeState === "ready" || window.__bakeState === "error", null, { timeout: 30000 });
  } catch {
    bad.push([id, "30 秒还没 ready"]); console.log(`✗ ${id}: 30 秒还没 ready`); await page.close(); continue;
  }
  const state = await page.evaluate(() => window.__bakeState);
  if (state === "error") {
    const msg = await page.evaluate(() => window.__bakeError);
    bad.push([id, msg]);
    console.log(`✗ ${id}: ${msg}`);
    // ⚠️ Draco / KTX2 / meshopt 压缩的模型在 r131 的这个 loader 下**加载不了**，
    // 而错误文本不会直说是压缩 —— 这里补一句人话。
    if (/draco|ktx|meshopt|unsupported|extension/i.test(msg)) {
      console.log(`     ↳ 多半是压缩过的 glTF（Draco/KTX2/meshopt）。vendored 的 r131 loader 没有那些 decoder。`);
    }
    await page.close(); continue;
  }
  // ⚠️ Playwright 的 `evaluate` **只收一个参数**（和 Puppeteer 不一样）——
  // 多传一个直接抛 "Too many arguments"。要传多个就打成对象。
  const frames = await page.evaluate(({ n, s }) => window.__bake(n, s), { n: N, s: SIZE });
  if (!frames || !frames.length) { bad.push([id, "__bake 返回空"]); console.log(`✗ ${id}: __bake 返回空`); await page.close(); continue; }
  const dir = join(OUT_ROOT, id);
  await rm(dir, { recursive: true, force: true });   // 只清这一只（旧的帧比新的多会残留）
  await mkdir(dir, { recursive: true });
  for (let i = 0; i < frames.length; i++) {
    await writeFile(join(dir, `f-${String(i).padStart(3, "0")}.png`),
      Buffer.from(frames[i].split(",")[1], "base64"));
  }
  // ⚠️ 还要验"它真的不是一个空图" —— 全透明也会"烘出 24 张"。
  const bytes = frames[0].length;
  ok.push([id, frames.length, bytes]);
  console.log(`✓ ${id}: ${frames.length} 帧 首帧 dataURL ${(bytes/1024).toFixed(1)}KB${errs.length ? "  ⚠️ 页面报错 " + errs[0].slice(0,60) : ""}`);
  await page.close();
}

await browser.close();
server.close();
console.log(`\n烘好 ${ok.length} 只，失败 ${bad.length} 只  →  ${OUT_ROOT}`);
if (bad.length) { console.log("失败："); for (const [id, why] of bad) console.log(`  ${id}: ${why}`); }
process.exit(bad.length ? 1 : 0);
