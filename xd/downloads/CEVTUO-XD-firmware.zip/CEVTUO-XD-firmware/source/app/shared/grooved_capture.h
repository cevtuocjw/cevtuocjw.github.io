/*
 * 手表屏幕录制（给分发页做 GIF）。
 *
 * 原理：LVGL 的 flush 回调把每一块 RGB565 像素拷进 466×466 的影子缓冲；
 * 一个后台任务每 250ms 把影子缓冲降采样成 233×233，走 USB Serial/JTAG
 * 发给 Mac。Mac 端 tools/grooved-capture.py 收帧、存 PNG、合成 GIF。
 *
 * 开关：Mac 往串口写 `CAP 1` / `CAP 0`（当前打开的 app 会调用
 * grooved_capture_line 解析；Groove/Muse 用 grooved_capture_poll_stdin）。
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif

void grooved_capture_push(int x, int y, int w, int h, const uint8_t* px);
void grooved_capture_line(const char* line);
void grooved_capture_poll_stdin(void);
bool grooved_capture_active(void);

#ifdef __cplusplus
}
#endif
