#include "grooved_capture.h"
#include <esp_heap_caps.h>
#include <driver/usb_serial_jtag.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <hal/hal.h>
#include <lvgl.h>
#include <cstdio>
#include <cstring>

// ⚠️ 实测 lv_screen_active() 是 468×466（不是 466×466）—— 整屏刷新的 flush
//    区域宽度也是 468。写成 466 时 x+w>CAP_W 会把「整屏那一刷」全部丢掉，
//    阴影里只剩几条窄的区域（症状：录出来一片黑，而推帧计数还在涨）。
#define CAP_W 468
#define CAP_H 466
#define OUT_W 466
#define OUT_H 466

static uint16_t* s_shadow = nullptr;
static volatile bool s_on = false;
// 影子缓冲只在 LVGL「重画到的区域」里更新；录制开始前屏幕上的东西
// 早就画完了 ⇒ 缓冲里是堆里的垃圾（第一次实测：一片彩色噪点）。
// 所以开录时清零 + 强制整屏重画一次。
static volatile bool s_want_full = false;
static volatile int s_pushes = 0;
static TaskHandle_t s_task = nullptr;
static char s_line[64];
static int s_len = 0;

static void send_all(const uint8_t* data, int n)
{
    int off = 0;
    while (off < n) {
        int chunk = n - off;
        if (chunk > 4096) chunk = 4096;
        int w = usb_serial_jtag_write_bytes(data + off, chunk, pdMS_TO_TICKS(200));
        if (w <= 0) break;
        off += w;
    }
}

static void capture_task(void*)
{
    uint8_t* frame = (uint8_t*)heap_caps_malloc(OUT_W * OUT_H * 2, MALLOC_CAP_SPIRAM);
    if (!frame) { vTaskDelete(nullptr); return; }
    for (;;) {
        if (s_on && s_shadow) {
            if (s_want_full) {
                s_want_full = false;
                bool lk = GetHAL().lvglLock();
                lv_obj_t* scr = lv_screen_active();
                std::printf("CAPDBG lock=%d scr=%p kids=%d w=%d h=%d pushes=%d\n",
                            (int)lk, (void*)scr, (int)lv_obj_get_child_count(scr),
                            (int)lv_obj_get_width(scr), (int)lv_obj_get_height(scr), s_pushes);
                std::fflush(stdout);
                if (lk) {
                    lv_obj_invalidate(scr);
                    GetHAL().lvglUnlock();
                }
                // 让 LVGL 把整屏画完再取样
                vTaskDelay(pdMS_TO_TICKS(150));
            }
            uint8_t hdr[8] = { 'C','A','P','1',
                               (uint8_t)(OUT_W & 0xff), (uint8_t)(OUT_W >> 8),
                               (uint8_t)(OUT_H & 0xff), (uint8_t)(OUT_H >> 8) };
            send_all(hdr, 8);
            int k = 0;
            for (int y = 0; y < OUT_H; y++) {
                // 1:1 取样：之前 2× 降采样把 8px 点阵字压成 4px，
                // 录出来的截图全是糊的（"COSPON D" 看起来像乱码）。
                const uint16_t* row = s_shadow + y * CAP_W;
                for (int x = 0; x < OUT_W; x++) {
                    uint16_t v = row[x];
                    frame[k++] = v & 0xff;
                    frame[k++] = v >> 8;
                }
            }
            send_all(frame, OUT_W * OUT_H * 2);
            const uint8_t endmagic[4] = { 'E','N','D','1' };
            send_all(endmagic, 4);
            static int frame_no = 0;
            if (++frame_no % 8 == 0) {
                std::printf("CAPDBG f=%d pushes=%d\n", frame_no, s_pushes);
                std::fflush(stdout);
            }
            vTaskDelay(pdMS_TO_TICKS(400));
        } else {
            vTaskDelay(pdMS_TO_TICKS(100));
        }
    }
}

void grooved_capture_push(int x, int y, int w, int h, const uint8_t* px)
{
    if (!s_on || !s_shadow || !px) return;
    s_pushes++;
    if (x < 0 || y < 0 || w <= 0 || h <= 0) return;
    if (x >= CAP_W || y >= CAP_H) return;
    if (x + w > CAP_W) w = CAP_W - x;
    if (y + h > CAP_H) h = CAP_H - y;
    const uint16_t* src = (const uint16_t*)px;
    for (int r = 0; r < h; r++) {
        memcpy(s_shadow + (y + r) * CAP_W + x, src + r * w, w * 2);
    }
}

void grooved_capture_line(const char* line)
{
    if (std::strncmp(line, "CAP ", 4) != 0) return;
    bool on = (line[4] == '1');
    if (on && !s_shadow) {
        s_shadow = (uint16_t*)heap_caps_malloc(CAP_W * CAP_H * 2, MALLOC_CAP_SPIRAM);
    }
    if (on && s_shadow) {
        std::memset(s_shadow, 0, CAP_W * CAP_H * 2);
        s_want_full = true;
    }
    s_on = on && s_shadow != nullptr;
    if (!s_task && s_shadow) {
        xTaskCreate(capture_task, "cap_task", 4096, nullptr, 1, &s_task);
    }
    std::printf("CAP %s\n", s_on ? "ON" : "OFF");
    std::fflush(stdout);
}

bool grooved_capture_active(void) { return s_on; }

void grooved_capture_poll_stdin(void)
{
    uint8_t b[32];
    int n = usb_serial_jtag_read_bytes(b, sizeof(b), 0);
    for (int i = 0; i < n; i++) {
        char c = (char)b[i];
        if (c == '\n' || c == '\r') {
            s_line[s_len] = 0;
            if (s_len > 0) grooved_capture_line(s_line);
            s_len = 0;
        } else if (s_len < (int)sizeof(s_line) - 1) {
            s_line[s_len++] = c;
        }
    }
}
