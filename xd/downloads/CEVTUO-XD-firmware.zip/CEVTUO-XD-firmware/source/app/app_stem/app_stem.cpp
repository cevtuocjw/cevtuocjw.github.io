/*
 * STEM-D v6 -- 四段 1/4 弧推子 + 可搓的黑胶 + 白色标签块。
 *
 * 读者 2026-10-19 晚（第二轮）：
 *   | 参考 YSL 的黑胶：**白色标签块贴在唱片上**；标签上显示 logo /
 *     正在播放的音乐；还要显示「音频有没有接进来」。
 *   | 摸黑胶时整张唱片跟着手指转（不是一个小点在动），可以来回搓。
 *   | 名字改成 STEM-D。
 *
 * 实现要点：
 *   | 白色标签是**独立的旋转对象**（132×92，中心 = 盘心）。唱片本身是圆形 +
 *     同心圆纹路，旋转看不出来；真正"转"的是标签。只旋转标签 = 视觉上整张
 *     唱片在转，但每次只重绘 132×92，不是整块 208×208。
 *   | Mac 桥每 2 秒写一行 `NP <title>|<artist>|<playing>`；Stem 非阻塞读 stdin。
 *   | `NO AUDIO` / `AUDIO IN` 是**如实显示手机媒体会话状态**，不是装饰。
 *
 * 交互（不变）：
 *   四段弧 = 四轨音量（拖）；长按静音；双击独奏
 *   黑胶   轻点播放/停止；按住拖 = 搓盘（整张标签跟着转）
 *   上 PLAY / 右 SCENE / 下 JOY / 左 TAP
 *   摇杆页 左 = TAPE 饱和/wow，右 = 搓盘/FX（中位 = 0）
 */
#include "app_stem.h"
#include "../grooved_icons.h"
#include "../grooved_capture.h"
#include "../grooved_logos.h"
#include <hal/hal.h>
#include <mooncake.h>
#include <mooncake_log.h>
#include <smooth_lvgl.hpp>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <cmath>
#include <string>
#include <esp_timer.h>
#include <unistd.h>
#include <fcntl.h>
#include <driver/usb_serial_jtag.h>
#include <driver/usb_serial_jtag_vfs.h>

using namespace mooncake;
using namespace smooth_ui_toolkit::lvgl_cpp;

/* ───────────────────────── 协议 ───────────────────────── */

static void midi(const char* fmt, ...)
{
    char buf[96];
    int n = std::snprintf(buf, sizeof(buf), "G1 ");
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(buf + n, sizeof(buf) - n, fmt, ap);
    va_end(ap);
    std::printf("%s\n", buf);
    std::fflush(stdout);
}
static void send_stem(int i, int v) { midi("STEM %d %d", i, v); }
static void send_mute(int i, bool on) { midi("MUTE %d %d", i, on ? 1 : 0); }
static void send_solo(int i, bool on) { midi("SOLO %d %d", i, on ? 1 : 0); }
static void send_platter(int v) { midi("PLATTER %d", v); }
static void send_tape(int drive, int wow) { midi("TAPE %d %d", drive, wow); }
static void send_fx(int v) { midi("FX %d", v); }
static void tap_feedback() { GetHAL().vibrate(10, 55); }

static int clamp_i(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static int64_t _tx_platter = 0, _tx_tape = 0, _tx_fx = 0, _tx_stem[4] = { 0, 0, 0, 0 };
static bool tx_gate(int64_t& last, int64_t interval_us)
{
    int64_t now = esp_timer_get_time();
    if (now - last < interval_us) return false;
    last = now;
    return true;
}

/* ───────────────────────── 布局 ───────────────────────── */

static const int CX = 233, CY = 233;
static const int PLATTER_R = 104;
static const int ARC_W = 8;
static const int ARC_SIZE = 400;
static const int BTN_R = 28;
static const uint32_t STEM_GREEN = 0x57E39B;

static const char* STEM_NAMES[4] = { "VOX", "DRM", "BAS", "OTH" };
static const int ARC_START[4] = { -86, -176, 94, 4 };
static const int ARC_END[4]   = { -4, -94, 176, 86 };
static const int QLAB[4][2] = { { 348, 119 }, { 118, 119 }, { 118, 347 }, { 348, 347 } };

enum FnBtn { FN_PLAY, FN_SCENE, FN_JOY, FN_TAP };
static const int BTN_POS[4][2] = { { 233, 73 }, { 393, 233 }, { 233, 393 }, { 73, 233 } };

// 白色标签块（中心 = 盘心）
static const int LAB_W = 132, LAB_H = 92;

/* ───────────────────────── 状态 ───────────────────────── */

static int _val[4] = { 100, 100, 100, 100 };
static bool _muted[4] = { false, false, false, false };
static bool _solo[4] = { false, false, false, false };
static int _scene = 0;
static int _bpm = 120;
static bool _playing = false;
static bool _joy_page = false;
static int64_t _last_clock_us = 0;
static int64_t _tap_us[4] = { 0, 0, 0, 0 };
static int _tap_count = 0;

/* 手机媒体 */
static char _np_title[64] = "";
static char _np_artist[64] = "";
static bool _np_playing = false;
static int64_t _np_seen_ms = 0;
static char _line[160];
static int _line_len = 0;

/* 触摸 */
enum Zone { Z_NONE, Z_ARC0, Z_ARC1, Z_ARC2, Z_ARC3, Z_PLATTER, Z_BTN_PLAY, Z_BTN_SCENE, Z_BTN_JOY, Z_BTN_TAP, Z_JOYL, Z_JOYR };
static Zone _zone = Z_NONE;
static int _last_arc = -1;
static bool _arc_dragged = false;
static bool _platter_moved = false;
static float _last_deg = 0;
static float _press_x = 0, _press_y = 0;
static int64_t _press_us = 0;
static int _platter_last = 0;
static float _vinyl_deg = 0;

/* ───────────────────────── 对象 ───────────────────────── */

static lv_obj_t* _owned[180];
static int _owned_n = 0;
static lv_obj_t* track(lv_obj_t* o)
{
    if (o && _owned_n < (int)(sizeof(_owned) / sizeof(_owned[0]))) _owned[_owned_n++] = o;
    return o;
}
static void destroy_all()
{
    for (int i = _owned_n - 1; i >= 0; i--) if (_owned[i]) lv_obj_del(_owned[i]);
    _owned_n = 0;
}

static lv_obj_t* _arc[4] = {};
static lv_obj_t* _name[4] = {};
static lv_obj_t* _num[4] = {};
static lv_obj_t* _btn[4] = {};
static lv_obj_t* _btn_lbl[4] = {};
static lv_obj_t* _platter = nullptr;
static lv_obj_t* _rings[3] = {};
static lv_obj_t* _vinyl_label = nullptr;
static lv_obj_t* _label_logo = nullptr;
static lv_obj_t* _label_name = nullptr;
static lv_obj_t* _label_track = nullptr;
static lv_obj_t* _label_artist = nullptr;
static lv_obj_t* _bpm_static = nullptr;
static lv_obj_t* _audio_pill = nullptr;
static lv_obj_t* _audio_dot = nullptr;
static lv_obj_t* _audio_text = nullptr;
static lv_obj_t* _joy_base[2] = {};
static lv_obj_t* _joy_knob[2] = {};
static lv_obj_t* _joy_lbl[2] = {};
static lv_obj_t* _status = nullptr;

/* ───────────────────────── 小工具 ───────────────────────── */

static void circle_style(lv_obj_t* o, int x, int y, int d, uint32_t bg, int opa)
{
    lv_obj_set_size(o, d, d);
    lv_obj_set_pos(o, x, y);
    lv_obj_set_style_radius(o, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_color(o, lv_color_hex(bg), 0);
    lv_obj_set_style_bg_opa(o, (lv_opa_t)opa, 0);
    lv_obj_set_style_border_width(o, 0, 0);
    lv_obj_clear_flag(o, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(o, LV_OBJ_FLAG_SCROLLABLE);
}

static lv_obj_t* mklabel(lv_obj_t* parent, const char* txt, int x, int y, int w, int h,
                         const lv_font_t* font, uint32_t color, bool tracked)
{
    lv_obj_t* l = lv_label_create(parent);
    if (tracked) track(l);
    lv_obj_set_pos(l, x, y);
    lv_obj_set_size(l, w, h);
    lv_label_set_text(l, txt);
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(color), 0);
    lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_clear_flag(l, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(l, LV_OBJ_FLAG_SCROLLABLE);
    return l;
}

/* ───────────────────────── 文字 / 值 ───────────────────────── */

static void paint_status(const char* s) { if (_status) lv_label_set_text(_status, s); }

static void paint_bpm()
{
    if (_bpm_static) lv_label_set_text_fmt(_bpm_static, "%d BPM", _bpm);
}

static void paint_play_state()
{
    if (_btn[FN_PLAY]) {
        lv_obj_set_style_bg_color(_btn[FN_PLAY], lv_color_hex(_playing ? STEM_GREEN : 0x151B24), 0);
        lv_obj_set_style_bg_opa(_btn[FN_PLAY], 245, 0);
        if (_btn_lbl[FN_PLAY]) {
            lv_obj_set_style_text_color(_btn_lbl[FN_PLAY], lv_color_hex(_playing ? 0x07130C : 0xE8EEF7), 0);
            lv_label_set_text(_btn_lbl[FN_PLAY], _playing ? "STOP" : "PLAY");
        }
    }
}

static void paint_audio()
{
    if (_audio_dot)
        lv_obj_set_style_bg_color(_audio_dot, lv_color_hex(_np_playing ? STEM_GREEN : 0x6B7482), 0);
    if (_audio_text) {
        lv_label_set_text(_audio_text, _np_playing ? "AUDIO IN" : "NO AUDIO");
        lv_obj_set_style_text_color(_audio_text, lv_color_hex(_np_playing ? 0xD8F5E6 : 0x9AA4B2), 0);
    }
}

/** 白色标签：有歌就显示歌，没有就显示 logo + STEM-D。 */
static void paint_label()
{
    bool has_track = _np_title[0] != 0;
    if (_label_logo) {
        if (has_track) lv_obj_add_flag(_label_logo, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_remove_flag(_label_logo, LV_OBJ_FLAG_HIDDEN);
    }
    if (_label_name) {
        if (has_track) lv_obj_add_flag(_label_name, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_remove_flag(_label_name, LV_OBJ_FLAG_HIDDEN);
    }
    if (_label_track) {
        if (has_track) lv_obj_remove_flag(_label_track, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(_label_track, LV_OBJ_FLAG_HIDDEN);
        lv_label_set_text(_label_track, has_track ? _np_title : "");
    }
    if (_label_artist) {
        bool has_artist = has_track && _np_artist[0] != 0;
        if (has_artist) lv_obj_remove_flag(_label_artist, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(_label_artist, LV_OBJ_FLAG_HIDDEN);
        lv_label_set_text(_label_artist, has_artist ? _np_artist : "");
    }
}

static void paint_arc(int i)
{
    if (!_arc[i]) return;
    uint32_t c = _muted[i] ? 0x5A6270 : STEM_GREEN;
    lv_obj_set_style_arc_color(_arc[i], lv_color_hex(c), LV_PART_INDICATOR);
    lv_arc_set_value(_arc[i], _val[i]);

    char nb[16];
    std::snprintf(nb, sizeof(nb), "%s%s%s", STEM_NAMES[i],
                  _muted[i] ? " M" : "", _solo[i] ? " S" : "");
    if (_name[i]) {
        lv_label_set_text(_name[i], nb);
        lv_obj_set_style_text_color(_name[i], lv_color_hex(_muted[i] ? 0x77808F : 0xE9F0F9), 0);
    }
    if (_num[i]) {
        lv_label_set_text_fmt(_num[i], "%d", _val[i]);
        lv_obj_set_style_text_color(_num[i], lv_color_hex(_muted[i] ? 0x8A93A2 : 0xFFFFFF), 0);
    }
}

static void paint_arcs() { for (int i = 0; i < 4; i++) paint_arc(i); }

static void set_stem(int i, int v)
{
    v = clamp_i(v, 0, 127);
    if (v == _val[i]) return;
    _val[i] = v;
    paint_arc(i);
    if (tx_gate(_tx_stem[i], 25000)) send_stem(i, v);
}

/* ───────────────────────── 走带 / 场景 / TAP ───────────────────────── */

static void toggle_play()
{
    _playing = !_playing;
    if (_playing) {
        _last_clock_us = esp_timer_get_time();
        midi("START");
    } else {
        midi("STOP");
    }
    paint_play_state();
    paint_status(_playing ? "PLAYING" : "STOPPED");
    tap_feedback();
}

static void apply_scene(int n)
{
    static const int SCENES[3][4] = {
        { 100, 100, 100, 100 },
        { 127, 80, 100, 127 },
        { 90, 127, 70, 40 },
    };
    n = (n % 3 + 3) % 3;
    _scene = n;
    for (int i = 0; i < 4; i++) {
        _val[i] = SCENES[n][i];
        paint_arc(i);
        send_stem(i, _val[i]);
    }
    paint_status(n == 0 ? "SCENE A" : (n == 1 ? "SCENE B" : "SCENE C"));
}

static void tap_tempo()
{
    int64_t now = esp_timer_get_time();
    if (_tap_count > 0 && now - _tap_us[(_tap_count - 1) % 4] > 2500000) _tap_count = 0;
    _tap_us[_tap_count % 4] = now;
    _tap_count++;
    if (_tap_count >= 3) {
        int n = _tap_count < 4 ? _tap_count : 4;
        int64_t span = _tap_us[(_tap_count - 1) % 4] - _tap_us[(_tap_count - n) % 4];
        if (span > 0) {
            _bpm = clamp_i((int)(60000000LL * (n - 1) / span), 40, 240);
            paint_bpm();
            midi("BPM %d", _bpm);
            char s[24];
            std::snprintf(s, sizeof(s), "BPM %d", _bpm);
            paint_status(s);
        }
    } else {
        paint_status("TAP ...");
    }
}

/* ───────────────────────── 摇杆 ───────────────────────── */

static const int JOY_X[2] = { 159, 307 };
static const int JOY_Y = 233;
static const int JOY_TRAVEL = 34;

static void joy_knob_to(int idx, float dx, float dy)
{
    if (_joy_knob[idx]) lv_obj_set_pos(_joy_knob[idx], JOY_X[idx] + (int)dx - 22, JOY_Y + (int)dy - 22);
}

static void joy_update(int idx, lv_point_t p)
{
    float dx = (float)(p.x - JOY_X[idx]);
    float dy = (float)(p.y - JOY_Y);
    float len = std::sqrt(dx * dx + dy * dy);
    if (len > JOY_TRAVEL) {
        dx = dx / len * JOY_TRAVEL;
        dy = dy / len * JOY_TRAVEL;
    }
    joy_knob_to(idx, dx, dy);

    int nx = clamp_i((int)(dx / (float)JOY_TRAVEL * 127.0f), -127, 127);
    int ny = clamp_i((int)(-dy / (float)JOY_TRAVEL * 127.0f), -127, 127);

    if (idx == 0) {
        if (tx_gate(_tx_tape, 30000)) send_tape(ny > 0 ? ny : 0, nx < 0 ? -nx : nx);
    } else {
        if (nx != _platter_last && tx_gate(_tx_platter, 30000)) {
            _platter_last = nx;
            send_platter(nx);
        }
        if (tx_gate(_tx_fx, 30000)) send_fx(ny > 0 ? ny : 0);
    }
}

/* ───────────────────────── 唱盘旋转 ───────────────────────── */

static void vinyl_set_deg(float deg)
{
    _vinyl_deg = deg;
    if (_vinyl_label) {
        int r = (int)(_vinyl_deg * 10.0f) % 3600;
        if (r < 0) r += 3600;
        lv_obj_set_style_transform_rotation(_vinyl_label, r, 0);
    }
}

static float wrap_deg(float d)
{
    while (d > 180) d -= 360;
    while (d < -180) d += 360;
    return d;
}

static int arc_at(float deg, float r)
{
    if (r < 150 || r > 226) return -1;
    for (int i = 0; i < 4; i++) {
        if (deg >= ARC_START[i] && deg < ARC_END[i]) return i;
    }
    return -1;
}

static int btn_at(float x, float y)
{
    for (int i = 0; i < 4; i++) {
        float dx = x - BTN_POS[i][0], dy = y - BTN_POS[i][1];
        if (dx * dx + dy * dy <= (BTN_R + 3) * (BTN_R + 3)) return i;
    }
    return -1;
}

/* ───────────────────────── stdin（Mac → 手表） ───────────────────────── */


/* ⚠️ 表上的 Montserrat 没有中文/全角/花式标点。CrewTower 的活动文本里经常有
 * `Thinking…`、中文、弯引号 —— 直接显示就是一个个小方框（缺字）。
 * 这里把常见标点映射成 ASCII，其余非 ASCII 码点整段跳过，保证永远不出现方框。 */
static void asciiize(char* s)
{
    char* w = s;
    unsigned char* p = (unsigned char*)s;
    while (*p) {
        if (*p < 0x80) { *w++ = (char)*p++; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0xA6) { *w++='.'; *w++='.'; *w++='.'; p += 3; continue; }
        if (p[0] == 0xC2 && p[1] == 0xB7) { *w++='|'; p += 2; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0x94) { *w++='-'; p += 3; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0x98) { *w++='\''; p += 3; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0x99) { *w++='\''; p += 3; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0x9C) { *w++='"'; p += 3; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0x9D) { *w++='"'; p += 3; continue; }
        int len = 1;
        if ((p[0] & 0xE0) == 0xC0) len = 2;
        else if ((p[0] & 0xF0) == 0xE0) len = 3;
        else if ((p[0] & 0xF8) == 0xF0) len = 4;
        p += len;
        *w++ = ' ';
    }
    *w = 0;
}

static void handle_line(char* line)
{
    if (std::strncmp(line, "CAP ", 4) == 0) { grooved_capture_line(line); return; }
    const char* rest = nullptr;
    if (std::strncmp(line, "NP ", 3) == 0) rest = line + 3;
    else if (std::strncmp(line, "G1 NP ", 6) == 0) rest = line + 6;
    if (!rest) return;

    char* bar1 = std::strchr((char*)rest, '|');
    if (!bar1) return;
    *bar1 = 0;
    char* bar2 = std::strchr(bar1 + 1, '|');
    if (!bar2) return;
    *bar2 = 0;

    const char* title = rest;
    const char* artist = bar1 + 1;
    bool playing = (bar2[1] == '1');

    bool changed = (std::strcmp(title, _np_title) != 0) ||
                   (std::strcmp(artist, _np_artist) != 0) ||
                   (playing != _np_playing);
    std::snprintf(_np_title, sizeof(_np_title), "%s", title);
    std::snprintf(_np_artist, sizeof(_np_artist), "%s", artist);
    asciiize(_np_title); asciiize(_np_artist);
    _np_playing = playing;
    _np_seen_ms = esp_timer_get_time() / 1000;

    if (changed) {
        if (!grooved_capture_active()) {
            std::printf("S_NP %s|%s|%d\n", _np_title, _np_artist, _np_playing ? 1 : 0);
            std::fflush(stdout);
        }
        paint_label();
        paint_audio();
    }
}

static void stdin_init()
{
    // 驱动在 main.cpp 启动时已经装好（见 USJ_BOOT），这里只需要非阻塞。
    int fl = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, fl | O_NONBLOCK);
}

static void stdin_poll()
{
    char buf[64];
    int n = 0;
    n = usb_serial_jtag_read_bytes(buf, sizeof(buf), 0);
    if (n < 0) {
        // 驱动没装成时退回 console VFS（至少不崩）
        n = read(STDIN_FILENO, buf, sizeof(buf));
        if (n < 0) n = 0;
    }
    for (int i = 0; i < n; i++) {
        char c = buf[i];
        if (c == '\n' || c == '\r') {
            _line[_line_len] = 0;
            if (_line_len > 0) handle_line(_line);
            _line_len = 0;
        } else if (_line_len < (int)sizeof(_line) - 1) {
            _line[_line_len++] = c;
        }
    }
}

/* ───────────────────────── 触摸 ───────────────────────── */

static void touch_press(float deg, float r, lv_point_t p)
{
    _press_us = esp_timer_get_time();
    _press_x = (float)p.x;
    _press_y = (float)p.y;
    _platter_moved = false;
    _arc_dragged = false;
    _last_arc = -1;

    int b = btn_at((float)p.x, (float)p.y);
    if (b >= 0) {
        _zone = (Zone)(Z_BTN_PLAY + b);
        return;
    }

    int a = arc_at(deg, r);
    if (a >= 0) {
        _zone = (Zone)(Z_ARC0 + a);
        _last_arc = a;
        float t = (deg - ARC_START[a]) / (float)(ARC_END[a] - ARC_START[a]);
        set_stem(a, (int)(t * 127.0f));
        paint_status(STEM_NAMES[a]);
        return;
    }

    if (_joy_page) {
        if (r < 145) {
            int idx = (p.x < CX) ? 0 : 1;
            _zone = (idx == 0) ? Z_JOYL : Z_JOYR;
            joy_update(idx, p);
            return;
        }
        _zone = Z_NONE;
        return;
    }

    if (r < PLATTER_R) {
        _zone = Z_PLATTER;
        _last_deg = deg;
        return;
    }

    _zone = Z_NONE;
}

static void touch_move(float deg, lv_point_t p)
{
    if (_zone >= Z_ARC0 && _zone <= Z_ARC3) {
        int i = _zone - Z_ARC0;
        float t = (deg - ARC_START[i]) / (float)(ARC_END[i] - ARC_START[i]);
        if (t < -0.1f || t > 1.1f) return;
        _arc_dragged = true;
        set_stem(i, (int)(t * 127.0f));
    } else if (_zone == Z_PLATTER) {
        int dx = p.x - (int)_press_x;
        int dy = p.y - (int)_press_y;
        if (dx * dx + dy * dy > 36) _platter_moved = true;

        float d = wrap_deg(deg - _last_deg);
        _last_deg = deg;

        // 整张标签跟着手指转（视觉上就是唱片在转）
        vinyl_set_deg(_vinyl_deg + d);

        if (std::fabs(d) > 0.35f) {
            int v = clamp_i((int)(d * 14.0f), -127, 127);
            if (v != _platter_last && tx_gate(_tx_platter, 30000)) {
                _platter_last = v;
                send_platter(v);
            }
        }
    } else if (_zone == Z_JOYL) {
        joy_update(0, p);
    } else if (_zone == Z_JOYR) {
        joy_update(1, p);
    }
}

static void set_joy_page(bool on)
{
    _joy_page = on;
    lv_obj_t* platter_objs[7] = { _platter, _rings[0], _rings[1], _rings[2],
                                  _vinyl_label, _bpm_static, nullptr };
    for (auto* o : platter_objs) {
        if (!o) continue;
        if (on) lv_obj_add_flag(o, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_remove_flag(o, LV_OBJ_FLAG_HIDDEN);
    }
    for (int i = 0; i < 2; i++) {
        lv_obj_t* o[3] = { _joy_base[i], _joy_knob[i], _joy_lbl[i] };
        for (auto* x : o) {
            if (!x) continue;
            if (on) lv_obj_remove_flag(x, LV_OBJ_FLAG_HIDDEN);
            else lv_obj_add_flag(x, LV_OBJ_FLAG_HIDDEN);
        }
    }
    if (_btn_lbl[FN_JOY]) lv_label_set_text(_btn_lbl[FN_JOY], on ? "STEM" : "JOY");
    paint_status(on ? "JOY PAGE" : "TAP PLATTER = PLAY");
}

static void touch_release()
{
    int64_t now = esp_timer_get_time();

    if (_zone >= Z_ARC0 && _zone <= Z_ARC3) {
        int i = _zone - Z_ARC0;
        send_stem(i, _val[i]);
    } else if (_zone == Z_PLATTER) {
        if (!_platter_moved && now - _press_us < 500000) {
            toggle_play();
        } else if (_platter_last != 0) {
            send_platter(0);
            _platter_last = 0;
        }
    } else if (_zone == Z_BTN_PLAY) {
        toggle_play();
    } else if (_zone == Z_BTN_SCENE) {
        tap_feedback();
        apply_scene(_scene + 1);
    } else if (_zone == Z_BTN_JOY) {
        tap_feedback();
        set_joy_page(!_joy_page);
    } else if (_zone == Z_BTN_TAP) {
        tap_feedback();
        tap_tempo();
    } else if (_zone == Z_JOYL) {
        joy_knob_to(0, 0, 0);
        send_tape(0, 0);
    } else if (_zone == Z_JOYR) {
        joy_knob_to(1, 0, 0);
        send_platter(0);
        _platter_last = 0;
        send_fx(0);
    }

    _zone = Z_NONE;
}

static void screen_event_cb(lv_event_t* e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_indev_t* indev = lv_indev_active();
    if (!indev) return;

    lv_point_t p;
    lv_indev_get_point(indev, &p);
    float dx = p.x - CX, dy = p.y - CY;
    float r = std::sqrt(dx * dx + dy * dy);
    float deg = std::atan2(dy, dx) * 180.0f / (float)M_PI;

    if (code == LV_EVENT_PRESSED) {
        touch_press(deg, r, p);
    } else if (code == LV_EVENT_PRESSING) {
        touch_move(deg, p);
    } else if (code == LV_EVENT_RELEASED) {
        touch_release();
    } else if (code == LV_EVENT_LONG_PRESSED) {
        if (_zone >= Z_ARC0 && _zone <= Z_ARC3 && !_arc_dragged) {
            int i = _zone - Z_ARC0;
            _muted[i] = !_muted[i];
            paint_arc(i);
            send_mute(i, _muted[i]);
            tap_feedback();
            char b[20];
            std::snprintf(b, sizeof(b), "%s %s", _muted[i] ? "MUTE" : "UNMUTE", STEM_NAMES[i]);
            paint_status(b);
        }
    } else if (code == LV_EVENT_DOUBLE_CLICKED) {
        if (_last_arc >= 0) {
            int i = _last_arc;
            _solo[i] = !_solo[i];
            paint_arc(i);
            send_solo(i, _solo[i]);
            tap_feedback();
            char b[20];
            std::snprintf(b, sizeof(b), "%s %s", _solo[i] ? "SOLO" : "UNSOLO", STEM_NAMES[i]);
            paint_status(b);
        }
    }
}

/* ───────────────────────── App ───────────────────────── */

AppStem::AppStem()
{
    setAppInfo().name = "Stem D";
    setAppInfo().icon = (void*)&icon_stem_d;
}

void AppStem::onCreate()
{
    mclog::tagInfo(getAppInfo().name, "on create");
    midi("HELLO stem-d 6");
}

void AppStem::onOpen()
{
    mclog::tagInfo(getAppInfo().name, "on open");
    _key_manager = std::make_unique<input::KeyManager>();

    LvglLockGuard lock;
    destroy_all();
    stdin_init();
    _line_len = 0;

    lv_obj_t* scr = lv_screen_active();
    lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(scr, lv_color_hex(0x0B0E13), 0);
    lv_obj_set_style_bg_grad_color(scr, lv_color_hex(0x04060A), 0);
    lv_obj_set_style_bg_grad_dir(scr, LV_GRAD_DIR_VER, 0);

    /* ① 四段 1/4 弧 */
    for (int i = 0; i < 4; i++) {
        _arc[i] = track(lv_arc_create(scr));
        lv_obj_set_size(_arc[i], ARC_SIZE, ARC_SIZE);
        lv_obj_set_pos(_arc[i], CX - ARC_SIZE / 2, CY - ARC_SIZE / 2);
        lv_arc_set_bg_angles(_arc[i], ARC_START[i], ARC_END[i]);
        lv_arc_set_range(_arc[i], 0, 127);
        lv_arc_set_value(_arc[i], _val[i]);
        lv_obj_set_style_arc_width(_arc[i], ARC_W, LV_PART_MAIN);
        lv_obj_set_style_arc_color(_arc[i], lv_color_hex(0xFFFFFF), LV_PART_MAIN);
        lv_obj_set_style_arc_opa(_arc[i], 45, LV_PART_MAIN);
        lv_obj_set_style_arc_width(_arc[i], ARC_W, LV_PART_INDICATOR);
        lv_obj_set_style_arc_color(_arc[i], lv_color_hex(STEM_GREEN), LV_PART_INDICATOR);
        lv_obj_set_style_arc_opa(_arc[i], 255, LV_PART_INDICATOR);
        lv_obj_set_style_bg_opa(_arc[i], LV_OPA_TRANSP, LV_PART_KNOB);
        lv_obj_clear_flag(_arc[i], LV_OBJ_FLAG_CLICKABLE);

        int lx = QLAB[i][0], ly = QLAB[i][1];
        _name[i] = mklabel(scr, STEM_NAMES[i], lx - 36, ly - 20, 72, 18,
                           &lv_font_montserrat_14, 0xE9F0F9, true);
        _num[i]  = mklabel(scr, "100", lx - 36, ly + 1, 72, 22,
                           &lv_font_montserrat_16, 0xFFFFFF, true);
    }
    paint_arcs();

    /* ② 红胶盘 */
    _platter = track(lv_obj_create(scr));
    circle_style(_platter, CX - PLATTER_R, CY - PLATTER_R, PLATTER_R * 2, 0x6B0C12, 235);
    lv_obj_set_style_bg_grad_color(_platter, lv_color_hex(0x26040A), 0);
    lv_obj_set_style_bg_grad_dir(_platter, LV_GRAD_DIR_VER, 0);
    lv_obj_set_style_border_width(_platter, 1, 0);
    lv_obj_set_style_border_color(_platter, lv_color_hex(0xFF8A8A), 0);
    lv_obj_set_style_border_opa(_platter, 90, 0);
    lv_obj_set_style_shadow_width(_platter, 18, 0);
    lv_obj_set_style_shadow_color(_platter, lv_color_hex(0xD2141E), 0);
    lv_obj_set_style_shadow_opa(_platter, 30, 0);

    for (int k = 0; k < 3; k++) {
        int d = 176 - k * 32;
        _rings[k] = track(lv_obj_create(scr));
        circle_style(_rings[k], CX - d / 2, CY - d / 2, d, 0x000000, 0);
        lv_obj_set_style_border_width(_rings[k], 1, 0);
        lv_obj_set_style_border_color(_rings[k], lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_border_opa(_rings[k], 24, 0);
    }

    /* ③ 白色标签块（YSL 那种贴在唱片上的白块）：跟着手指转 */
    _vinyl_label = track(lv_obj_create(scr));
    lv_obj_set_pos(_vinyl_label, CX - LAB_W / 2, CY - LAB_H / 2);
    lv_obj_set_size(_vinyl_label, LAB_W, LAB_H);
    lv_obj_set_style_radius(_vinyl_label, 14, 0);
    lv_obj_set_style_bg_color(_vinyl_label, lv_color_hex(0xF3EFE6), 0);
    lv_obj_set_style_bg_opa(_vinyl_label, 255, 0);
    lv_obj_set_style_border_width(_vinyl_label, 1, 0);
    lv_obj_set_style_border_color(_vinyl_label, lv_color_hex(0x000000), 0);
    lv_obj_set_style_border_opa(_vinyl_label, 70, 0);
    lv_obj_set_style_transform_pivot_x(_vinyl_label, LAB_W / 2, 0);
    lv_obj_set_style_transform_pivot_y(_vinyl_label, LAB_H / 2, 0);
    lv_obj_clear_flag(_vinyl_label, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(_vinyl_label, LV_OBJ_FLAG_SCROLLABLE);

    _label_logo = lv_image_create(_vinyl_label);
    lv_image_set_src(_label_logo, &logo_stem);
    lv_image_set_scale(_label_logo, 110);          // 51×27
    lv_obj_set_pos(_label_logo, (LAB_W - 51) / 2, 10);
    lv_obj_set_style_image_recolor(_label_logo, lv_color_hex(0x1A1A1A), 0);
    lv_obj_set_style_image_recolor_opa(_label_logo, LV_OPA_COVER, 0);
    lv_obj_clear_flag(_label_logo, LV_OBJ_FLAG_CLICKABLE);

    _label_name = mklabel(_vinyl_label, "STEM-D", 10, 42, LAB_W - 20, 20,
                          &lv_font_montserrat_14, 0x1A1A1A, false);

    _label_track = mklabel(_vinyl_label, "", 8, 30, LAB_W - 16, 20,
                           &lv_font_montserrat_14, 0x141414, false);
    lv_label_set_long_mode(_label_track, LV_LABEL_LONG_DOT);

    _label_artist = mklabel(_vinyl_label, "", 8, 54, LAB_W - 16, 16,
                            &lv_font_montserrat_10, 0x555555, false);
    lv_label_set_long_mode(_label_artist, LV_LABEL_LONG_DOT);

    paint_label();
    vinyl_set_deg(0);

    /* ④ 盘底 BPM（静态，不转） */
    _bpm_static = mklabel(scr, "120 BPM", CX - 50, CY + 62, 100, 16,
                          &lv_font_montserrat_10, 0xC9D3E0, true);
    paint_bpm();

    /* ⑤ 音频状态（静态） */
    _audio_pill = track(lv_obj_create(scr));
    lv_obj_set_pos(_audio_pill, CX - 48, CY - 94);
    lv_obj_set_size(_audio_pill, 96, 22);
    lv_obj_set_style_radius(_audio_pill, 11, 0);
    lv_obj_set_style_bg_color(_audio_pill, lv_color_hex(0x0B0E13), 0);
    lv_obj_set_style_bg_opa(_audio_pill, 170, 0);
    lv_obj_set_style_border_width(_audio_pill, 1, 0);
    lv_obj_set_style_border_color(_audio_pill, lv_color_hex(0xFFFFFF), 0);
    lv_obj_set_style_border_opa(_audio_pill, 30, 0);
    lv_obj_clear_flag(_audio_pill, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(_audio_pill, LV_OBJ_FLAG_SCROLLABLE);

    _audio_dot = track(lv_obj_create(scr));
    circle_style(_audio_dot, CX - 39, CY - 88, 9, 0x6B7482, 255);
    lv_obj_clear_flag(_audio_dot, LV_OBJ_FLAG_CLICKABLE);

    _audio_text = mklabel(scr, "NO AUDIO", CX - 26, CY - 91, 76, 16,
                          &lv_font_montserrat_10, 0x9AA4B2, true);
    paint_audio();

    /* ⑥ 绕盘功能键 */
    static const char* BTN_TXT[4] = { "PLAY", "SCENE", "JOY", "TAP" };
    for (int i = 0; i < 4; i++) {
        _btn[i] = track(lv_obj_create(scr));
        circle_style(_btn[i], BTN_POS[i][0] - BTN_R, BTN_POS[i][1] - BTN_R, BTN_R * 2, 0x151B24, 245);
        lv_obj_set_style_border_width(_btn[i], 1, 0);
        lv_obj_set_style_border_color(_btn[i], lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_border_opa(_btn[i], 35, 0);
        _btn_lbl[i] = mklabel(scr, BTN_TXT[i], BTN_POS[i][0] - BTN_R, BTN_POS[i][1] - 9,
                              BTN_R * 2, 18,
                              i == 1 ? &lv_font_montserrat_10 : &lv_font_montserrat_14,
                              0xE8EEF7, true);
    }
    paint_play_state();

    /* ⑦ 双摇杆 */
    for (int i = 0; i < 2; i++) {
        _joy_base[i] = track(lv_obj_create(scr));
        circle_style(_joy_base[i], JOY_X[i] - 56, JOY_Y - 56, 112, 0x10151C, 235);
        lv_obj_set_style_border_width(_joy_base[i], 1, 0);
        lv_obj_set_style_border_color(_joy_base[i], lv_color_hex(0x2E3846), 0);
        lv_obj_set_style_border_opa(_joy_base[i], 255, 0);

        _joy_knob[i] = track(lv_obj_create(scr));
        circle_style(_joy_knob[i], JOY_X[i] - 22, JOY_Y - 22, 44,
                     i == 0 ? 0xFF7A3B : 0x6AA9FF, 215);
        lv_obj_set_style_border_width(_joy_knob[i], 1, 0);
        lv_obj_set_style_border_color(_joy_knob[i], lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_border_opa(_joy_knob[i], 60, 0);

        _joy_lbl[i] = mklabel(scr, i == 0 ? "TAPE" : "DECK / FX",
                              JOY_X[i] - 50, 292, 100, 18,
                              &lv_font_montserrat_14, 0xD6E0EC, true);

        lv_obj_add_flag(_joy_base[i], LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(_joy_knob[i], LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(_joy_lbl[i], LV_OBJ_FLAG_HIDDEN);
    }

    /* ⑧ 状态行 */
    _status = mklabel(scr, "TAP PLATTER = PLAY", CX - 100, 432, 200, 18,
                      &lv_font_montserrat_14, 0xDFE7F2, true);

    lv_obj_add_flag(scr, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(scr, screen_event_cb, LV_EVENT_PRESSED, nullptr);
    lv_obj_add_event_cb(scr, screen_event_cb, LV_EVENT_PRESSING, nullptr);
    lv_obj_add_event_cb(scr, screen_event_cb, LV_EVENT_RELEASED, nullptr);
    lv_obj_add_event_cb(scr, screen_event_cb, LV_EVENT_LONG_PRESSED, nullptr);
    lv_obj_add_event_cb(scr, screen_event_cb, LV_EVENT_DOUBLE_CLICKED, nullptr);

    _zone = Z_NONE;
    _last_arc = -1;
    midi("BPM %d", _bpm);
}

void AppStem::onRunning()
{
    // ⚠️ LVGL 跑在独立任务里（hal_display 的 lvgl_rtos_task 持有 xGuiSemaphore）。
    //    onRunning 在主任务 ⇒ 所有 LVGL 调用都必须拿锁，否则会和渲染线程抢，
    //    轻则花屏，重则卡死（症状就是"按黄键没反应，只能重启"）。
    {
        LvglLockGuard lock;
        stdin_poll();

        // 桥停了 10 秒以上 ⇒ 如实退回 NO AUDIO，不装作还在放
        if (_np_playing) {
            int64_t now_ms = esp_timer_get_time() / 1000;
            if (_np_seen_ms == 0 || now_ms - _np_seen_ms > 10000) {
                _np_playing = false;
                paint_audio();
            }
        }
    }

    if (_key_manager) {
        auto ev = _key_manager->update();
        if (ev == input::KeyEvent::GoPrevious || ev == input::KeyEvent::GoHome) {
            close();
            return;
        }
        if (ev == input::KeyEvent::GoNext) {
            tap_feedback();
            LvglLockGuard lock;
            apply_scene(_scene + 1);
        }
    }

    if (_playing) {
        int64_t now = esp_timer_get_time();
        const int64_t step = 60000000LL / ((int64_t)_bpm * 24);
        while (now - _last_clock_us >= step) {
            midi("CLOCK");
            _last_clock_us += step;
        }
    }
}

void AppStem::onClose()
{
    mclog::tagInfo(getAppInfo().name, "on close");
    if (_playing) {
        _playing = false;
        midi("STOP");
    }
    _key_manager.reset();

    LvglLockGuard lock;
    destroy_all();

    for (auto& p : _arc) p = nullptr;
    for (auto& p : _name) p = nullptr;
    for (auto& p : _num) p = nullptr;
    for (auto& p : _btn) p = nullptr;
    for (auto& p : _btn_lbl) p = nullptr;
    for (auto& p : _rings) p = nullptr;
    for (auto& p : _joy_base) p = nullptr;
    for (auto& p : _joy_knob) p = nullptr;
    for (auto& p : _joy_lbl) p = nullptr;
    _platter = nullptr;
    _vinyl_label = nullptr;
    _label_logo = nullptr;
    _label_name = nullptr;
    _label_track = nullptr;
    _label_artist = nullptr;
    _bpm_static = nullptr;
    _audio_pill = nullptr;
    _audio_dot = nullptr;
    _audio_text = nullptr;
    _status = nullptr;
}
