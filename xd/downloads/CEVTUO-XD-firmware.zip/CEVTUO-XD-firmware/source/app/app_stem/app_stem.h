/*
 * Stem —— 原厂固件里的一个 **MIDI 控制器** app。
 *
 * 它不做别的：屏幕上所有东西都是 MIDI 控制（BPM / 走带 / CC / Note / Panic）。
 * 消息通过 **USB 串口** 发给 Mac 上的 `tools/grooved-serial-midi`
 * （那个工具建一个叫 "GrooveD" 的 CoreMIDI 虚拟端口）。
 *
 * 为什么走 USB 而不是 Wi-Fi：这台表的 USB 一直插着（供电/烧录），
 * 而 Wi-Fi 要配网、要处理断线重连 —— 对"一个 MIDI 控制器"来说
 * 那条路只在多花时间，不会更可靠。
 */
#pragma once
#include <apps/common/key_manager/key_manager.h>
#include <mooncake.h>
#include <memory>

class AppStem : public mooncake::AppAbility {
public:
    AppStem();

    void onCreate() override;
    void onOpen() override;
    void onRunning() override;
    void onClose() override;

private:
    std::unique_ptr<input::KeyManager> _key_manager;
};
