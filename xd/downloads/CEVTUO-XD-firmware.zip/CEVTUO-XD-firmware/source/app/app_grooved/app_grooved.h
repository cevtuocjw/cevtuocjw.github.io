/*
 * Groove D —— MIDI **演奏** app（打击垫 / CC / 走带）。
 *
 * 和 Stem 分开：Stem 管四轨推子与静音/独奏，Groove D 管"打"和"扭"。
 * 两个 app 各自有独立的界面与手势，launcher 里是两张卡片。
 */
#pragma once
#include <apps/common/key_manager/key_manager.h>
#include <mooncake.h>
#include <memory>

class AppGrooved : public mooncake::AppAbility {
public:
    AppGrooved();
    void onCreate() override;
    void onOpen() override;
    void onRunning() override;
    void onClose() override;

private:
    std::unique_ptr<input::KeyManager> _key_manager;
};
