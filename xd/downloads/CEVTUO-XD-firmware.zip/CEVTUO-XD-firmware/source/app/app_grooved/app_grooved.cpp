/*
 * Groove D v2 -- 鼓机 / 演奏页（和 Stem 明确分开）。
 *
 * 分工（读者 2026-10-19）：
 *   | Stem   = 四轨 stem 推子 + 搓盘 + 磁带/FX（混音台）
 *   | Groove = 打击垫 + 小推子 + 指针盘 + 走带 + 磁带机（鼓机/演出）
 *   ⇒ Groove 里不放 stem 推子，Stem 里不放打击垫。
 *
 * 页面：
 *   主页面：8 打击垫 / 4 根 CC 小推子 / 2 个指针盘（BPM、FX）/ 电平指示 / 走带
 *   双击背景：切磁带机页（两个卷轴 + 计数器）
 *
 * ⚠️ 本固件没有初始化 LVGL 主题 ⇒ 所有文字必须显式设色（默认是黑色）。
 * ⚠️ 字体只有 Montserrat，没有中文字形 ⇒ 界面文字只用英文。
 * ⚠️ 卷轴辐条必须是卷轴的**子对象**，否则不会跟着转（v1 的辐条是屏幕子对象，位置永远不对）。
 */
#include "app_grooved.h"
#include "../grooved_icons.h"
#include "../grooved_capture.h"
#include <hal/hal.h>
#include <mooncake.h>
#include <mooncake_log.h>
#include <smooth_lvgl.hpp>
#include <cstdio>
#include <cstdarg>
#include <cmath>
#include <string>
#include <esp_timer.h>

using namespace mooncake;
using namespace smooth_ui_toolkit::lvgl_cpp;

/* ───────────────────────── 协议 ───────────────────────── */

static void midi(const char* fmt, ...)
{
    char buf[96];
    int n = std::snprintf(buf, sizeof(buf), "G1 ");
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(buf + n, sizeof(buf) - n, fmt, ap);
    va_end(ap);
    std::printf("%s\n", buf);
    std::fflush(stdout);
}
static void tap_feedback() { GetHAL().vibrate(10, 60); }

static int clamp_i(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static int64_t _tx[8] = {};
static bool tx_gate(int slot, int64_t interval_us)
{
    int64_t now = esp_timer_get_time();
    if (now - _tx[slot] < interval_us) return false;
    _tx[slot] = now;
    return true;
}

/* ───────────────────────── 常量 ───────────────────────── */

static const int CX = 233;

static const int PAD_COLS = 4;
static const int PAD_W = 74, PAD_H = 68;
static const int PAD_X0 = 73, PAD_Y0 = 80;
static const int PAD_DX = 82, PAD_DY = 76;

static const int FADER_X[4] = { 155, 207, 259, 311 };
static const int FADER_TOP = 244, FADER_LEN = 104;
static const int CC_NUMS[4] = { 1, 7, 10, 11 };

static const int DIAL_X[2] = { 95, 371 };
static const int DIAL_Y = 302;
static const int DIAL_R = 42;

static const uint32_t FADER_COLORS[4] = { 0x57E39B, 0x6AA9FF, 0xB58CFF, 0xFFC24B };
static const uint32_t FADER_DARK[4]   = { 0x1F7A52, 0x2F5FA8, 0x6B4AA8, 0xB07A18 };

static const uint32_t PAD_COLORS[8] = {
    0xFF7A3B, 0xFFC24B, 0x4AD78C, 0x57E39B,
    0x6AA9FF, 0xB58CFF, 0xFF7AB0, 0x59D7E8,
};

/* ───────────────────────── 状态 ───────────────────────── */

static const int PADS_DRUM[8] = { 36, 38, 42, 46, 39, 45, 49, 51 };
static const int PADS_SYNTH[8] = { 60, 62, 64, 67, 69, 72, 74, 77 };
static const char* PAD_LABELS[8] = { "KICK", "SNR", "HAT", "OPEN", "CLAP", "TOM", "CRSH", "RIDE" };

static int _bpm = 120;
static bool _playing = false;
static int _bank = 0;
static int _cc[4] = { 64, 64, 64, 64 };
static int _fx = 0;
static bool _tape_page = false;
static int _level = 0;
static int64_t _last_clock_us = 0;
static int64_t _tap_us[4] = { 0, 0, 0, 0 };
static int _tap_count = 0;
static int64_t _level_tick = 0;

/* 触摸（推子 / 指针盘） */
enum Zone { Z_NONE, Z_FADER0, Z_FADER1, Z_FADER2, Z_FADER3, Z_DIAL0, Z_DIAL1 };
static Zone _zone = Z_NONE;
static int _drag_y0 = 0, _dial_base = 0;

/* ───────────────────────── 对象 ───────────────────────── */

static lv_obj_t* _owned[180];
static int _owned_n = 0;
static lv_obj_t* track(lv_obj_t* o)
{
    if (o && _owned_n < (int)(sizeof(_owned) / sizeof(_owned[0]))) _owned[_owned_n++] = o;
    return o;
}
static void destroy_all()
{
    for (int i = _owned_n - 1; i >= 0; i--) if (_owned[i]) lv_obj_del(_owned[i]);
    _owned_n = 0;
}

static lv_obj_t* _pad[8] = {};
static lv_obj_t* _pad_lbl[8] = {};
static lv_obj_t* _fader_fill[4] = {};
static lv_obj_t* _fader_cap[4] = {};
static lv_obj_t* _fader_val[4] = {};
static lv_obj_t* _fader_name[4] = {};
static lv_obj_t* _dial_arc[2] = {};
static lv_obj_t* _dial_needle[2] = {};
static lv_obj_t* _dial_lbl[2] = {};
static lv_obj_t* _meter_seg[12] = {};
static lv_obj_t* _reel[2] = {};
static lv_obj_t* _tape_title = nullptr;
static lv_obj_t* _tape_counter = nullptr;
static lv_obj_t* _status = nullptr;
static lv_obj_t* _play_btn = nullptr;
static lv_obj_t* _play_lbl = nullptr;
static lv_obj_t* _title = nullptr;
static lv_obj_t* _sub = nullptr;

/* ───────────────────────── 工具 ───────────────────────── */

static void circle_style(lv_obj_t* o, int x, int y, int d, uint32_t bg, int opa)
{
    lv_obj_set_pos(o, x, y);
    lv_obj_set_size(o, d, d);
    lv_obj_set_style_radius(o, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_color(o, lv_color_hex(bg), 0);
    lv_obj_set_style_bg_opa(o, (lv_opa_t)opa, 0);
    lv_obj_set_style_border_width(o, 0, 0);
    lv_obj_clear_flag(o, LV_OBJ_FLAG_SCROLLABLE);
}

static lv_obj_t* mklabel(lv_obj_t* parent, const char* txt, int x, int y, int w, int h,
                         const lv_font_t* font, uint32_t color, bool tracked)
{
    lv_obj_t* l = lv_label_create(parent);
    if (tracked) track(l);
    lv_obj_set_pos(l, x, y);
    lv_obj_set_size(l, w, h);
    lv_label_set_text(l, txt);
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(color), 0);
    lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_clear_flag(l, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(l, LV_OBJ_FLAG_SCROLLABLE);
    return l;
}

/* ───────────────────────── 绘制 ───────────────────────── */

static void paint_status(const char* s) { if (_status) lv_label_set_text(_status, s); }

static int pad_note(int i) { return _bank == 0 ? PADS_DRUM[i] : PADS_SYNTH[i]; }

static void paint_pad(int i, bool active)
{
    if (!_pad[i]) return;
    lv_obj_set_style_bg_color(_pad[i], lv_color_hex(active ? PAD_COLORS[i] : 0x151B24), 0);
    lv_obj_set_style_bg_opa(_pad[i], active ? 235 : 245, 0);
    if (_pad_lbl[i])
        lv_obj_set_style_text_color(_pad_lbl[i], lv_color_hex(active ? 0x0B0D10 : 0xE8EEF7), 0);
}

static void paint_pads()
{
    for (int i = 0; i < 8; i++) {
        if (!_pad_lbl[i]) continue;
        char b[24];
        std::snprintf(b, sizeof(b), "%s\n%d", PAD_LABELS[i], pad_note(i));
        lv_label_set_text(_pad_lbl[i], b);
        paint_pad(i, false);
    }
}

static void paint_meter()
{
    int lit = _level * 12 / 127;
    for (int i = 0; i < 12; i++) {
        if (!_meter_seg[i]) continue;
        lv_obj_set_style_bg_opa(_meter_seg[i], i < lit ? 235 : 30, 0);
        lv_obj_set_style_bg_color(_meter_seg[i],
            lv_color_hex(i < 8 ? 0x57E39B : (i < 10 ? 0xFFC24B : 0xFF6A5A)), 0);
    }
}

static void paint_fader(int i)
{
    if (!_fader_fill[i]) return;
    int h = _cc[i] * FADER_LEN / 127;
    if (h < 2) h = 2;
    lv_obj_set_y(_fader_fill[i], FADER_TOP + (FADER_LEN - h));
    lv_obj_set_height(_fader_fill[i], h);
    if (_fader_cap[i]) lv_obj_set_y(_fader_cap[i], FADER_TOP + (FADER_LEN - h) - 7);
    if (_fader_val[i]) lv_label_set_text_fmt(_fader_val[i], "%d", _cc[i]);
}

static void paint_dial(int i)
{
    if (_dial_arc[i]) {
        if (i == 0) lv_arc_set_value(_dial_arc[i], _bpm - 40);
        else lv_arc_set_value(_dial_arc[i], _fx);
    }
    if (_dial_needle[i]) {
        int v = (i == 0) ? (_bpm - 40) : _fx;
        int range = (i == 0) ? 200 : 127;
        int deg = -135 + v * 270 / range;
        lv_obj_set_style_transform_rotation(_dial_needle[i], deg * 10, 0);
    }
    if (_dial_lbl[i]) {
        char b[24];
        if (i == 0) std::snprintf(b, sizeof(b), "BPM %d", _bpm);
        else std::snprintf(b, sizeof(b), "FX %d", _fx);
        lv_label_set_text(_dial_lbl[i], b);
    }
}

static void paint_play()
{
    if (_play_btn) {
        lv_obj_set_style_bg_color(_play_btn, lv_color_hex(_playing ? 0x57E39B : 0x1A212B), 0);
    }
    if (_play_lbl) {
        lv_label_set_text(_play_lbl, _playing ? "STOP" : "PLAY");
        lv_obj_set_style_text_color(_play_lbl, lv_color_hex(_playing ? 0x07130C : 0xE8EEF7), 0);
    }
}

/* ───────────────────────── 卷轴 ───────────────────────── */

static void reel_anim_cb(void* var, int32_t v)
{
    lv_obj_set_style_transform_rotation((lv_obj_t*)var, v, 0);
}

static void reel_anim(lv_obj_t* o, bool on, int ms)
{
    if (!o) return;
    lv_anim_del(o, reel_anim_cb);
    if (!on) return;
    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_var(&a, o);
    lv_anim_set_values(&a, 0, 3600);
    lv_anim_set_time(&a, ms);
    lv_anim_set_repeat_count(&a, LV_ANIM_REPEAT_INFINITE);
    lv_anim_set_exec_cb(&a, reel_anim_cb);
    lv_anim_start(&a);
}

static void paint_tape_page()
{
    for (int i = 0; i < 8; i++) {
        if (!_pad[i]) continue;
        if (_tape_page) lv_obj_add_flag(_pad[i], LV_OBJ_FLAG_HIDDEN);
        else lv_obj_remove_flag(_pad[i], LV_OBJ_FLAG_HIDDEN);
    }
    for (int i = 0; i < 4; i++) {
        lv_obj_t* objs[4] = { _fader_fill[i], _fader_cap[i], _fader_val[i], _fader_name[i] };
        for (auto* o : objs) {
            if (!o) continue;
            if (_tape_page) lv_obj_add_flag(o, LV_OBJ_FLAG_HIDDEN);
            else lv_obj_remove_flag(o, LV_OBJ_FLAG_HIDDEN);
        }
    }
    for (int i = 0; i < 2; i++) {
        lv_obj_t* objs[3] = { _dial_arc[i], _dial_needle[i], _dial_lbl[i] };
        for (auto* o : objs) {
            if (!o) continue;
            if (_tape_page) lv_obj_add_flag(o, LV_OBJ_FLAG_HIDDEN);
            else lv_obj_remove_flag(o, LV_OBJ_FLAG_HIDDEN);
        }
    }
    for (int i = 0; i < 2; i++) {
        if (!_reel[i]) continue;
        if (_tape_page) lv_obj_remove_flag(_reel[i], LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(_reel[i], LV_OBJ_FLAG_HIDDEN);
    }
    if (_tape_title) {
        if (_tape_page) lv_obj_remove_flag(_tape_title, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(_tape_title, LV_OBJ_FLAG_HIDDEN);
    }
    if (_tape_counter) {
        if (_tape_page) lv_obj_remove_flag(_tape_counter, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(_tape_counter, LV_OBJ_FLAG_HIDDEN);
    }
    if (_tape_counter) {
        char b[40];
        std::snprintf(b, sizeof(b), "TAPE  |  %d BPM", _bpm);
        lv_label_set_text(_tape_counter, b);
    }
    paint_status(_tape_page ? "DOWN = TAPE STOP | DOUBLE TAP = BACK"
                            : "DOUBLE TAP = TAPE | SWIPE = PLAY");
}

/* ───────────────────────── 交互 ───────────────────────── */

static void toggle_play()
{
    _playing = !_playing;
    if (_playing) {
        _last_clock_us = esp_timer_get_time();
        midi("START");
    } else {
        midi("STOP");
    }
    paint_play();
    reel_anim(_reel[0], _playing && _tape_page, 1400);
    reel_anim(_reel[1], _playing && _tape_page, 1900);
    paint_status(_playing ? "PLAYING" : "STOPPED");
}

static void set_bpm(int v)
{
    v = clamp_i(v, 40, 240);
    if (v == _bpm) return;
    _bpm = v;
    paint_dial(0);
    midi("BPM %d", _bpm);
    if (_tape_page && _tape_counter) {
        char b[40];
        std::snprintf(b, sizeof(b), "TAPE  |  %d BPM", _bpm);
        lv_label_set_text(_tape_counter, b);
    }
}

static void toggle_bank()
{
    _bank = !_bank;
    paint_pads();
    paint_status(_bank ? "BANK | SYNTH" : "BANK | DRUM");
}

static void tap_tempo()
{
    int64_t now = esp_timer_get_time();
    if (_tap_count > 0 && now - _tap_us[(_tap_count - 1) % 4] > 2500000) _tap_count = 0;
    _tap_us[_tap_count % 4] = now;
    _tap_count++;
    if (_tap_count >= 3) {
        int n = _tap_count < 4 ? _tap_count : 4;
        int64_t span = _tap_us[(_tap_count - 1) % 4] - _tap_us[(_tap_count - n) % 4];
        if (span > 0) set_bpm((int)(60000000LL * (n - 1) / span));
    }
    paint_status("TAP");
}

static void pad_event_cb(lv_event_t* e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t* obj = (lv_obj_t*)lv_event_get_target(e);
    int i = (int)(intptr_t)lv_obj_get_user_data(obj);
    if (i < 0 || i > 7) return;

    if (code == LV_EVENT_PRESSED) {
        tap_feedback();
        paint_pad(i, true);
        midi("NOTEON 1 %d 110", pad_note(i));
        _level = 127;
        paint_meter();
        paint_status(PAD_LABELS[i]);
    } else if (code == LV_EVENT_RELEASED || code == LV_EVENT_PRESS_LOST) {
        midi("NOTEOFF 1 %d 0", pad_note(i));
        paint_pad(i, false);
    }
}

static void btn_event_cb(lv_event_t* e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    int id = (int)(intptr_t)lv_obj_get_user_data((lv_obj_t*)lv_event_get_target(e));
    tap_feedback();
    if (id == 0) toggle_play();
    else if (id == 1) tap_tempo();
    else if (id == 2) { midi("PANIC"); paint_status("PANIC"); }
}

static void fader_at(lv_point_t p)
{
    int i = _zone - Z_FADER0;
    if (i < 0 || i > 3) return;
    int v = (FADER_TOP + FADER_LEN - p.y) * 127 / FADER_LEN;
    v = clamp_i(v, 0, 127);
    if (v == _cc[i]) return;
    _cc[i] = v;
    paint_fader(i);
    char slot = (char)(4 + i);
    if (tx_gate(slot, 25000)) midi("CC 1 %d %d", CC_NUMS[i], v);
}

static void dial_at(lv_point_t p)
{
    int i = _zone - Z_DIAL0;
    if (i < 0 || i > 1) return;
    int dy = _drag_y0 - p.y;
    if (i == 0) {
        set_bpm(_dial_base + dy * 6 / 5);
    } else {
        int v = clamp_i(_dial_base + dy, 0, 127);
        if (v == _fx) return;
        _fx = v;
        paint_dial(1);
        if (tx_gate(7, 25000)) midi("FX %d", _fx);
    }
}

static void touch_press(lv_point_t p)
{
    _zone = Z_NONE;
    for (int i = 0; i < 4; i++) {
        int fdx = p.x - FADER_X[i];
        if (fdx < 0) fdx = -fdx;
        if (!_tape_page && fdx <= 18 &&
            p.y >= FADER_TOP - 10 && p.y <= FADER_TOP + FADER_LEN + 14) {
            _zone = (Zone)(Z_FADER0 + i);
            fader_at(p);
            return;
        }
    }
    for (int i = 0; i < 2; i++) {
        float dx = p.x - DIAL_X[i], dy = p.y - DIAL_Y;
        if (!_tape_page && dx * dx + dy * dy <= (DIAL_R + 8) * (DIAL_R + 8)) {
            _zone = (Zone)(Z_DIAL0 + i);
            _drag_y0 = p.y;
            _dial_base = (i == 0) ? _bpm : _fx;
            return;
        }
    }
}

static void screen_event_cb(lv_event_t* e)
{
    lv_event_code_t code = lv_event_get_code(e);

    if (code == LV_EVENT_PRESSED) {
        lv_indev_t* indev = lv_indev_active();
        if (!indev) return;
        lv_point_t p;
        lv_indev_get_point(indev, &p);
        touch_press(p);
    } else if (code == LV_EVENT_PRESSING) {
        if (_zone == Z_NONE) return;
        lv_indev_t* indev = lv_indev_active();
        if (!indev) return;
        lv_point_t p;
        lv_indev_get_point(indev, &p);
        if (_zone >= Z_FADER0 && _zone <= Z_FADER3) fader_at(p);
        else dial_at(p);
    } else if (code == LV_EVENT_RELEASED) {
        if (_zone >= Z_FADER0 && _zone <= Z_FADER3) {
            int i = _zone - Z_FADER0;
            midi("CC 1 %d %d", CC_NUMS[i], _cc[i]);
        }
        _zone = Z_NONE;
    } else if (code == LV_EVENT_DOUBLE_CLICKED) {
        _tape_page = !_tape_page;
        tap_feedback();
        paint_tape_page();
        reel_anim(_reel[0], _playing && _tape_page, 1400);
        reel_anim(_reel[1], _playing && _tape_page, 1900);
    } else if (code == LV_EVENT_GESTURE && _zone == Z_NONE) {
        lv_dir_t dir = lv_indev_get_gesture_dir(lv_indev_active());
        if (dir == LV_DIR_LEFT || dir == LV_DIR_RIGHT) {
            if (!_tape_page) { toggle_bank(); tap_feedback(); }
        } else if (dir == LV_DIR_TOP) {
            toggle_play();
            tap_feedback();
        } else if (dir == LV_DIR_BOTTOM) {
            if (_tape_page) {
                midi("TAPESTOP");
                paint_status("TAPE STOP");
                tap_feedback();
            }
        }
    }
}

/* ───────────────────────── App ───────────────────────── */

AppGrooved::AppGrooved()
{
    setAppInfo().name = "Groove D";
    setAppInfo().icon = (void*)&icon_groove_d;
}

void AppGrooved::onCreate()
{
    mclog::tagInfo(getAppInfo().name, "on create");
    midi("HELLO groove-d 4");
}

void AppGrooved::onOpen()
{
    mclog::tagInfo(getAppInfo().name, "on open");
    _key_manager = std::make_unique<input::KeyManager>();

    LvglLockGuard lock;
    destroy_all();
    _tape_page = false;

    lv_obj_t* scr = lv_screen_active();
    lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(scr, lv_color_hex(0x0A0D12), 0);
    lv_obj_set_style_bg_grad_color(scr, lv_color_hex(0x04060A), 0);
    lv_obj_set_style_bg_grad_dir(scr, LV_GRAD_DIR_VER, 0);

    /* 标题 */
    _title = mklabel(scr, "GROOVE D", CX - 90, 16, 180, 24,
                     &lv_font_montserrat_18, 0xE9F0F9, true);
    _sub = mklabel(scr, "PADS / FADERS / TAPE", CX - 90, 40, 180, 14,
                   &lv_font_montserrat_10, 0x7E8998, true);

    /* 电平指示：12 段 */
    for (int i = 0; i < 12; i++) {
        _meter_seg[i] = track(lv_obj_create(scr));
        lv_obj_set_pos(_meter_seg[i], CX - 72 + i * 12, 58);
        lv_obj_set_size(_meter_seg[i], 10, 5);
        lv_obj_set_style_radius(_meter_seg[i], 2, 0);
        lv_obj_set_style_bg_color(_meter_seg[i], lv_color_hex(0x57E39B), 0);
        lv_obj_set_style_bg_opa(_meter_seg[i], 30, 0);
        lv_obj_set_style_border_width(_meter_seg[i], 0, 0);
        lv_obj_clear_flag(_meter_seg[i], LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(_meter_seg[i], LV_OBJ_FLAG_SCROLLABLE);
    }
    paint_meter();

    /* 8 打击垫 */
    for (int i = 0; i < 8; i++) {
        int x = PAD_X0 + (i % PAD_COLS) * PAD_DX;
        int y = PAD_Y0 + (i / PAD_COLS) * PAD_DY;
        _pad[i] = track(lv_obj_create(scr));
        lv_obj_set_pos(_pad[i], x, y);
        lv_obj_set_size(_pad[i], PAD_W, PAD_H);
        lv_obj_set_style_radius(_pad[i], 18, 0);
        lv_obj_set_style_bg_color(_pad[i], lv_color_hex(0x151B24), 0);
        lv_obj_set_style_bg_opa(_pad[i], 245, 0);
        lv_obj_set_style_border_width(_pad[i], 1, 0);
        lv_obj_set_style_border_color(_pad[i], lv_color_hex(PAD_COLORS[i]), 0);
        lv_obj_set_style_border_opa(_pad[i], 150, 0);
        lv_obj_set_user_data(_pad[i], (void*)(intptr_t)i);
        lv_obj_add_event_cb(_pad[i], pad_event_cb, LV_EVENT_PRESSED, nullptr);
        lv_obj_add_event_cb(_pad[i], pad_event_cb, LV_EVENT_RELEASED, nullptr);
        lv_obj_add_event_cb(_pad[i], pad_event_cb, LV_EVENT_PRESS_LOST, nullptr);

        _pad_lbl[i] = mklabel(_pad[i], "", 6, 14, PAD_W - 12, 40,
                              &lv_font_montserrat_14, 0xE8EEF7, false);
        // 固定盒子 + 顶对齐会让两行字看起来"往下偏"；改成内容尺寸再居中。
        lv_obj_set_size(_pad_lbl[i], LV_SIZE_CONTENT, LV_SIZE_CONTENT);
        lv_obj_align(_pad_lbl[i], LV_ALIGN_CENTER, 0, 1);
    }
    paint_pads();

    /* 4 根 CC 小推子 */
    for (int i = 0; i < 4; i++) {
        int cx = FADER_X[i];
        lv_obj_t* trackbg = track(lv_obj_create(scr));
        lv_obj_set_pos(trackbg, cx - 3, FADER_TOP);
        lv_obj_set_size(trackbg, 6, FADER_LEN);
        lv_obj_set_style_radius(trackbg, 3, 0);
        lv_obj_set_style_bg_color(trackbg, lv_color_hex(0x0C1015), 0);
        lv_obj_set_style_bg_opa(trackbg, 235, 0);
        lv_obj_set_style_border_width(trackbg, 1, 0);
        lv_obj_set_style_border_color(trackbg, lv_color_hex(FADER_COLORS[i]), 0);
        lv_obj_set_style_border_opa(trackbg, 55, 0);
        lv_obj_clear_flag(trackbg, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(trackbg, LV_OBJ_FLAG_SCROLLABLE);

        // 刻度：小段白线，让推子有硬件感
        for (int t = 0; t < 5; t++) {
            lv_obj_t* tick = track(lv_obj_create(scr));
            lv_obj_set_pos(tick, cx + 7, FADER_TOP + 6 + t * 23);
            lv_obj_set_size(tick, 7, 1);
            lv_obj_set_style_bg_color(tick, lv_color_hex(0xFFFFFF), 0);
            lv_obj_set_style_bg_opa(tick, 34, 0);
            lv_obj_set_style_border_width(tick, 0, 0);
            lv_obj_clear_flag(tick, LV_OBJ_FLAG_CLICKABLE);
            lv_obj_clear_flag(tick, LV_OBJ_FLAG_SCROLLABLE);
        }

        _fader_fill[i] = track(lv_obj_create(scr));
        lv_obj_set_pos(_fader_fill[i], cx - 3, FADER_TOP + 40);
        lv_obj_set_size(_fader_fill[i], 6, 64);
        lv_obj_set_style_radius(_fader_fill[i], 3, 0);
        lv_obj_set_style_bg_color(_fader_fill[i], lv_color_hex(FADER_COLORS[i]), 0);
        lv_obj_set_style_bg_grad_color(_fader_fill[i], lv_color_hex(FADER_DARK[i]), 0);
        lv_obj_set_style_bg_grad_dir(_fader_fill[i], LV_GRAD_DIR_VER, 0);
        lv_obj_set_style_bg_opa(_fader_fill[i], 235, 0);
        lv_obj_set_style_border_width(_fader_fill[i], 0, 0);
        lv_obj_clear_flag(_fader_fill[i], LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(_fader_fill[i], LV_OBJ_FLAG_SCROLLABLE);

        _fader_cap[i] = track(lv_obj_create(scr));
        lv_obj_set_pos(_fader_cap[i], cx - 13, FADER_TOP + 30);
        lv_obj_set_size(_fader_cap[i], 26, 14);
        lv_obj_set_style_radius(_fader_cap[i], 5, 0);
        lv_obj_set_style_bg_color(_fader_cap[i], lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_bg_grad_color(_fader_cap[i], lv_color_hex(0xC9D4E2), 0);
        lv_obj_set_style_bg_grad_dir(_fader_cap[i], LV_GRAD_DIR_VER, 0);
        lv_obj_set_style_bg_opa(_fader_cap[i], 255, 0);
        lv_obj_set_style_border_width(_fader_cap[i], 1, 0);
        lv_obj_set_style_border_color(_fader_cap[i], lv_color_hex(FADER_DARK[i]), 0);
        lv_obj_set_style_border_opa(_fader_cap[i], 200, 0);
        lv_obj_clear_flag(_fader_cap[i], LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(_fader_cap[i], LV_OBJ_FLAG_SCROLLABLE);

        lv_obj_t* strip = lv_obj_create(_fader_cap[i]);
        lv_obj_set_pos(strip, 4, 5);
        lv_obj_set_size(strip, 18, 3);
        lv_obj_set_style_radius(strip, 2, 0);
        lv_obj_set_style_bg_color(strip, lv_color_hex(FADER_COLORS[i]), 0);
        lv_obj_set_style_bg_opa(strip, 240, 0);
        lv_obj_set_style_border_width(strip, 0, 0);
        lv_obj_clear_flag(strip, LV_OBJ_FLAG_CLICKABLE);

        char nm[8];
        std::snprintf(nm, sizeof(nm), "CC%d", CC_NUMS[i]);
        _fader_name[i] = mklabel(scr, nm, cx - 24, FADER_TOP - 16, 48, 14,
                                 &lv_font_montserrat_10, 0x8A93A0, true);
        _fader_val[i] = mklabel(scr, "64", cx - 24, FADER_TOP + FADER_LEN + 6, 48, 16,
                                &lv_font_montserrat_14, FADER_COLORS[i], true);
        paint_fader(i);
    }

    /* 两个指针盘：左 BPM，右 FX */
    for (int i = 0; i < 2; i++) {
        int cx = DIAL_X[i], cy = DIAL_Y;
        lv_obj_t* base = track(lv_obj_create(scr));
        circle_style(base, cx - DIAL_R, cy - DIAL_R, DIAL_R * 2, 0x10151C, 240);
        lv_obj_set_style_border_width(base, 1, 0);
        lv_obj_set_style_border_color(base, lv_color_hex(0x2A3340), 0);
        lv_obj_set_style_border_opa(base, 255, 0);
        lv_obj_clear_flag(base, LV_OBJ_FLAG_CLICKABLE);

        _dial_arc[i] = track(lv_arc_create(scr));
        lv_obj_set_size(_dial_arc[i], DIAL_R * 2 - 8, DIAL_R * 2 - 8);
        lv_obj_set_pos(_dial_arc[i], cx - DIAL_R + 4, cy - DIAL_R + 4);
        lv_arc_set_bg_angles(_dial_arc[i], 135, 405);
        lv_arc_set_range(_dial_arc[i], 0, (i == 0) ? 200 : 127);
        lv_obj_set_style_arc_width(_dial_arc[i], 4, LV_PART_MAIN);
        lv_obj_set_style_arc_color(_dial_arc[i], lv_color_hex(0xFFFFFF), LV_PART_MAIN);
        lv_obj_set_style_arc_opa(_dial_arc[i], 26, LV_PART_MAIN);
        lv_obj_set_style_arc_width(_dial_arc[i], 4, LV_PART_INDICATOR);
        lv_obj_set_style_arc_color(_dial_arc[i], lv_color_hex(i == 0 ? 0x57E39B : 0x6AA9FF), LV_PART_INDICATOR);
        lv_obj_set_style_bg_opa(_dial_arc[i], LV_OPA_TRANSP, LV_PART_KNOB);
        lv_obj_clear_flag(_dial_arc[i], LV_OBJ_FLAG_CLICKABLE);

        _dial_needle[i] = track(lv_obj_create(scr));
        lv_obj_set_pos(_dial_needle[i], cx - 1, cy - 28);
        lv_obj_set_size(_dial_needle[i], 3, 28);
        lv_obj_set_style_radius(_dial_needle[i], 2, 0);
        lv_obj_set_style_bg_color(_dial_needle[i], lv_color_hex(0xF2F6FC), 0);
        lv_obj_set_style_bg_opa(_dial_needle[i], 245, 0);
        lv_obj_set_style_border_width(_dial_needle[i], 0, 0);
        lv_obj_set_style_transform_pivot_x(_dial_needle[i], 1, 0);
        lv_obj_set_style_transform_pivot_y(_dial_needle[i], 28, 0);
        lv_obj_clear_flag(_dial_needle[i], LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(_dial_needle[i], LV_OBJ_FLAG_SCROLLABLE);

        lv_obj_t* hub = track(lv_obj_create(scr));
        circle_style(hub, cx - 5, cy - 5, 10, 0xF2F6FC, 255);
        lv_obj_clear_flag(hub, LV_OBJ_FLAG_CLICKABLE);

        _dial_lbl[i] = mklabel(scr, i == 0 ? "BPM 120" : "FX 0",
                              cx - 35, cy + DIAL_R + 4, 70, 16,
                              &lv_font_montserrat_14, 0xE8EEF7, true);
        paint_dial(i);
    }

    /* 走带：PLAY / TAP / PANIC */
    static const char* BTN_TXT[3] = { "PLAY", "TAP", "PANIC" };
    static const int BTN_X[3] = { 150, 233, 316 };
    for (int i = 0; i < 3; i++) {
        lv_obj_t* b = track(lv_obj_create(scr));
        circle_style(b, BTN_X[i] - 29, 375, 58, i == 2 ? 0x2A1B1B : 0x1A212B, 245);
        lv_obj_set_style_border_width(b, 1, 0);
        lv_obj_set_style_border_color(b, lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_border_opa(b, 35, 0);
        lv_obj_set_user_data(b, (void*)(intptr_t)i);
        lv_obj_add_event_cb(b, btn_event_cb, LV_EVENT_CLICKED, nullptr);
        lv_obj_t* l = mklabel(b, BTN_TXT[i], 0, 20, 58, 18,
                              &lv_font_montserrat_14, i == 2 ? 0xFF9A9A : 0xE8EEF7, false);
        lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_size(l, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
        lv_obj_align(l, LV_ALIGN_CENTER, 0, 1);
        if (i == 0) { _play_btn = b; _play_lbl = l; }
    }
    paint_play();

    /* 磁带机页：两个卷轴（辐条是卷轴的子对象） */
    static const int REEL_X[2] = { 150, 316 };
    for (int i = 0; i < 2; i++) {
        int d = 132;
        _reel[i] = track(lv_obj_create(scr));
        circle_style(_reel[i], REEL_X[i] - d / 2, 244 - d / 2, d, 0x0E1218, 245);
        lv_obj_set_style_border_width(_reel[i], 2, 0);
        lv_obj_set_style_border_color(_reel[i], lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_border_opa(_reel[i], 70, 0);
        lv_obj_set_style_transform_pivot_x(_reel[i], d / 2, 0);
        lv_obj_set_style_transform_pivot_y(_reel[i], d / 2, 0);
        lv_obj_clear_flag(_reel[i], LV_OBJ_FLAG_CLICKABLE);

        lv_obj_t* hub = lv_obj_create(_reel[i]);
        circle_style(hub, d / 2 - 16, d / 2 - 16, 32, 0x1A212B, 255);
        lv_obj_set_style_border_width(hub, 1, 0);
        lv_obj_set_style_border_color(hub, lv_color_hex(0x57E39B), 0);
        lv_obj_set_style_border_opa(hub, 200, 0);
        lv_obj_clear_flag(hub, LV_OBJ_FLAG_CLICKABLE);

        for (int k = 0; k < 3; k++) {
            lv_obj_t* spoke = lv_obj_create(_reel[i]);
            lv_obj_set_pos(spoke, d / 2 - 26, d / 2 - 2);
            lv_obj_set_size(spoke, 52, 4);
            lv_obj_set_style_radius(spoke, 2, 0);
            lv_obj_set_style_bg_color(spoke, lv_color_hex(0xEFF4FA), 0);
            lv_obj_set_style_bg_opa(spoke, 220, 0);
            lv_obj_set_style_border_width(spoke, 0, 0);
            lv_obj_set_style_transform_pivot_x(spoke, 26, 0);
            lv_obj_set_style_transform_pivot_y(spoke, 2, 0);
            lv_obj_set_style_transform_rotation(spoke, k * 1200, 0);
            lv_obj_clear_flag(spoke, LV_OBJ_FLAG_CLICKABLE);
        }
        lv_obj_add_flag(_reel[i], LV_OBJ_FLAG_HIDDEN);
    }

    _tape_title = mklabel(scr, "TAPE DECK", CX - 90, 150, 180, 26,
                          &lv_font_montserrat_20, 0xE9F0F9, true);
    _tape_counter = mklabel(scr, "TAPE  |  120 BPM", CX - 100, 330, 200, 20,
                            &lv_font_montserrat_14, 0xF2F6FC, true);
    lv_obj_add_flag(_tape_title, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(_tape_counter, LV_OBJ_FLAG_HIDDEN);

    /* 状态行 */
    _status = mklabel(scr, "DOUBLE TAP = TAPE | SWIPE = PLAY", CX - 110, 438, 220, 14,
                      &lv_font_montserrat_10, 0x8A93A0, true);

    lv_obj_add_flag(scr, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(scr, screen_event_cb, LV_EVENT_PRESSED, nullptr);
    lv_obj_add_event_cb(scr, screen_event_cb, LV_EVENT_PRESSING, nullptr);
    lv_obj_add_event_cb(scr, screen_event_cb, LV_EVENT_RELEASED, nullptr);
    lv_obj_add_event_cb(scr, screen_event_cb, LV_EVENT_DOUBLE_CLICKED, nullptr);
    lv_obj_add_event_cb(scr, screen_event_cb, LV_EVENT_GESTURE, nullptr);

    _zone = Z_NONE;
    midi("BPM %d", _bpm);
}

void AppGrooved::onRunning()
{
    grooved_capture_poll_stdin();
    if (_key_manager) {
        auto ev = _key_manager->update();
        if (ev == input::KeyEvent::GoPrevious || ev == input::KeyEvent::GoHome) {
            close();
            return;
        }
        if (ev == input::KeyEvent::GoNext) {
            tap_feedback();
            LvglLockGuard lock;
            toggle_bank();
        }
    }

    int64_t now = esp_timer_get_time();
    if (_playing) {
        const int64_t step = 60000000LL / ((int64_t)_bpm * 24);
        while (now - _last_clock_us >= step) {
            midi("CLOCK");
            _last_clock_us += step;
        }
    }

    // 电平指示衰减（每 80ms 降一点）
    if (now - _level_tick > 80000) {
        _level_tick = now;
        if (_level > 0) {
            _level -= 10;
            if (_level < 0) _level = 0;
            LvglLockGuard lock;
            paint_meter();
        }
    }
}

void AppGrooved::onClose()
{
    mclog::tagInfo(getAppInfo().name, "on close");
    if (_playing) {
        _playing = false;
        midi("STOP");
    }
    _key_manager.reset();

    LvglLockGuard lock;
    destroy_all();

    for (auto& p : _pad) p = nullptr;
    for (auto& p : _pad_lbl) p = nullptr;
    for (auto& p : _fader_fill) p = nullptr;
    for (auto& p : _fader_cap) p = nullptr;
    for (auto& p : _fader_val) p = nullptr;
    for (auto& p : _fader_name) p = nullptr;
    for (auto& p : _dial_arc) p = nullptr;
    for (auto& p : _dial_needle) p = nullptr;
    for (auto& p : _dial_lbl) p = nullptr;
    for (auto& p : _meter_seg) p = nullptr;
    for (auto& p : _reel) p = nullptr;
    _tape_title = nullptr;
    _tape_counter = nullptr;
    _status = nullptr;
    _play_btn = nullptr;
    _play_lbl = nullptr;
    _title = nullptr;
    _sub = nullptr;
    _zone = Z_NONE;
}
