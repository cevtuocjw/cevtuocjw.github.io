#pragma once
#include <lvgl.h>
/* 200×200 RGB565 应用图标 —— 和原厂 Settings/Alarm 同规格：
 * 黑底 + 玻璃质感主体 + 彩色辉光；辉光在图片边缘前收成纯黑（不留方形裁切）。 */

LV_IMG_DECLARE(icon_stem_d);
LV_IMG_DECLARE(icon_groove_d);
LV_IMG_DECLARE(icon_cospon_d);
LV_IMG_DECLARE(icon_muse);
