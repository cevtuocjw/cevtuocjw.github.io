/*
 * Cospon D —— 手表上看 Mac 上正在跑的 agent（数据从 USB 串口来）。
 *
 * 不是 MIDI：它只显示状态。数据由 Mac 的 tools/grooved-serial-midi
 * 每 2 秒写一行 `AG …` / `AGENT …` 到串口。
 */
#pragma once
#include <apps/common/key_manager/key_manager.h>
#include <mooncake.h>
#include <memory>

class AppCospon : public mooncake::AppAbility {
public:
    AppCospon();
    void onCreate() override;
    void onOpen() override;
    void onRunning() override;
    void onClose() override;

private:
    std::unique_ptr<input::KeyManager> _key_manager;
};
