/*
 * Cospon D v2 -- Mac agent 面板（尽量对齐 CrewTower 的会话卡片）。
 *
 * 数据来自 Mac 桥（`tools/grooved-serial-midi`）每 2 秒写来的：
 *   AG <pending> <count>
 *   SESS <agent>|<app>|<state>|<activity>|<tokens>|<limit>|<project>|<age>
 *
 * 为什么读 CrewTower 的 sessions.json 而不是自己挂 hook：
 * CrewTower 已经做了机器级采集（Claude / Codex / DSH，**连 Cherry Studio 里的会话也能看到**），
 * 再挂一套只会得到第二份互不相干的真相。
 *
 * 卡片长这样（466 圆屏，3 张）：
 *   ┌──────────────────────────────┐
 *   │ ● Cherry Studio           3m │
 *   │   claudeCode          Codex  │
 *   │   Find the 8765 server       │
 *   │   [████████░░░░░░] 31%|313k  │
 *   └──────────────────────────────┘
 *
 * ⚠️ 本固件没有 LVGL 主题 ⇒ 所有文字必须显式设色（默认黑色）。
 * ⚠️ 字体没有中文字形 ⇒ 只用英文。
 */
#include "app_cospon.h"
#include "../grooved_icons.h"
#include "../grooved_logos.h"
#include "../grooved_capture.h"
#include <hal/hal.h>
#include <mooncake.h>
#include <mooncake_log.h>
#include <smooth_lvgl.hpp>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <unistd.h>
#include <fcntl.h>
#include <driver/usb_serial_jtag.h>
#include <driver/usb_serial_jtag_vfs.h>
#include <esp_http_client.h>
#include <nvs_flash.h>
#include <nvs.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <strings.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// 中文字体：lv_conf 没在这个项目里声明它，但源文件已经在 LVGL 里编译。
LV_FONT_DECLARE(lv_font_grooved_cjk12);
// 复古点阵字体（LVGL 自带 unscii）。英文标签/数字用它，中文正文仍走 CJK 字体。
LV_FONT_DECLARE(lv_font_unscii_8);
LV_FONT_DECLARE(lv_font_unscii_16);

using namespace mooncake;
using namespace smooth_ui_toolkit::lvgl_cpp;

static const int CX = 233;
static const int SLOTS = 3;
static const int CARD_W = 300, CARD_H = 98;
static const int CARD_X = 83;
static const int CARD_Y[3] = { 56, 162, 268 };

static std::unique_ptr<Label> _title, _sub, _foot;

struct Row {
    lv_obj_t* halo = nullptr;     // 状态灯的光晕
    lv_obj_t* dot = nullptr;      // 状态灯
    lv_obj_t* accent = nullptr;   // 左侧状态色条
    lv_obj_t* app = nullptr;
    lv_obj_t* agent = nullptr;
    lv_obj_t* state = nullptr;    // WORKING / WAITING / IDLE
    lv_obj_t* activity = nullptr;
    lv_obj_t* project = nullptr;
    lv_obj_t* bar_bg = nullptr;
    lv_obj_t* bar_fill = nullptr;
    lv_obj_t* tok = nullptr;
};
static Row _row[SLOTS];

/* 详情浮层：点某张卡放大 */
static int _detail = -1;
static lv_obj_t* _detail_backdrop = nullptr;
static lv_obj_t* _detail_panel = nullptr;
static lv_obj_t* _detail_close = nullptr;
static lv_obj_t* _detail_app = nullptr;
static lv_obj_t* _detail_state = nullptr;
static lv_obj_t* _detail_agent = nullptr;
static lv_obj_t* _detail_meta = nullptr;
static lv_obj_t* _detail_activity = nullptr;
static lv_obj_t* _detail_info = nullptr;
static lv_obj_t* _detail_ring = nullptr;
static lv_obj_t* _detail_pct = nullptr;
static lv_obj_t* _df_n[5] = {};
static lv_obj_t* _df_v[5] = {};

static lv_obj_t* _owned[80];
static int _owned_n = 0;
static lv_obj_t* T(lv_obj_t* o)
{
    if (o && _owned_n < (int)(sizeof(_owned) / sizeof(_owned[0]))) _owned[_owned_n++] = o;
    return o;
}

static char _line[200];
static int _line_len = 0;
static int _waiting = 0, _count = 0;
static int _incoming = 0;
static int64_t _last_rx_ms = 0;
static int64_t _last_snap_ms = 0;

/* 最近 8 条消息（每个会话） */
static char _msgs[SLOTS][8][240];
static int _msg_n[SLOTS] = { 0, 0, 0 };

/* 最近 6 次工具调用：详情里的 STEPS 视图 */
static char _steps[SLOTS][6][200];    // Bash 命令经常 >80 字符；80 会截断，用户看到的就不是完整命令
static int _step_n[SLOTS] = { 0, 0, 0 };
static char _stage_steps[SLOTS][6][200];
static int _stage_step_n[SLOTS] = { 0, 0, 0 };
static int _detail_view = 0;          // 0 = CHAT, 1 = STEPS
static char _center_fp[96] = "";      // 自动居中的指纹，避免每 2 秒把用户滚动位置拉回去

/* 待批请求 + 两个键（ALLOW / DENY） */
static lv_obj_t* _perm_panel = nullptr;
static lv_obj_t* _perm_tool = nullptr;
static lv_obj_t* _perm_detail = nullptr;
static char _perm_id[64] = "";
static lv_obj_t* _detail_msgs = nullptr;
static lv_obj_t* _dm[SLOTS][8] = {};
static lv_obj_t* _ds[6] = {};                 // STEPS 视图的 6 行
static lv_obj_t* _msgs_spacer = nullptr;      // 末尾留白，让最后一条能滚到中线
static lv_obj_t* _detail_pulse = nullptr;     // 呼吸点
static lv_obj_t* _side_l = nullptr, *_side_r = nullptr;
static lv_obj_t* _side_l_cap = nullptr, *_side_r_cap = nullptr;
static lv_obj_t* _side_l_v[3] = {};
static lv_obj_t* _side_r_v[3] = {};

/* WiFi：一个按键 + 一个 Mac 主机名（手机通过 NET 命令发过来） */
static lv_obj_t* _wifi_btn = nullptr;
static lv_obj_t* _wifi_lab = nullptr;
static lv_obj_t* _wifi_btn_lab = nullptr;
static lv_obj_t* _act_continue = nullptr;
static lv_obj_t* _act_handoff = nullptr;
static lv_obj_t* _detail_cap = nullptr;
static char _net_host[64] = "";
static volatile bool _wifi_task_run = false;
static volatile bool _ui_alive = false;
static TaskHandle_t _wifi_task = nullptr;
static void save_net_host(const char* host);
/* Wi-Fi 这条路的健康状态：只有完整快照（收到 END）才算一次成功。
 * 失败原因要能显示出来 —— 不然"没数据"和"链路坏了"在屏幕上一模一样。 */
static int64_t _last_ok_ms = 0;
static char _net_err[48] = "";
/* CONTINUE / HANDOFF 的回执。上一版直接写 _detail_state，而 fill_detail()
 * 每 2 秒就被一次快照调用 —— 回执活不过两秒，用户当然不知道到底成没成。
 * 这里单独存一份并给它一个过期时间，详情和底栏都能看到。 */
static char _act_status[56] = "";
static int64_t _act_until_ms = 0;

static bool act_live()
{
    return _act_status[0] && (esp_timer_get_time() / 1000) < _act_until_ms;
}

static void set_act_status(const char* s, int ms)
{
    std::snprintf(_act_status, sizeof(_act_status), "%s", s && s[0] ? s : "");
    _act_until_ms = esp_timer_get_time() / 1000 + ms;
}

static uint32_t state_color(const char* s)
{
    // ⚠️ 不能区分大小写：bridge 传的是 CrewTower 的原文，实测出现过 Working/WORKING。
    if (strcasecmp(s, "waiting") == 0) return 0xFFC24A;
    if (strcasecmp(s, "working") == 0) return 0xFF5A1F;
    if (strcasecmp(s, "idle") == 0) return 0x8A8275;
    return 0x6AA9FF;
}

static uint32_t agent_color(const char* a)
{
    if (std::strstr(a, "claude")) return 0xFF7A3B;
    if (std::strstr(a, "codex")) return 0x6AA9FF;
    if (std::strstr(a, "dsh") || std::strstr(a, "qwen")) return 0x57E39B;
    return 0x8A93A0;
}

/* 呼吸点：working 时缓慢明暗，其余状态常亮。 */
static void pulse_exec(void* obj, int32_t v)
{
    lv_obj_set_style_bg_opa((lv_obj_t*)obj, (lv_opa_t)v, 0);
}
static bool _pulse_running = false;
static void pulse_start()
{
    if (_pulse_running || !_detail_pulse) return;
    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_var(&a, _detail_pulse);
    lv_anim_set_exec_cb(&a, pulse_exec);
    lv_anim_set_values(&a, 45, 255);
    lv_anim_set_time(&a, 900);
    lv_anim_set_playback_time(&a, 900);
    lv_anim_set_repeat_count(&a, LV_ANIM_REPEAT_INFINITE);
    lv_anim_start(&a);
    _pulse_running = true;
}
static void pulse_stop()
{
    if (!_pulse_running) return;
    lv_anim_del(_detail_pulse, pulse_exec);
    _pulse_running = false;
    if (_detail_pulse) lv_obj_set_style_bg_opa(_detail_pulse, 255, 0);
}

static void set_text(lv_obj_t* l, const char* s)
{
    if (l) lv_label_set_text(l, s);
}

static void paint_footer()
{
    if (!_foot) return;
    char b[96];
    int64_t now = esp_timer_get_time() / 1000;
    // 动作回执优先：用户按完 CONTINUE / HANDOFF 最想知道的就是这一句。
    if (act_live()) {
        std::snprintf(b, sizeof(b), "ACT %.30s", _act_status);
        _foot->setText(b);
        _foot->setTextColor(lv_color_hex(std::strstr(_act_status, "FAIL") ? 0xFF6B6B : 0x7BE0A4));
        return;
    }
    bool live = _last_rx_ms > 0 && (now - _last_rx_ms) < 6000;
    // 不 LIVE 时把**为什么**写出来：NO HOST / CONN FAIL / SHORT。
    // 只说 "NO BRIDGE" 的话，"没配地址" 和 "连不上 Mac" 长得一模一样。
    const char* tail = live ? "LIVE" : (_net_err[0] ? _net_err : "NO BRIDGE");
    std::snprintf(b, sizeof(b), "WAITING %d | TOTAL %d | %s",
                  _waiting, _count, tail);
    _foot->setText(b);
    _foot->setTextColor(lv_color_hex(live ? 0x7BE0A4 : 0xFF9A5C));
}

static void paint_row(int i)
{
    Row& r = _row[i];
    if (!r.dot) return;

    if (i >= _count) {
        if (r.app) lv_label_set_text(r.app, "-");
        if (r.agent) lv_label_set_text(r.agent, "no session");
        if (r.activity) lv_label_set_text(r.activity, "");
        if (r.state) lv_label_set_text(r.state, "");
        if (r.project) lv_label_set_text(r.project, "");
        if (r.tok) lv_label_set_text(r.tok, "");
        if (r.halo) lv_obj_set_style_bg_opa(r.halo, 30, 0);
        lv_obj_set_style_bg_opa(r.dot, 60, 0);
        lv_obj_set_style_bg_color(r.dot, lv_color_hex(0x39414D), 0);
        lv_obj_set_style_bg_opa(r.accent, 60, 0);
        lv_obj_set_style_bg_color(r.accent, lv_color_hex(0x39414D), 0);
        lv_obj_set_width(r.bar_fill, 1);
        return;
    }
}

struct SessionData {
    char agent[40];
    char app[40];
    char state[20];
    char activity[120];
    int tokens;
    int limit;
    char project[40];
    int age;
    int turn_sec;     // 本轮从最后一条 user 消息开始的秒数（右侧 TURN）
    int session_sec;  // 整个会话从开始到现在的秒数（顶部 TOTAL）
};
static SessionData _data[SLOTS];
static bool _filled[SLOTS] = { false, false, false };
/* 一次快照是 AG → SESS* → MSG* → END。全部先写进 stage，END 时一次性提交，
 * 否则每收到一行就重画：卡片会在 activity 和最新消息之间来回跳。 */
static bool _snap = false;
static int _stage_count = 0, _stage_waiting = 0;
static SessionData _stage[SLOTS];
static bool _stage_filled[SLOTS] = { false, false, false };
static char _stage_msgs[SLOTS][8][240];
static int _stage_msg_n[SLOTS] = { 0, 0, 0 };
static char _last_fp[SLOTS][240] = {};

static const char* state_word(const char* st)
{
    if (strcasecmp(st, "working") == 0) return "WORKING";
    if (strcasecmp(st, "waiting") == 0) return "WAITING";
    if (strcasecmp(st, "idle") == 0) return "IDLE";
    return "UNKNOWN";
}

static void fill_detail()
{
    if (_detail < 0 || _detail >= SLOTS || !_detail_panel) return;
    const SessionData& d = _data[_detail];
    uint32_t sc = state_color(d.state);
    uint32_t ac = agent_color(d.agent);

    set_text(_detail_app, d.project[0] ? d.project : (d.agent[0] ? d.agent : "AGENT"));

    int64_t now = esp_timer_get_time() / 1000;
    int elapsed = d.turn_sec > 0 ? d.turn_sec : 0;
    if (_last_snap_ms > 0 && now > _last_snap_ms) elapsed += (int)((now - _last_snap_ms) / 1000);

    char st[64];
    if (act_live()) {
        std::snprintf(st, sizeof(st), "%s", _act_status);
        set_text(_detail_state, st);
        lv_obj_set_style_text_color(_detail_state,
            std::strstr(st, "FAIL") ? lv_color_hex(0xFF6B6B) : lv_color_hex(0x7BE0A4), 0);
    } else {
        // 顶部显示「整个对话的总时长」，右侧 TURN 才是本轮耗时。
        int total = d.session_sec > 0 ? d.session_sec : elapsed;
        char ts[20];
        if (total >= 3600) std::snprintf(ts, sizeof(ts), "%dh%02dm", total / 3600, (total % 3600) / 60);
        else if (total >= 60) std::snprintf(ts, sizeof(ts), "%dm", total / 60);
        else std::snprintf(ts, sizeof(ts), "%ds", total);
        if (std::strcmp(d.state, "working") == 0) std::snprintf(st, sizeof(st), "WORKING  TOTAL %s", ts);
        else if (std::strcmp(d.state, "waiting") == 0) std::snprintf(st, sizeof(st), "WAITING  TOTAL %s", ts);
        else if (std::strcmp(d.state, "idle") == 0) std::snprintf(st, sizeof(st), "IDLE  TOTAL %s", ts);
        else std::snprintf(st, sizeof(st), "UNKNOWN  TOTAL %s", ts);
        set_text(_detail_state, st);
        lv_obj_set_style_text_color(_detail_state, lv_color_hex(sc), 0);
    }

    if (_detail_pulse) {
        if (std::strcmp(d.state, "working") == 0) {
            pulse_start();
            lv_obj_set_style_bg_color(_detail_pulse, lv_color_hex(0xFF5A1F), 0);
        } else {
            pulse_stop();
            lv_obj_set_style_bg_color(_detail_pulse, lv_color_hex(ac), 0);
        }
    }

    /* 左侧：CTX 或 STEPS；点一下切换。 */
    int pct = d.limit > 0 ? (int)((int64_t)d.tokens * 100 / d.limit) : 0;
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    char l0[12], l1[12];
    if (_detail_view == 0) {
        std::snprintf(l0, sizeof(l0), "%d%%", pct);
        if (d.tokens >= 1000) std::snprintf(l1, sizeof(l1), "%dk", d.tokens / 1000);
        else std::snprintf(l1, sizeof(l1), "%d", d.tokens);
        set_text(_side_l_cap, "CHAT");
        set_text(_side_l_v[0], l0);
        set_text(_side_l_v[1], l1);
        set_text(_side_l_v[2], "TAP");
    } else {
        std::snprintf(l0, sizeof(l0), "%d", _step_n[_detail]);
        set_text(_side_l_cap, "STEPS");
        set_text(_side_l_v[0], l0);
        set_text(_side_l_v[1], "TAP");
        set_text(_side_l_v[2], "CHAT");
    }

    /* 右侧：本轮计时；超过一小时显示 h/m。 */
    char r0[12], r1[12];
    if (elapsed >= 3600) {
        std::snprintf(r0, sizeof(r0), "%dh", elapsed / 3600);
        std::snprintf(r1, sizeof(r1), "%dm", (elapsed % 3600) / 60);
    } else {
        std::snprintf(r0, sizeof(r0), "%dm", elapsed / 60);
        std::snprintf(r1, sizeof(r1), "%ds", elapsed % 60);
    }
    set_text(_side_r_v[0], r0);
    set_text(_side_r_v[1], r1);
    set_text(_side_r_v[2], std::strcmp(d.state, "working") == 0 ? "LIVE" : "DONE");

    int slot = _detail;
    bool has = slot >= 0 && slot < SLOTS && _msg_n[slot] > 0;
    int has_steps = _step_n[slot] > 0;

    for (int k = 0; k < 8; k++) {
        lv_obj_t* l = _dm[0][k];
        if (!l) continue;
        if (_detail_view == 0 && has && k < _msg_n[slot]) {
            lv_label_set_text(l, _msgs[slot][k]);
            lv_obj_set_height(l, LV_SIZE_CONTENT);
            lv_obj_remove_flag(l, LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(l, LV_OBJ_FLAG_HIDDEN);
        }
    }
    for (int k = 0; k < 6; k++) {
        lv_obj_t* l = _ds[k];
        if (!l) continue;
        if (_detail_view == 1 && has_steps && k < _step_n[slot]) {
            char b[220];
            // 最新的一条放在最上面：长 Bash 命令换行后会超过一屏，
            // 放底部时最后一行会被容器裁掉，用户得自己拖。倒序后第一屏就是最新的。
            int src = _step_n[slot] - 1 - k;
            std::snprintf(b, sizeof(b), "> %s", _steps[slot][src]);
            lv_label_set_text(l, b);
            // 文本换了之后必须重新声明 LV_SIZE_CONTENT：mkcard_label 创建时给的是
            // 固定高度 30，只在创建时设一次的话长命令会停在 3 行、后面被裁掉。
            lv_obj_set_height(l, LV_SIZE_CONTENT);
            lv_obj_remove_flag(l, LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(l, LV_OBJ_FLAG_HIDDEN);
        }
    }

    // 末尾留白：内容比容器高时，最后一条也能滚到中线。
    if (_msgs_spacer) {
        lv_obj_set_height(_msgs_spacer, lv_obj_get_height(_detail_msgs) / 2);
    }

    /* 最新一条对话放在中段偏下，而不是永远贴底。
     * 内容比容器矮时用 pad_top 把它推下来；比容器高时滚动到最后一条。
     * 只在内容真的变了的时候调整 —— 否则用户一滚就被拉回去。 */
    if (_detail_view == 0 && has) {
        char fp[96];
        std::snprintf(fp, sizeof(fp), "%d|%s", _msg_n[slot], _msgs[slot][_msg_n[slot] - 1]);
        if (std::strcmp(fp, _center_fp) != 0) {
            std::snprintf(_center_fp, sizeof(_center_fp), "%s", fp);
            lv_obj_update_layout(_detail_msgs);
            int total = 0, nvis = 0;
            for (int k = 0; k < 8; k++) {
                if (!lv_obj_has_flag(_dm[0][k], LV_OBJ_FLAG_HIDDEN)) {
                    total += lv_obj_get_height(_dm[0][k]) + (nvis ? 7 : 0);
                    nvis++;
                }
            }
            int H = lv_obj_get_height(_detail_msgs);
            int pad = 0;
            if (total < H) pad = (H - total) / 2 + H / 10;
            lv_obj_set_style_pad_top(_detail_msgs, pad, 0);
            lv_obj_update_layout(_detail_msgs);
            if (total < H) {
                lv_obj_scroll_to_y(_detail_msgs, 0, LV_ANIM_OFF);
            } else {
                lv_obj_t* last = _dm[0][_msg_n[slot] - 1];
                // 先保证最新一条完整可见，再做居中；长消息不会被容器底边裁掉。
                lv_obj_scroll_to_view(last, LV_ANIM_OFF);
                lv_area_t a, c;
                lv_obj_get_coords(last, &a);
                lv_obj_get_coords(_detail_msgs, &c);
                // scroll_to_y 收的是「内容坐标」，不是相对当前位置的增量。
                // 不加当前 scroll_y 的话，列表已经滚过一段时会把最后一条推到最底部。
                int y = lv_obj_get_scroll_y(_detail_msgs) + (a.y1 + a.y2) / 2 - c.y1 - H / 2;
                if (y < 0) y = 0;
                lv_obj_scroll_to_y(_detail_msgs, y, LV_ANIM_OFF);
            }
        }
    } else if (_detail_view == 1) {
        // 倒序后 _ds[0] 就是最新一条。用 pad_top 把这一条的**中心**顶到容器中线，
        // 既不用滚动计算，也不会因为长 Bash 换行而把最后一行裁掉。
        int H = lv_obj_get_height(_detail_msgs);
        int pad = 0;
        if (slot >= 0 && _step_n[slot] > 0) {
            lv_obj_update_layout(_detail_msgs);
            int fh = lv_obj_get_height(_ds[0]);
            pad = H / 2 - fh / 2;
            if (pad < 0) pad = 0;
        }
        lv_obj_set_style_pad_top(_detail_msgs, pad, 0);
        lv_obj_update_layout(_detail_msgs);
        lv_obj_scroll_to_y(_detail_msgs, 0, LV_ANIM_OFF);
    }

    bool idle = std::strcmp(d.state, "idle") == 0;
    if (_act_continue) {
        if (idle) lv_obj_remove_flag(_act_continue, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(_act_continue, LV_OBJ_FLAG_HIDDEN);
    }
    if (_act_handoff) {
        if (idle) lv_obj_remove_flag(_act_handoff, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(_act_handoff, LV_OBJ_FLAG_HIDDEN);
    }
}

static void view_cb(lv_event_t* e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    _detail_view = _detail_view ? 0 : 1;
    _center_fp[0] = 0;
    fill_detail();
    lv_event_stop_bubbling(e);
}

static void hide_detail()
{
    _detail = -1;
    pulse_stop();
    if (_detail_panel) lv_obj_add_flag(_detail_panel, LV_OBJ_FLAG_HIDDEN);
    if (_detail_backdrop) lv_obj_add_flag(_detail_backdrop, LV_OBJ_FLAG_HIDDEN);
    if (_foot) lv_obj_remove_flag(_foot->get(), LV_OBJ_FLAG_HIDDEN);
    if (_wifi_btn) lv_obj_remove_flag(_wifi_btn, LV_OBJ_FLAG_HIDDEN);
    if (_wifi_lab) lv_obj_remove_flag(_wifi_lab, LV_OBJ_FLAG_HIDDEN);
    if (_title) lv_obj_remove_flag(_title->get(), LV_OBJ_FLAG_HIDDEN);
    if (_sub) lv_obj_remove_flag(_sub->get(), LV_OBJ_FLAG_HIDDEN);
}

static void show_detail(int slot)
{
    if (slot < 0 || slot >= SLOTS || slot >= _count) return;
    _detail = slot;
    _detail_view = 1;   // 默认先看 AI 的过程，点左侧切回 CHAT
    _center_fp[0] = 0;
    fill_detail();
    if (_detail_backdrop) {
        lv_obj_remove_flag(_detail_backdrop, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_foreground(_detail_backdrop);
    }
    if (_detail_panel) {
        lv_obj_remove_flag(_detail_panel, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_foreground(_detail_panel);
    }
    if (_foot) lv_obj_add_flag(_foot->get(), LV_OBJ_FLAG_HIDDEN);
    if (_wifi_btn) lv_obj_add_flag(_wifi_btn, LV_OBJ_FLAG_HIDDEN);
    if (_wifi_lab) lv_obj_add_flag(_wifi_lab, LV_OBJ_FLAG_HIDDEN);
    if (_title) lv_obj_add_flag(_title->get(), LV_OBJ_FLAG_HIDDEN);
    if (_sub) lv_obj_add_flag(_sub->get(), LV_OBJ_FLAG_HIDDEN);
    GetHAL().vibrate(20, 80);
}

static void card_cb(lv_event_t* e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    show_detail((int)(intptr_t)lv_obj_get_user_data((lv_obj_t*)lv_event_get_target(e)));
}

static void detail_cb(lv_event_t* e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    // 只点背景才关；按钮/列表的点击即使冒泡过来也不关。
    if (lv_event_get_target(e) != _detail_panel) return;
    hide_detail();
}

static void close_cb(lv_event_t* e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    hide_detail();
    lv_event_stop_bubbling(e);
}

/* 消息列表自己滚，不要把点击/滚动冒泡给详情面板（否则一滚就关） */
static void stop_bubble_cb(lv_event_t* e) { lv_event_stop_bubbling(e); }

/* ── 待批请求：两个键（ALLOW / DENY）── */
static void hide_perm()
{
    _perm_id[0] = 0;
    if (_perm_panel) lv_obj_add_flag(_perm_panel, LV_OBJ_FLAG_HIDDEN);
}

static void send_perm(const char* behavior)
{
    if (!_perm_id[0]) return;
    std::printf("G1 PERM %s %s\n", _perm_id, behavior);
    std::fflush(stdout);
    GetHAL().vibrate(30, 80);
    hide_perm();
}

static void action_cb(lv_event_t* e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    if (_detail < 0) return;
    int act = (int)(intptr_t)lv_event_get_user_data(e);
    std::printf("G1 ACTION %d %s\n", _detail, act ? "handoff" : "continue");
    std::fflush(stdout);
    GetHAL().vibrate(40, 90);
    set_act_status(act ? "HANDOFF..." : "CONTINUE...", 20000);
    if (_detail_state) {
        set_text(_detail_state, _act_status);
        lv_obj_set_style_text_color(_detail_state, lv_color_hex(0x7BE0A4), 0);
    }
    paint_footer();
    lv_event_stop_bubbling(e);
}

static void perm_allow_cb(lv_event_t* e)
{
    if (lv_event_get_code(e) == LV_EVENT_CLICKED) send_perm("allow");
}
static void perm_deny_cb(lv_event_t* e)
{
    if (lv_event_get_code(e) == LV_EVENT_CLICKED) send_perm("deny");
}

static void show_perm(const char* id, const char* tool, const char* detail)
{
    if (!_perm_panel || !id || !id[0]) return;
    bool same = std::strcmp(_perm_id, id) == 0;
    std::snprintf(_perm_id, sizeof(_perm_id), "%s", id);
    set_text(_perm_tool, tool && tool[0] ? tool : "PERMISSION");
    set_text(_perm_detail, detail && detail[0] ? detail : "(no detail)");
    lv_obj_remove_flag(_perm_panel, LV_OBJ_FLAG_HIDDEN);
    lv_obj_move_foreground(_perm_panel);
    if (!same) GetHAL().vibrate(60, 90);
}

static void apply_row(int i)
{
    if (i < 0 || i >= SLOTS) return;
    const SessionData& d = _data[i];
    Row& r = _row[i];
    if (!r.dot) return;

    uint32_t sc = state_color(d.state);
    uint32_t ac = agent_color(d.agent);

    lv_obj_set_style_bg_color(r.dot, lv_color_hex(sc), 0);
    lv_obj_set_style_bg_opa(r.dot, 255, 0);
    if (r.halo) {
        lv_obj_set_style_bg_color(r.halo, lv_color_hex(sc), 0);
        lv_obj_set_style_bg_opa(r.halo, 70, 0);
    }
    lv_obj_set_style_bg_color(r.accent, lv_color_hex(sc), 0);
    lv_obj_set_style_bg_opa(r.accent, 230, 0);

    // 卡片标题用项目名（如 Codex），副标题用 agent；**不显示宿主 App 名**。
    set_text(r.app, d.project[0] ? d.project : (d.agent[0] ? d.agent : "AGENT"));
    set_text(r.agent, d.agent[0] ? d.agent : "unknown");
    // 卡片优先显示**最新一条消息**（用户能在手表上直接读到 AI 说了什么）；
    // 没有消息时才退回 activity。两者不会每 2 秒互相覆盖。
    const char* latest = _msg_n[i] > 0 ? _msgs[i][_msg_n[i] - 1]
        : (d.activity[0] ? d.activity
        : (std::strcmp(d.state, "working") == 0 ? "working..." : d.state));
    set_text(r.activity, latest);
    lv_obj_set_style_text_color(r.agent, lv_color_hex(ac), 0);

    const char* sw = "?";
    if (std::strcmp(d.state, "working") == 0) sw = "WORKING";
    else if (std::strcmp(d.state, "waiting") == 0) sw = "WAITING";
    else if (std::strcmp(d.state, "idle") == 0) sw = "IDLE";
    // 卡片上也带一眼能看到的耗时（详情里有精确到秒的计时）。
    if (std::strcmp(d.state, "working") == 0 && d.turn_sec > 0) {
        char swb[24];
        if (d.turn_sec >= 3600) std::snprintf(swb, sizeof(swb), "%s %dh", sw, d.turn_sec / 3600);
        else std::snprintf(swb, sizeof(swb), "%s %dm", sw, d.turn_sec / 60);
        set_text(r.state, swb);
    } else {
        set_text(r.state, sw);
    }
    lv_obj_set_style_text_color(r.state, lv_color_hex(sc), 0);
    {
        char age_s[16];
        if (d.age < 0) age_s[0] = 0;
        else if (d.age < 60) std::snprintf(age_s, sizeof(age_s), "now");
        else if (d.age < 3600) std::snprintf(age_s, sizeof(age_s), "%dm", d.age / 60);
        else std::snprintf(age_s, sizeof(age_s), "%dh", d.age / 3600);
        set_text(r.project, age_s);
    }

    int pct = 0;
    if (d.limit > 0) pct = (int)((int64_t)d.tokens * 100 / d.limit);
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;

    int w = 160 * pct / 100;
    if (w < 1) w = 1;
    lv_obj_set_width(r.bar_fill, w);
    lv_obj_set_style_bg_color(r.bar_fill, lv_color_hex(ac), 0);

    if (d.limit > 0) {
        char b[24];
        if (d.limit >= 1000000) {
            std::snprintf(b, sizeof(b), "%d%% | %dk/%.1fM", pct, d.tokens / 1000, d.limit / 1000000.0);
        } else {
            std::snprintf(b, sizeof(b), "%d%% | %dk/%dk", pct, d.tokens / 1000, d.limit / 1000);
        }
        set_text(r.tok, b);
    } else {
        set_text(r.tok, "");
    }

    _filled[i] = true;
    if (_detail == i) fill_detail();
}


/* ⚠️ 表上的 Montserrat 没有中文/全角/花式标点。CrewTower 的活动文本里经常有
 * `Thinking…`、中文、弯引号 —— 直接显示就是一个个小方框（缺字）。
 * 这里把常见标点映射成 ASCII，其余非 ASCII 码点整段跳过，保证永远不出现方框。 */
static void asciiize(char* s)
{
    char* w = s;
    unsigned char* p = (unsigned char*)s;
    while (*p) {
        if (*p < 0x80) { *w++ = (char)*p++; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0xA6) { *w++='.'; *w++='.'; *w++='.'; p += 3; continue; }
        if (p[0] == 0xC2 && p[1] == 0xB7) { *w++='|'; p += 2; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0x94) { *w++='-'; p += 3; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0x98) { *w++='\''; p += 3; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0x99) { *w++='\''; p += 3; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0x9C) { *w++='"'; p += 3; continue; }
        if (p[0] == 0xE2 && p[1] == 0x80 && p[2] == 0x9D) { *w++='"'; p += 3; continue; }
        int len = 1;
        if ((p[0] & 0xE0) == 0xC0) len = 2;
        else if ((p[0] & 0xF0) == 0xE0) len = 3;
        else if ((p[0] & 0xF8) == 0xF0) len = 4;
        p += len;
        *w++ = ' ';
    }
    *w = 0;
}

static void handle_line(char* line)
{
    if (std::strncmp(line, "CAP ", 4) == 0) { grooved_capture_line(line); return; }
    // 详情浮层只从卡片点击进入。录制那轮的 `DETAIL n` 串口命令已经撤掉：
    // 它是一条只对录制有用的后门，留着等于多一条绕过点击的外部入口。
    if (std::strncmp(line, "AG ", 3) == 0) {
        int p = 0, c = 0;
        std::sscanf(line + 3, "%d %d", &p, &c);
        _stage_waiting = p;
        _stage_count = c;
        _snap = true;
        _incoming = 0;
        for (int i = 0; i < SLOTS; i++) {
            _stage_filled[i] = false;
            _stage_msg_n[i] = 0;
            _stage_step_n[i] = 0;
        }
        return;
    }

    /* 一次快照的结束标记：这时才把 stage 提交到屏幕，避免 activity / 消息来回跳。 */
    if (std::strncmp(line, "END", 3) == 0) {
        _waiting = _stage_waiting;
        _count = _stage_count;
        for (int i = 0; i < SLOTS; i++) {
            if (i < _count && _stage_filled[i]) {
                _data[i] = _stage[i];
                _msg_n[i] = _stage_msg_n[i];
                for (int k = 0; k < 8; k++) {
                    std::snprintf(_msgs[i][k], sizeof(_msgs[i][k]), "%s", _stage_msgs[i][k]);
                }
                _step_n[i] = _stage_step_n[i];
                for (int k = 0; k < 6; k++) {
                    std::snprintf(_steps[i][k], sizeof(_steps[i][k]), "%s", _stage_steps[i][k]);
                }
                apply_row(i);
            } else {
                _msg_n[i] = 0;
                _filled[i] = false;
                paint_row(i);
            }
        }
        _last_snap_ms = esp_timer_get_time() / 1000;
        paint_footer();
        if (_detail >= 0) fill_detail();
        _snap = false;
        return;
    }

    if (std::strncmp(line, "ACT ", 4) == 0) {
        const char* p = line + 4;
        const char* sp = std::strchr(p, ' ');
        if (sp) p = sp + 1;
        // 回执至少留 20 秒，并在底栏也显示 —— 用户经常在详情关掉后才看结果。
        set_act_status(p, 20000);
        if (_detail_state) {
            set_text(_detail_state, p);
            lv_obj_set_style_text_color(_detail_state,
                std::strstr(p, "FAIL") ? lv_color_hex(0xFF6B6B) : lv_color_hex(0x7BE0A4), 0);
        }
        paint_footer();
        return;
    }

    if (std::strncmp(line, "SESS ", 5) == 0) {
        char* p = line + 5;
        char* fields[10] = {};
        int n = 0;
        fields[n++] = p;
        while (n < 10) {
            char* bar = std::strchr(p, '|');
            if (!bar) break;
            *bar = 0;
            p = bar + 1;
            fields[n++] = p;
        }
        if (n < 4) return;

        int slot = _incoming++ % SLOTS;
        SessionData& d = _snap ? _stage[slot] : _data[slot];
        std::snprintf(d.agent, sizeof(d.agent), "%s", fields[0]);
        std::snprintf(d.app, sizeof(d.app), "%s", fields[1]);
        std::snprintf(d.state, sizeof(d.state), "%s", fields[2]);
        std::snprintf(d.activity, sizeof(d.activity), "%s", fields[3]);
        d.tokens = n > 4 ? std::atoi(fields[4]) : 0;
        d.limit = n > 5 ? std::atoi(fields[5]) : 0;
        std::snprintf(d.project, sizeof(d.project), "%s", n > 6 ? fields[6] : "");
        d.age = n > 7 ? std::atoi(fields[7]) : -1;
        d.turn_sec = n > 8 ? std::atoi(fields[8]) : 0;
        d.session_sec = n > 9 ? std::atoi(fields[9]) : 0;
        // 只把 ASCII 字段做 asciiize；activity 可能是中文，交给 CJK 字体显示。
        asciiize(d.agent); asciiize(d.app); asciiize(d.state); asciiize(d.project);
        char fp[240];
        std::snprintf(fp, sizeof(fp), "%s|%s|%s|%d", d.app, d.state, d.activity, d.tokens);
        if (std::strcmp(fp, _last_fp[slot]) != 0) {
            std::snprintf(_last_fp[slot], sizeof(_last_fp[slot]), "%s", fp);
            if (!grooved_capture_active()) {
                std::printf("C_SESS %s\n", fp);
                std::fflush(stdout);
            }
        }
        if (_snap) {
            _stage_filled[slot] = true;
        } else {
            apply_row(slot);
        }
        return;
    }

    if (std::strncmp(line, "STEP ", 5) == 0) {
        char* p = line + 5;
        char* bar = std::strchr(p, '|');
        if (!bar) return;
        *bar = 0;
        int slot = std::atoi(p);
        if (slot < 0 || slot >= SLOTS) return;
        const char* text = bar + 1;
        char (*dst)[200] = _snap ? _stage_steps[slot] : _steps[slot];
        int& n = _snap ? _stage_step_n[slot] : _step_n[slot];
        if (n < 6) {
            std::snprintf(dst[n], sizeof(dst[0]), "%s", text);
            n++;
        } else {
            for (int k = 0; k < 5; k++) std::snprintf(dst[k], sizeof(dst[0]), "%s", dst[k + 1]);
            std::snprintf(dst[5], sizeof(dst[0]), "%s", text);
        }
        if (!_snap && _detail == slot) fill_detail();
        return;
    }

    if (std::strncmp(line, "MSG ", 4) == 0) {
        char* p = line + 4;
        char* b1 = std::strchr(p, '|');
        if (!b1) return;
        *b1 = 0;
        int slot = std::atoi(p);
        char* role = b1 + 1;
        char* b2 = std::strchr(role, '|');
        if (!b2) return;
        *b2 = 0;
        const char* text = b2 + 1;
        if (slot < 0 || slot >= SLOTS) return;
        // 角色名短一点，中文也用 CJK 字体（Montserrat 没有中文）。
        const char* who = std::strcmp(role, "user") == 0 ? "你"
                        : std::strcmp(role, "assistant") == 0 ? "AI"
                        : role;
        char (*msgs)[240] = _snap ? _stage_msgs[slot] : _msgs[slot];
        int& n = _snap ? _stage_msg_n[slot] : _msg_n[slot];
        if (n < 8) {
            std::snprintf(msgs[n], sizeof(msgs[0]), "%s: %s", who, text);
            n++;
        } else {
            for (int k = 0; k < 7; k++)
                std::snprintf(msgs[k], sizeof(msgs[0]), "%s", msgs[k + 1]);
            std::snprintf(msgs[7], sizeof(msgs[0]), "%s: %s", who, text);
        }
        if (_snap) return;
        apply_row(slot);
        if (_detail == slot) fill_detail();
        return;
    }

    if (std::strncmp(line, "PERM ", 5) == 0) {
        if (std::strcmp(line + 5, "-") == 0) {
            hide_perm();
            return;
        }
        char* p = line + 5;
        char* b1 = std::strchr(p, '|');
        if (!b1) return;
        *b1 = 0;
        char* tool = b1 + 1;
        char* b2 = std::strchr(tool, '|');
        if (!b2) return;
        *b2 = 0;
        const char* det = b2 + 1;
        asciiize(p); asciiize(tool);
        show_perm(p, tool, det);
        return;
    }

    if (std::strncmp(line, "NET ", 4) == 0) {
        std::snprintf(_net_host, sizeof(_net_host), "%s", line + 4);
        save_net_host(_net_host);
        return;
    }

    // 兼容旧协议
    if (std::strncmp(line, "AGENT ", 6) == 0) {
        char* rest = line + 6;
        char* bar1 = std::strchr(rest, '|');
        if (!bar1) return;
        *bar1 = 0;
        char* bar2 = std::strchr(bar1 + 1, '|');
        if (!bar2) return;
        *bar2 = 0;

        int slot = _incoming++ % SLOTS;
        SessionData& d = _data[slot];
        std::snprintf(d.state, sizeof(d.state), "%s", rest);
        std::snprintf(d.app, sizeof(d.app), "%s", bar1 + 1);
        std::snprintf(d.agent, sizeof(d.agent), "%s", "agent");
        std::snprintf(d.activity, sizeof(d.activity), "%s", bar2 + 1);
        d.tokens = 0; d.limit = 0;
        std::snprintf(d.project, sizeof(d.project), "%s", "");
        d.age = -1;
        asciiize(d.agent); asciiize(d.app); asciiize(d.state); asciiize(d.project);
        apply_row(slot);
    }
}

static lv_obj_t* mkcard_label(lv_obj_t* parent, int x, int y, int w, int h,
                              const lv_font_t* font, uint32_t color,
                              lv_text_align_t align)
{
    lv_obj_t* l = lv_label_create(parent);
    lv_obj_set_pos(l, x, y);
    lv_obj_set_size(l, w, h);
    lv_label_set_text(l, "");
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(color), 0);
    lv_obj_set_style_text_align(l, align, 0);
    lv_obj_clear_flag(l, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(l, LV_OBJ_FLAG_SCROLLABLE);
    return l;
}

/* ── WiFi：NVS 里保存 Mac 主机名（手机通过 NET 命令发来）── */
static void load_net_host()
{
    nvs_handle_t h;
    esp_err_t e = nvs_open("grooved", NVS_READONLY, &h);
    if (e == ESP_ERR_NVS_NOT_INITIALIZED) {
        nvs_flash_init();
        e = nvs_open("grooved", NVS_READONLY, &h);
    }
    if (e == ESP_OK) {
        size_t len = sizeof(_net_host);
        if (nvs_get_str(h, "net", _net_host, &len) != ESP_OK) _net_host[0] = 0;
        nvs_close(h);
    }
}

static void save_net_host(const char* host)
{
    nvs_handle_t h;
    esp_err_t e = nvs_open("grooved", NVS_READWRITE, &h);
    if (e == ESP_ERR_NVS_NOT_INITIALIZED) {
        nvs_flash_init();
        e = nvs_open("grooved", NVS_READWRITE, &h);
    }
    if (e == ESP_OK) {
        nvs_set_str(h, "net", host);
        nvs_commit(h);
        nvs_close(h);
    }
}

static void wifi_poll_task(void*)
{
    /* ⚠️ 这里原来只 read 一次 4095 字节 —— 那是一个会**静默**吃掉整个 Wi-Fi 链路的 bug：
     * /api/agents/watch 的响应是 3 个会话 × 最多 8 条消息，实测可以超过 6KB。
     * 单次 read 只拿到前 4KB，`END` 落在后面 ⇒ 固件永远不提交快照 ⇒
     * Wi-Fi 明明连上了，COSPON D 却一直什么都不显示（USB 那条路是逐行写串口，所以没事）。
     * 现在按块读满整个响应体，再一次性解析。 */
    static char body[16384];
    int udp = -1;
    int64_t last_who = 0;
    while (_wifi_task_run) {
        auto st = GetHAL().getWifiStatus();

        /* Wi-Fi 下自动找 Mac：广播 `GROOVED?`，Mac 的 UDP 41234 回 `GROOVED <ip> <port>`。
         * 这样换地方、Mac 的 DHCP 地址变了，也不用再回手机点“发送 Mac 地址”。 */
        if (st.connected) {
            if (udp < 0) {
                udp = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
                if (udp >= 0) {
                    int on = 1;
                    setsockopt(udp, SOL_SOCKET, SO_BROADCAST, &on, sizeof(on));
                    int fl = fcntl(udp, F_GETFL, 0);
                    fcntl(udp, F_SETFL, fl | O_NONBLOCK);
                }
            }
            if (udp >= 0 && (!_net_host[0] || _net_err[0])) {
                int64_t now = esp_timer_get_time() / 1000;
                if (now - last_who > 4000) {
                    last_who = now;
                    struct sockaddr_in to = {};
                    to.sin_family = AF_INET;
                    to.sin_port = htons(41234);
                    to.sin_addr.s_addr = htonl(INADDR_BROADCAST);
                    const char* q = "GROOVED?\n";
                    sendto(udp, q, std::strlen(q), 0, (struct sockaddr*)&to, sizeof(to));
                }
                for (int i = 0; i < 4; i++) {
                    char rb[96];
                    struct sockaddr_in from;
                    socklen_t fl = sizeof(from);
                    int r = recvfrom(udp, rb, sizeof(rb) - 1, 0, (struct sockaddr*)&from, &fl);
                    if (r <= 0) break;
                    rb[r] = 0;
                    char ip[40] = "";
                    if (std::sscanf(rb, "GROOVED %39s", ip) == 1 && ip[0]) {
                        std::snprintf(_net_host, sizeof(_net_host), "%s", ip);
                        save_net_host(_net_host);
                        _net_err[0] = 0;
                        _last_ok_ms = 0;
                        last_who = 0;
                        break;
                    }
                }
            }
        }

        if (st.connected && _net_host[0]) {
            char url[128];
            std::snprintf(url, sizeof(url), "http://%s:8765/api/agents/watch", _net_host);
            esp_http_client_config_t cfg = {};
            cfg.url = url;
            cfg.timeout_ms = 3000;
            esp_http_client_handle_t cli = esp_http_client_init(&cfg);
            if (cli) {
                if (esp_http_client_open(cli, 0) == ESP_OK) {
                    esp_http_client_fetch_headers(cli);
                    int total = 0;
                    while (total < (int)sizeof(body) - 1) {
                        int n = esp_http_client_read(cli, body + total, sizeof(body) - 1 - total);
                        if (n <= 0) break;
                        total += n;
                        if (esp_http_client_is_complete_data_received(cli)) break;
                    }
                    if (total > 0 && _ui_alive) {
                        body[total] = 0;
                        LvglLockGuard lock;
                        _snap = false;   // 只认这一份响应里的 AG…END
                        char* save = nullptr;
                        char* line = strtok_r(body, "\n", &save);
                        while (line) {
                            handle_line(line);
                            line = strtok_r(nullptr, "\n", &save);
                        }
                        _last_rx_ms = esp_timer_get_time() / 1000;
                        // handle_line 只在看到 END 时才把 _snap 关掉。
                        if (_snap) {
                            std::snprintf(_net_err, sizeof(_net_err), "%s", "SHORT");
                        } else {
                            _net_err[0] = 0;
                            _last_ok_ms = _last_rx_ms;
                        }
                    } else {
                        std::snprintf(_net_err, sizeof(_net_err), "%s", total ? "UI OFF" : "EMPTY");
                    }
                    esp_http_client_close(cli);
                } else {
                    std::snprintf(_net_err, sizeof(_net_err), "%s", "CONN FAIL");
                }
                esp_http_client_cleanup(cli);
            }
        } else if (st.connected) {
            std::snprintf(_net_err, sizeof(_net_err), "%s", "NO HOST");
        } else {
            _net_err[0] = 0;
        }
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
    if (udp >= 0) close(udp);
    _wifi_task = nullptr;
    vTaskDelete(nullptr);
}

static void wifi_cb(lv_event_t* e)
{
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    auto st = GetHAL().getWifiStatus();
    bool on = st.enabled || st.mode != Hal::WifiMode::Off;
    if (on) {
        // 关：断开站点/配置 AP，轮询任务会自然停在 connected=false。
        GetHAL().setWifiEnabled(false);
        if (_wifi_lab) lv_label_set_text(_wifi_lab, "WIFI OFF");
        if (_wifi_btn_lab) lv_label_set_text(_wifi_btn_lab, "WIFI ON");
    } else {
        GetHAL().setWifiEnabled(true);
        if (_wifi_lab) lv_label_set_text(_wifi_lab, "WIFI ON...");
        if (_wifi_btn_lab) lv_label_set_text(_wifi_btn_lab, "WIFI OFF");
    }
    GetHAL().vibrate(30, 80);
}

AppCospon::AppCospon()
{
    setAppInfo().name = "Cospon D";
    setAppInfo().icon = (void*)&icon_cospon_d;
}

void AppCospon::onCreate()
{
    mclog::tagInfo(getAppInfo().name, "on create");
    std::printf("C1 HELLO cospon 2\n");
}

void AppCospon::onOpen()
{
    mclog::tagInfo(getAppInfo().name, "on open");
    _key_manager = std::make_unique<input::KeyManager>();

    // 和 Stem 一样：console VFS 的 read 收不到主机写入，必须走 USB Serial/JTAG 驱动。
    usb_serial_jtag_driver_config_t cfg = USB_SERIAL_JTAG_DRIVER_CONFIG_DEFAULT();
    cfg.rx_buffer_size = 2048;
    cfg.tx_buffer_size = 1024;
    esp_err_t ierr = usb_serial_jtag_driver_install(&cfg);
    if (ierr == ESP_OK || ierr == ESP_ERR_INVALID_STATE) {
    }
    int fl = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, fl | O_NONBLOCK);
    _line_len = 0;

    LvglLockGuard lock;

    lv_obj_t* scr = lv_screen_active();
    lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(scr, lv_color_hex(0x080A0D), 0);
    lv_obj_set_style_bg_grad_color(scr, lv_color_hex(0x030405), 0);
    lv_obj_set_style_bg_grad_dir(scr, LV_GRAD_DIR_VER, 0);

    _title = std::make_unique<Label>(scr);
    _title->setPos(CX - 80, 14);
    _title->setSize(160, 20);
    _title->setTextAlign(LV_TEXT_ALIGN_CENTER);
    _title->setText("COSPON D");
    _title->setTextFont(&lv_font_unscii_16);
    _title->setTextColor(lv_color_hex(0xEFE9DA));

    _sub = std::make_unique<Label>(scr);
    _sub->setPos(CX - 100, 38);
    _sub->setSize(200, 12);
    _sub->setTextAlign(LV_TEXT_ALIGN_CENTER);
    _sub->setText("M A C   /   A G E N T S");
    _sub->setTextFont(&lv_font_unscii_8);
    _sub->setTextColor(lv_color_hex(0x6F756F));

    for (int i = 0; i < SLOTS; i++) {
        Row& r = _row[i];
        int y = CARD_Y[i];

        lv_obj_t* card = T(lv_obj_create(scr));
        lv_obj_set_pos(card, CARD_X, y);
        lv_obj_set_size(card, CARD_W, CARD_H);
        lv_obj_set_style_radius(card, 16, 0);
        lv_obj_set_style_bg_color(card, lv_color_hex(0x0C1015), 0);
        lv_obj_set_style_bg_opa(card, 255, 0);
        lv_obj_set_style_border_width(card, 1, 0);
        lv_obj_set_style_border_color(card, lv_color_hex(0x252C35), 0);
        lv_obj_set_style_border_opa(card, 255, 0);
        lv_obj_add_flag(card, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_user_data(card, (void*)(intptr_t)i);
        lv_obj_add_event_cb(card, card_cb, LV_EVENT_CLICKED, nullptr);

        r.accent = T(lv_obj_create(scr));
        lv_obj_set_pos(r.accent, CARD_X + 1, y + 12);
        lv_obj_set_size(r.accent, 4, CARD_H - 24);
        lv_obj_set_style_radius(r.accent, 2, 0);
        lv_obj_set_style_bg_color(r.accent, lv_color_hex(0x39414D), 0);
        lv_obj_set_style_bg_opa(r.accent, 60, 0);
        lv_obj_set_style_border_width(r.accent, 0, 0);
        lv_obj_clear_flag(r.accent, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(r.accent, LV_OBJ_FLAG_SCROLLABLE);

        // 状态灯光晕（比灯大一圈、低透明度）
        r.halo = T(lv_obj_create(scr));
        lv_obj_set_pos(r.halo, CARD_X + 9, y + 10);
        lv_obj_set_size(r.halo, 24, 24);
        lv_obj_set_style_radius(r.halo, LV_RADIUS_CIRCLE, 0);
        lv_obj_set_style_bg_color(r.halo, lv_color_hex(0x39414D), 0);
        lv_obj_set_style_bg_opa(r.halo, 45, 0);
        lv_obj_set_style_border_width(r.halo, 0, 0);
        lv_obj_clear_flag(r.halo, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(r.halo, LV_OBJ_FLAG_SCROLLABLE);

        r.dot = T(lv_obj_create(scr));
        lv_obj_set_pos(r.dot, CARD_X + 14, y + 15);
        lv_obj_set_size(r.dot, 14, 14);
        lv_obj_set_style_radius(r.dot, LV_RADIUS_CIRCLE, 0);
        lv_obj_set_style_bg_color(r.dot, lv_color_hex(0x39414D), 0);
        lv_obj_set_style_bg_opa(r.dot, 60, 0);
        if (r.halo) lv_obj_set_style_bg_color(r.halo, lv_color_hex(0x39414D), 0);
        lv_obj_set_style_border_width(r.dot, 0, 0);
        lv_obj_clear_flag(r.dot, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(r.dot, LV_OBJ_FLAG_SCROLLABLE);

        r.app = T(mkcard_label(scr, CARD_X + 32, y + 8, 180, 18,
                             &lv_font_unscii_16, 0xEFE9DA, LV_TEXT_ALIGN_LEFT));
        r.agent = T(mkcard_label(scr, CARD_X + 32, y + 28, 180, 11,
                               &lv_font_unscii_8, 0x7C838C, LV_TEXT_ALIGN_LEFT));
        r.state = T(mkcard_label(scr, CARD_X + 214, y + 7, 78, 12,
                             &lv_font_unscii_8, 0x8A8275, LV_TEXT_ALIGN_RIGHT));
        r.project = T(mkcard_label(scr, CARD_X + 214, y + 27, 78, 11,
                                 &lv_font_unscii_8, 0x7C838C, LV_TEXT_ALIGN_RIGHT));

        r.activity = T(mkcard_label(scr, CARD_X + 32, y + 46, 258, 18,
                                  &lv_font_grooved_cjk12, 0xB9B2A2, LV_TEXT_ALIGN_LEFT));
        lv_label_set_long_mode(r.activity, LV_LABEL_LONG_DOT);

        r.bar_bg = T(lv_obj_create(scr));
        lv_obj_set_pos(r.bar_bg, CARD_X + 32, y + 72);
        lv_obj_set_size(r.bar_bg, 160, 5);
        lv_obj_set_style_radius(r.bar_bg, 3, 0);
        lv_obj_set_style_bg_color(r.bar_bg, lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_bg_opa(r.bar_bg, 26, 0);
        lv_obj_set_style_border_width(r.bar_bg, 0, 0);
        lv_obj_clear_flag(r.bar_bg, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(r.bar_bg, LV_OBJ_FLAG_SCROLLABLE);

        r.bar_fill = T(lv_obj_create(scr));
        lv_obj_set_pos(r.bar_fill, CARD_X + 32, y + 72);
        lv_obj_set_size(r.bar_fill, 1, 5);
        lv_obj_set_style_radius(r.bar_fill, 3, 0);
        lv_obj_set_style_bg_color(r.bar_fill, lv_color_hex(0x39414D), 0);
        lv_obj_set_style_bg_opa(r.bar_fill, 220, 0);
        lv_obj_set_style_border_width(r.bar_fill, 0, 0);
        lv_obj_clear_flag(r.bar_fill, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(r.bar_fill, LV_OBJ_FLAG_SCROLLABLE);

        r.tok = T(mkcard_label(scr, CARD_X + 198, y + 68, 94, 12,
                             &lv_font_unscii_8, 0x7C838C, LV_TEXT_ALIGN_RIGHT));
    }

    /* 详情浮层：全屏黑底，不再画小圆圈。内容仍按半径 233 的圆盘约束排，
     * 所以不会被表盘压到；X / 黄色键都能退出。 */
    _detail_panel = T(lv_obj_create(scr));
    lv_obj_set_pos(_detail_panel, 0, 0);
    lv_obj_set_size(_detail_panel, 466, 466);
    lv_obj_set_style_radius(_detail_panel, 0, 0);
    lv_obj_set_style_bg_color(_detail_panel, lv_color_hex(0x040507), 0);
    lv_obj_set_style_bg_opa(_detail_panel, 255, 0);
    lv_obj_set_style_border_width(_detail_panel, 0, 0);
    lv_obj_add_flag(_detail_panel, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(_detail_panel, detail_cb, LV_EVENT_CLICKED, nullptr);
    lv_obj_clear_flag(_detail_panel, LV_OBJ_FLAG_SCROLLABLE);

    /* 顶部 logo：A8 alpha 图，必须 recolor 成米白，否则黑底上看不见。
     * 104×94 缩到 80/256 ≈ 32×29，放在中轴正中。 */
    lv_obj_t* lg = T(lv_image_create(_detail_panel));
    lv_image_set_src(lg, &logo_cospon);
    lv_image_set_scale(lg, 96);          // 104×94 → 39×35
    lv_obj_set_size(lg, 39, 35);         // 显式尺寸：否则 scale 以原图中心为轴，位置会偏
    lv_obj_set_pos(lg, 213, 12);         // 中轴上方，kicker(y=54) 之前结束
    lv_obj_set_style_image_recolor(lg, lv_color_hex(0xEFE9DA), 0);
    lv_obj_set_style_image_recolor_opa(lg, LV_OPA_COVER, 0);
    lv_obj_clear_flag(lg, LV_OBJ_FLAG_CLICKABLE);

    /* 标题和项目名统一用 unscii_16：原来 Codex 是 Montserrat 20，
     * 和周围的点阵字完全是两种语言，所以看起来"字体不太对"。 */
    lv_obj_t* kick = T(mkcard_label(_detail_panel, 133, 54, 200, 20,
        &lv_font_unscii_16, 0x6F756F, LV_TEXT_ALIGN_CENTER));
    lv_label_set_text(kick, "COSPON D");
    lv_obj_set_style_text_letter_space(kick, 3, 0);

    _detail_app = T(mkcard_label(_detail_panel, 83, 74, 300, 24,
        &lv_font_unscii_16, 0xEFE9DA, LV_TEXT_ALIGN_CENTER));
    lv_obj_set_style_text_letter_space(_detail_app, 3, 0);
    lv_label_set_long_mode(_detail_app, LV_LABEL_LONG_DOT);

    _detail_pulse = T(lv_obj_create(_detail_panel));
    lv_obj_set_pos(_detail_pulse, 229, 100);
    lv_obj_set_size(_detail_pulse, 8, 8);
    lv_obj_set_style_radius(_detail_pulse, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_color(_detail_pulse, lv_color_hex(0xFF5A1F), 0);
    lv_obj_set_style_bg_opa(_detail_pulse, 255, 0);
    lv_obj_set_style_border_width(_detail_pulse, 0, 0);
    lv_obj_clear_flag(_detail_pulse, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(_detail_pulse, LV_OBJ_FLAG_SCROLLABLE);

    _detail_state = T(mkcard_label(_detail_panel, 53, 112, 360, 18,
        &lv_font_unscii_16, 0xEFE9DA, LV_TEXT_ALIGN_CENTER));

    /* 两侧信息柱：没有框，纯文字，60px 宽，保证 4 个字符完整显示。 */
    auto sidecol = [&](int x, const char* cap, lv_obj_t** cap_out, lv_obj_t** v) {
        lv_obj_t* p = T(lv_obj_create(_detail_panel));
        lv_obj_set_pos(p, x, 150);
        lv_obj_set_size(p, 60, 130);
        lv_obj_set_style_bg_opa(p, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_width(p, 0, 0);
        lv_obj_set_style_pad_all(p, 0, 0);
        lv_obj_clear_flag(p, LV_OBJ_FLAG_SCROLLABLE);
        *cap_out = T(mkcard_label(p, 0, 0, 60, 11, &lv_font_unscii_8, 0x6F756F, LV_TEXT_ALIGN_CENTER));
        lv_label_set_text(*cap_out, cap);
        lv_obj_set_style_text_letter_space(*cap_out, 1, 0);
        const lv_font_t* fs[3] = { &lv_font_unscii_16, &lv_font_unscii_8, &lv_font_unscii_8 };
        int ys[3] = { 18, 46, 68 };
        for (int k = 0; k < 3; k++) {
            v[k] = T(mkcard_label(p, 0, ys[k], 60, k == 0 ? 18 : 12, fs[k],
                                  k == 0 ? 0xEFE9DA : 0x9A9388, LV_TEXT_ALIGN_CENTER));
            lv_label_set_text(v[k], "-");
        }
        return p;
    };
    _side_l = sidecol(44, "STEPS", &_side_l_cap, _side_l_v);
    lv_obj_add_flag(_side_l, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(_side_l, view_cb, LV_EVENT_CLICKED, nullptr);
    _side_r = sidecol(362, "TURN", &_side_r_cap, _side_r_v);

    /* 中间：CHAT / STEPS 共用的滚动区。226 宽，左右各留 16px。 */
    _detail_msgs = T(lv_obj_create(_detail_panel));
    lv_obj_set_pos(_detail_msgs, 120, 150);
    lv_obj_set_size(_detail_msgs, 226, 178);
    lv_obj_set_style_bg_opa(_detail_msgs, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(_detail_msgs, 0, 0);
    lv_obj_set_style_pad_all(_detail_msgs, 0, 0);
    lv_obj_set_style_clip_corner(_detail_msgs, true, 0);
    lv_obj_add_flag(_detail_msgs, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(_detail_msgs, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_row(_detail_msgs, 7, 0);
    lv_obj_set_scroll_dir(_detail_msgs, LV_DIR_VER);
    lv_obj_set_scrollbar_mode(_detail_msgs, LV_SCROLLBAR_MODE_OFF);
    lv_obj_add_event_cb(_detail_msgs, stop_bubble_cb, LV_EVENT_CLICKED, nullptr);
    lv_obj_add_event_cb(_detail_msgs, stop_bubble_cb, LV_EVENT_PRESSED, nullptr);
    lv_obj_add_event_cb(_detail_msgs, stop_bubble_cb, LV_EVENT_SCROLL, nullptr);
    lv_obj_add_event_cb(_detail_msgs, stop_bubble_cb, LV_EVENT_SCROLL_BEGIN, nullptr);
    lv_obj_add_event_cb(_detail_msgs, stop_bubble_cb, LV_EVENT_SCROLL_END, nullptr);

    for (int k = 0; k < 8; k++) {
        _dm[0][k] = T(mkcard_label(_detail_msgs, 0, 0, 226, 40,
                                   &lv_font_grooved_cjk12, 0xD8D2C4, LV_TEXT_ALIGN_LEFT));
        lv_label_set_long_mode(_dm[0][k], LV_LABEL_LONG_WRAP);
        lv_obj_set_height(_dm[0][k], LV_SIZE_CONTENT);
        lv_obj_set_width(_dm[0][k], 226);
        lv_obj_add_flag(_dm[0][k], LV_OBJ_FLAG_HIDDEN);
    }
    for (int k = 0; k < 6; k++) {
        _ds[k] = T(mkcard_label(_detail_msgs, 0, 0, 226, 30,
                                &lv_font_grooved_cjk12, 0x9AA3AD, LV_TEXT_ALIGN_LEFT));
        lv_label_set_long_mode(_ds[k], LV_LABEL_LONG_WRAP);
        lv_obj_set_height(_ds[k], LV_SIZE_CONTENT);
        lv_obj_set_width(_ds[k], 226);
        lv_obj_add_flag(_ds[k], LV_OBJ_FLAG_HIDDEN);
    }
    _msgs_spacer = T(lv_obj_create(_detail_msgs));
    lv_obj_set_size(_msgs_spacer, 1, 1);
    lv_obj_set_style_bg_opa(_msgs_spacer, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(_msgs_spacer, 0, 0);
    lv_obj_clear_flag(_msgs_spacer, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(_msgs_spacer, LV_OBJ_FLAG_SCROLLABLE);

    /* 底部硬件键：居中，米白 CONTINUE / 橙色 HANDOFF。 */
    auto mkact = [&](int x, const char* text, uint32_t bg, uint32_t fg, int act) {
        lv_obj_t* b = T(lv_obj_create(_detail_panel));
        lv_obj_set_pos(b, x, 336);
        lv_obj_set_size(b, 126, 30);
        lv_obj_set_style_radius(b, 8, 0);
        lv_obj_set_style_bg_color(b, lv_color_hex(bg), 0);
        lv_obj_set_style_bg_opa(b, 255, 0);
        lv_obj_set_style_border_width(b, 1, 0);
        lv_obj_set_style_border_color(b, lv_color_hex(0x3A3228), 0);
        lv_obj_add_flag(b, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(b, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_event_cb(b, action_cb, LV_EVENT_CLICKED, (void*)(intptr_t)act);
        lv_obj_t* l = lv_label_create(b);
        lv_label_set_text(l, text);
        lv_obj_set_style_text_font(l, &lv_font_unscii_8, 0);
        lv_obj_set_style_text_color(l, lv_color_hex(fg), 0);
        lv_obj_set_style_text_letter_space(l, 2, 0);
        lv_obj_center(l);
        return b;
    };
    _act_continue = mkact(102, "CONTINUE", 0xE8E2D2, 0x0A0A0A, 0);
    _act_handoff = mkact(238, "HANDOFF", 0xFF5A1F, 0x0A0A0A, 1);
    lv_obj_add_flag(_act_continue, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(_act_handoff, LV_OBJ_FLAG_HIDDEN);

    /* X：右上角关闭。 */
    _detail_close = T(lv_obj_create(_detail_panel));
    lv_obj_set_pos(_detail_close, 356, 64);
    lv_obj_set_size(_detail_close, 28, 28);
    lv_obj_set_style_radius(_detail_close, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_color(_detail_close, lv_color_hex(0x14181D), 0);
    lv_obj_set_style_bg_opa(_detail_close, 255, 0);
    lv_obj_set_style_border_width(_detail_close, 1, 0);
    lv_obj_set_style_border_color(_detail_close, lv_color_hex(0x3A3228), 0);
    lv_obj_add_flag(_detail_close, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(_detail_close, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(_detail_close, close_cb, LV_EVENT_CLICKED, nullptr);
    {
        lv_obj_t* xl = lv_label_create(_detail_close);
        lv_label_set_text(xl, "X");
        lv_obj_set_style_text_font(xl, &lv_font_unscii_16, 0);
        lv_obj_set_style_text_color(xl, lv_color_hex(0xEFE9DA), 0);
        lv_obj_center(xl);
    }

    lv_obj_t* hint = T(mkcard_label(_detail_panel, 133, 384, 200, 12,
                                    &lv_font_unscii_8, 0x59616E, LV_TEXT_ALIGN_CENTER));
    lv_label_set_text(hint, "YELLOW = BACK   X = CLOSE");
    lv_obj_set_style_text_letter_space(hint, 1, 0);
    lv_obj_add_flag(_detail_panel, LV_OBJ_FLAG_HIDDEN);

    /* 待批请求面板：两个键（ALLOW / DENY） */
    _perm_panel = T(lv_obj_create(scr));
    lv_obj_set_pos(_perm_panel, 83, 130);
    lv_obj_set_size(_perm_panel, 300, 220);
    lv_obj_set_style_radius(_perm_panel, 20, 0);
    lv_obj_set_style_bg_color(_perm_panel, lv_color_hex(0x1A1208), 0);
    lv_obj_set_style_bg_opa(_perm_panel, 252, 0);
    lv_obj_set_style_border_width(_perm_panel, 1, 0);
    lv_obj_set_style_border_color(_perm_panel, lv_color_hex(0xFF9A5C), 0);
    lv_obj_clear_flag(_perm_panel, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(_perm_panel, LV_OBJ_FLAG_HIDDEN);

    lv_obj_t* pt = T(mkcard_label(_perm_panel, 16, 10, 268, 18,
                                  &lv_font_montserrat_14, 0xFFB066, LV_TEXT_ALIGN_LEFT));
    lv_label_set_text(pt, "PERMISSION");
    _perm_tool = T(mkcard_label(_perm_panel, 16, 30, 268, 16,
                               &lv_font_montserrat_10, 0xE9F0F9, LV_TEXT_ALIGN_LEFT));
    _perm_detail = T(mkcard_label(_perm_panel, 16, 50, 268, 96,
                                  &lv_font_montserrat_14, 0xE8EEF7, LV_TEXT_ALIGN_LEFT));
    lv_label_set_long_mode(_perm_detail, LV_LABEL_LONG_WRAP);

    auto mkbtn = [&](int x, uint32_t color, const char* text, lv_event_cb_t cb) {
        lv_obj_t* b = T(lv_obj_create(_perm_panel));
        lv_obj_set_pos(b, x, 156);
        lv_obj_set_size(b, 120, 44);
        lv_obj_set_style_radius(b, 12, 0);
        lv_obj_set_style_bg_color(b, lv_color_hex(color), 0);
        lv_obj_set_style_bg_opa(b, 235, 0);
        lv_obj_set_style_border_width(b, 0, 0);
        lv_obj_add_flag(b, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(b, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_event_cb(b, cb, LV_EVENT_CLICKED, nullptr);
        lv_obj_t* l = lv_label_create(b);
        lv_label_set_text(l, text);
        lv_obj_set_style_text_font(l, &lv_font_montserrat_14, 0);
        lv_obj_set_style_text_color(l, lv_color_hex(0xFFFFFF), 0);
        lv_obj_center(l);
    };
    mkbtn(16, 0x1F8F5A, "ALLOW", perm_allow_cb);
    mkbtn(164, 0x9A2E3A, "DENY", perm_deny_cb);

    _foot = std::make_unique<Label>(scr);
    _foot->setPos(CX - 120, 390);
    _foot->setSize(240, 16);
    _foot->setTextAlign(LV_TEXT_ALIGN_CENTER);
    _foot->setText("WAITING 0 | TOTAL 0 | NO BRIDGE");
    _foot->setTextFont(&lv_font_unscii_8);
    _foot->setTextColor(lv_color_hex(0xFF9A5C));

    /* WiFi 一键：开站/开配网 AP；连上后 HTTP 轮询 /api/agents/watch */
    _wifi_btn = T(lv_obj_create(scr));
    lv_obj_set_pos(_wifi_btn, CX - 45, 406);
    lv_obj_set_size(_wifi_btn, 90, 28);
    lv_obj_set_style_radius(_wifi_btn, 14, 0);
    lv_obj_set_style_bg_color(_wifi_btn, lv_color_hex(0x12202A), 0);
    lv_obj_set_style_bg_opa(_wifi_btn, 245, 0);
    lv_obj_set_style_border_width(_wifi_btn, 1, 0);
    lv_obj_set_style_border_color(_wifi_btn, lv_color_hex(0x2E4A5A), 0);
    lv_obj_add_flag(_wifi_btn, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(_wifi_btn, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(_wifi_btn, wifi_cb, LV_EVENT_CLICKED, nullptr);
    {
        lv_obj_t* wl = lv_label_create(_wifi_btn);
        _wifi_btn_lab = wl;
        lv_label_set_text(wl, "WIFI ON");
        lv_obj_set_style_text_font(wl, &lv_font_unscii_8, 0);
        lv_obj_set_style_text_color(wl, lv_color_hex(0x8FD8B0), 0);
        lv_obj_center(wl);
    }
    _wifi_lab = T(mkcard_label(scr, CX - 100, 436, 200, 12,
                               &lv_font_unscii_8, 0x6F756F, LV_TEXT_ALIGN_CENTER));
    lv_label_set_text(_wifi_lab, "WIFI OFF");

    for (int i = 0; i < SLOTS; i++) paint_row(i);

    load_net_host();
    _ui_alive = true;
    _wifi_task_run = true;
    if (!_wifi_task) xTaskCreate(wifi_poll_task, "cospon_wifi", 4096, nullptr, 4, &_wifi_task);
}

void AppCospon::onRunning()
{
    // ⚠️ 和 Stem 一样：LVGL 在独立任务，onRunning 里的 UI 调用必须拿锁。
    char buf[64];
    int n = usb_serial_jtag_read_bytes(buf, sizeof(buf), 0);
    if (n < 0) n = 0;
    {
    LvglLockGuard lock;
    for (int i = 0; i < n; i++) {
        char c = buf[i];
        if (c == '\n' || c == '\r') {
            _line[_line_len] = 0;
            if (_line_len > 0) {
                handle_line(_line);
                _last_rx_ms = esp_timer_get_time() / 1000;
            }
            _line_len = 0;
        } else if (_line_len < (int)sizeof(_line) - 1) {
            _line[_line_len++] = c;
        }
    }

    // 每 2 秒刷一次 footer（LIVE / NO BRIDGE 会随时间变）
    static int64_t last_foot = 0;
    int64_t now = esp_timer_get_time() / 1000;
    if (now - last_foot > 2000) {
        last_foot = now;
        paint_footer();
    }

    static int64_t last_wifi = 0;
    if (now - last_wifi > 1000) {
        last_wifi = now;
        auto ws = GetHAL().getWifiStatus();
        char wb[128];
        if (ws.connected) {
            if (!_net_host[0]) {
                std::snprintf(wb, sizeof(wb), "WIFI %s | NO HOST", ws.ipAddress.c_str());
            } else if (_net_err[0]) {
                std::snprintf(wb, sizeof(wb), "WIFI %s | %s", ws.ipAddress.c_str(), _net_err);
            } else if (_last_ok_ms == 0) {
                std::snprintf(wb, sizeof(wb), "WIFI %s | WAIT", ws.ipAddress.c_str());
            } else {
                std::snprintf(wb, sizeof(wb), "WIFI %s", ws.ipAddress.c_str());
            }
        } else if (ws.configMode) {
            std::snprintf(wb, sizeof(wb), "AP %s / 192.168.4.1", ws.apSsid.c_str());
        } else if (ws.enabled) {
            std::snprintf(wb, sizeof(wb), "WIFI CONNECTING...");
        } else {
            std::snprintf(wb, sizeof(wb), "WIFI OFF");
        }
        if (_wifi_lab) lv_label_set_text(_wifi_lab, wb);
        if (_wifi_btn_lab) lv_label_set_text(_wifi_btn_lab,
            (ws.enabled || ws.mode != Hal::WifiMode::Off) ? "WIFI OFF" : "WIFI ON");
    }
    }   // LvglLockGuard

    // 有 waiting / 待批时响两下（震动两次）--只在"从没有变成有"时触发，不重复吵。
    bool attn = _waiting > 0;
    for (int i = 0; i < _count && i < SLOTS; i++) {
        if (std::strcmp(_data[i].state, "waiting") == 0) attn = true;
    }
    static bool was_attn = false;
    if (attn && !was_attn) {
        GetHAL().vibrate(60, 90);
        vTaskDelay(pdMS_TO_TICKS(150));
        GetHAL().vibrate(60, 90);
    }
    was_attn = attn;

    if (_key_manager) {
        auto ev = _key_manager->update();
        if (ev == input::KeyEvent::GoPrevious || ev == input::KeyEvent::GoHome) {
            if (_detail >= 0) {
                LvglLockGuard lock;
                hide_detail();
                return;
            }
            close();
            return;
        }
        if (ev == input::KeyEvent::GoNext) {
            std::printf("C1 REFRESH\n");
            std::fflush(stdout);
            LvglLockGuard lock;
            if (_foot) {
                _foot->setText("REFRESHING...");
                _foot->setTextColor(lv_color_hex(0x6AA9FF));
            }
        }
    }
}

void AppCospon::onClose()
{
    mclog::tagInfo(getAppInfo().name, "on close");
    _ui_alive = false;
    _wifi_task_run = false;
    _key_manager.reset();
    LvglLockGuard lock;
    pulse_stop();
    _title.reset();
    _sub.reset();
    _foot.reset();
    for (int i = _owned_n - 1; i >= 0; i--) if (_owned[i]) lv_obj_del(_owned[i]);
    _owned_n = 0;
    for (auto& r : _row) {
        r.dot = nullptr; r.accent = nullptr; r.app = nullptr; r.agent = nullptr;
        r.activity = nullptr; r.project = nullptr; r.state = nullptr; r.halo = nullptr;
        r.bar_bg = nullptr; r.bar_fill = nullptr; r.tok = nullptr;
    }
}
