/*
 * Muse -- 切到 ota_1（Muse Gadget SDK）的入口。
 * 见 app_muse.h 与 docs/双系统-2026-10-19.md。
 */
#include "app_muse.h"
#include "../grooved_icons.h"
#include "../grooved_capture.h"
#include <hal/hal.h>
#include <mooncake.h>
#include <mooncake_log.h>
#include <smooth_lvgl.hpp>
#include <esp_ota_ops.h>
#include <esp_partition.h>
#include <esp_system.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <cstdio>

using namespace mooncake;
using namespace smooth_ui_toolkit::lvgl_cpp;

static const int CX = 233;
static const int BTN_X = 163, BTN_Y = 306, BTN_W = 140, BTN_H = 42;

static lv_obj_t* _owned[32];
static int _owned_n = 0;
static lv_obj_t* T(lv_obj_t* o)
{
    if (o && _owned_n < (int)(sizeof(_owned) / sizeof(_owned[0]))) _owned[_owned_n++] = o;
    return o;
}
static void destroy_all()
{
    for (int i = _owned_n - 1; i >= 0; i--) if (_owned[i]) lv_obj_del(_owned[i]);
    _owned_n = 0;
}

static lv_obj_t* _status = nullptr;

static void set_status(const char* s)
{
    if (_status) lv_label_set_text(_status, s);
}

static bool ota1_valid()
{
    const esp_partition_t* p = esp_partition_find_first(
        ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_1, NULL);
    if (!p) return false;
    uint8_t magic = 0xFF;
    if (esp_partition_read(p, 0, &magic, 1) != ESP_OK) return false;
    return magic == 0xE9;
}

static void enter_muse()
{
    if (!ota1_valid()) {
        set_status("MUSE NOT INSTALLED (ota_1 empty)");
        GetHAL().vibrate(30, 80);
        return;
    }
    const esp_partition_t* p = esp_partition_find_first(
        ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_1, NULL);
    if (!p || esp_ota_set_boot_partition(p) != ESP_OK) {
        set_status("SWITCH FAILED");
        return;
    }
    set_status("SWITCHING TO MUSE...");
    GetHAL().vibrate(60, 100);
    vTaskDelay(pdMS_TO_TICKS(450));
    esp_restart();
}

/* 只在按钮区域内响应，避免误触 */
static bool in_btn(int x, int y)
{
    return x >= BTN_X && x <= BTN_X + BTN_W && y >= BTN_Y && y <= BTN_Y + BTN_H;
}

static void screen_cb(lv_event_t* e)
{
    lv_event_code_t code = lv_event_get_code(e);
    if (code != LV_EVENT_RELEASED && code != LV_EVENT_CLICKED) return;
    lv_indev_t* indev = lv_indev_active();
    if (!indev) return;
    lv_point_t p;
    lv_indev_get_point(indev, &p);
    if (in_btn(p.x, p.y)) enter_muse();
}

AppMuse::AppMuse()
{
    setAppInfo().name = "Muse D";
    setAppInfo().icon = (void*)&icon_muse;
}

void AppMuse::onCreate() { mclog::tagInfo(getAppInfo().name, "on create"); }

void AppMuse::onOpen()
{
    mclog::tagInfo(getAppInfo().name, "on open");
    _key_manager = std::make_unique<input::KeyManager>();

    LvglLockGuard lock;
    destroy_all();

    lv_obj_t* scr = lv_screen_active();
    lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(scr, lv_color_hex(0x0B0E13), 0);
    lv_obj_set_style_bg_grad_color(scr, lv_color_hex(0x04060A), 0);
    lv_obj_set_style_bg_grad_dir(scr, LV_GRAD_DIR_VER, 0);

    lv_obj_t* icon = T(lv_image_create(scr));
    lv_image_set_src(icon, &icon_muse);
    lv_image_set_scale(icon, 180);           // 70% → 140×140
    lv_obj_set_pos(icon, CX - 70, 46);
    lv_obj_clear_flag(icon, LV_OBJ_FLAG_CLICKABLE);

    auto label = [&](const char* txt, int x, int y, int w, int h,
                     const lv_font_t* f, uint32_t c) {
        lv_obj_t* l = T(lv_label_create(scr));
        lv_obj_set_pos(l, x, y);
        lv_obj_set_size(l, w, h);
        lv_label_set_text(l, txt);
        lv_obj_set_style_text_font(l, f, 0);
        lv_obj_set_style_text_color(l, lv_color_hex(c), 0);
        lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_clear_flag(l, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(l, LV_OBJ_FLAG_SCROLLABLE);
        return l;
    };

    label("Muse D", CX - 100, 200, 200, 36, &lv_font_montserrat_28, 0xE9F0F9);
    label("SECOND OS | OTA_1", CX - 100, 238, 200, 16,
          &lv_font_montserrat_10, 0x8A93A0);

    lv_obj_t* btn = T(lv_obj_create(scr));
    lv_obj_set_pos(btn, BTN_X, BTN_Y);
    lv_obj_set_size(btn, BTN_W, BTN_H);
    lv_obj_set_style_radius(btn, 21, 0);
    lv_obj_set_style_bg_color(btn, lv_color_hex(0x123A34), 0);
    lv_obj_set_style_bg_opa(btn, 245, 0);
    lv_obj_set_style_border_width(btn, 1, 0);
    lv_obj_set_style_border_color(btn, lv_color_hex(0x57E39B), 0);
    lv_obj_set_style_border_opa(btn, 220, 0);
    lv_obj_clear_flag(btn, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(btn, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t* bl = label("ENTER MUSE", BTN_X, BTN_Y + 12, BTN_W, 18,
                         &lv_font_montserrat_14, 0xB8F5DE);
    (void)bl;

    _status = label(ota1_valid() ? "OTA_1 READY" : "OTA_1 EMPTY | FLASH MUSE FIRST",
                    CX - 120, 370, 240, 16,
                    &lv_font_montserrat_10, ota1_valid() ? 0x7BE0A4 : 0xFF9A5C);

    label("BLUE = ENTER | YELLOW = BACK", CX - 120, 420, 240, 14,
          &lv_font_montserrat_10, 0x59616E);

    lv_obj_add_flag(scr, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(scr, screen_cb, LV_EVENT_RELEASED, nullptr);
}

void AppMuse::onRunning()
{
    grooved_capture_poll_stdin();
    if (!_key_manager) return;
    auto ev = _key_manager->update();
    if (ev == input::KeyEvent::GoPrevious || ev == input::KeyEvent::GoHome) {
        close();
        return;
    }
    if (ev == input::KeyEvent::GoNext) {
        GetHAL().vibrate(20, 80);
        LvglLockGuard lock;
        enter_muse();
    }
}

void AppMuse::onClose()
{
    mclog::tagInfo(getAppInfo().name, "on close");
    _key_manager.reset();
    LvglLockGuard lock;
    destroy_all();
    _status = nullptr;
}
