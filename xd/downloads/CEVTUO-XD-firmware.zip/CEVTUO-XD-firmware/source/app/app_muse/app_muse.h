/*
 * Muse —— 第二个系统（ota_1）的入口 app。
 *
 * 不是把 Muse 的代码塞进 mooncake，而是**切换启动分区**：
 *   ota_0 = 原厂 Watch（本 app 所在的这一套）
 *   ota_1 = Muse Gadget SDK 固件
 * 点 ENTER MUSE ⇒ esp_ota_set_boot_partition(ota_1) + 重启。
 * Muse 那边有自己的「两只边键按住 3 秒回 Watch」补丁。
 */
#pragma once
#include <apps/common/key_manager/key_manager.h>
#include <mooncake.h>
#include <memory>

class AppMuse : public mooncake::AppAbility {
public:
    AppMuse();
    void onCreate() override;
    void onOpen() override;
    void onRunning() override;
    void onClose() override;

private:
    std::unique_ptr<input::KeyManager> _key_manager;
};
