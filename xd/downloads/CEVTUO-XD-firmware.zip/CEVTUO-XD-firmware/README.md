# CEVTUO XD · M5StopWatch 固件

这份包是手表端（M5Stack StopWatch，ESP32-S3 / 16MB Flash / 8MB PSRAM）的完整可构建源码
和可直接烧写的二进制。手表上跑四个 App：Stem D、Groove D、COSPON D、Muse D。

## 目录

```
firmware/            预编译产物
  firmware.bin         应用镜像（写到 0x20000，保留 NVS）
  firmware.factory.bin 整片镜像（写到 0x0，会清掉 NVS）
  bootloader.bin / partitions.bin / ota_data_initial.bin
source/app/          四个 App 的 C++ 源码、字体、图标、线稿 logo
source/assets/pet/   启动动画帧（RGB565）
source/tools/        apply-app.sh（把 App 幂等接进上游固件树）
flash.sh             日常升级：只写应用分区
flash-full.sh        整片恢复（会清掉 Wi-Fi 配置）
FEATURES.md          功能与算法总账
```

## 直接烧写（不重新编译）

```bash
# 只更新 App，保留 Wi-Fi 凭据 / 已保存的 Mac 地址
bash flash.sh /dev/cu.usbmodem1101

# 整片恢复（换机、分区表变了、或者要回到干净状态）
bash flash-full.sh /dev/cu.usbmodem1101
```

macOS 上如果找不到 esptool：`python3 -m pip install esptool`，或者用 PlatformIO 自带的
`~/.platformio/penv/bin/python -m esptool`。

## 从源码构建

```bash
git clone https://github.com/m5stack/M5StopWatch-UserDemo.git
XD_UPSTREAM="$PWD/M5StopWatch-UserDemo" bash source/tools/apply-app.sh
cd M5StopWatch-UserDemo && pio run
pio run -t upload --upload-port /dev/cu.usbmodem1101
```

`apply-app.sh` 做四件事，全部幂等：把 `source/app/app_*` 复制进上游 `main/apps/`、
换成双系统分区表（`partitions_dual.csv`）、注册 `apps.h` / `main.cpp`、
在 `main.cpp` 里注入电源轨恢复（Muse 休息时会关掉 OLED 的 L3B 轨，不恢复就是黑屏）。

构建依赖 PlatformIO + pioarduino 平台 55.03.312（ESP-IDF 5.5.5）。上游 commit 见 `VERSION`。

## 手表上的 Wi-Fi

COSPON D 的数据来自 Mac。两条链路：

1. **USB 串口**：Mac 上的 `grooved-serial-midi` 每 2 秒把 `AG / SESS / MSG / PERM / END` 写进串口。
2. **Wi-Fi**：手表连上局域网后，主动轮询 `http://<Mac 局域网 IP>:8765/api/agents/watch`。

Wi-Fi 第一次使用：

1. COSPON D → `WIFI ON`；手表进入配置 AP（`M5StopWatch-XXXX`）。
2. 手机连这个 AP，在网页里填家里的 Wi-Fi。
3. 回到手机 App 的 LINK 页，按「发送 Mac 地址到手表」（需要 Mac 服务在线）。
4. 地址存在 NVS 里，之后开 Wi-Fi 就会自己轮询。

状态行会明确写出当前处在哪一种状态：`WIFI <ip>`、`WIFI <ip> | NO HOST`（没有 Mac 地址）、
`WIFI <ip> | CONN FAIL`（连不上）、`WIFI <ip> | SHORT`（响应不完整）。底部显示
`LIVE` / `NO BRIDGE`。不会再有"连上了但什么都不显示、也说不清为什么"。

## 常见问题

- **Wi-Fi 连着但没内容**：先看状态行是不是 `NO HOST`。是的话在 LINK 页重发 Mac 地址；
  再看 Mac 上的服务是否监听 `0.0.0.0:8765`（`lsof -nP -iTCP:8765 -sTCP:LISTEN`）。
- **黑屏**：长按红色电源键 5 秒关机再开。`apply-app.sh` 注入的电源轨恢复必须存在。
- **刷完 Wi-Fi 配置丢了**：用了 `flash-full.sh`。用 `flash.sh` 日常升级不会丢。
