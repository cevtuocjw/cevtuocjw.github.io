#!/usr/bin/env bash
# 只写应用分区（0x20000）：保留 NVS 里的 Wi-Fi 凭据和 Mac 地址。
# 这是日常升级用的那条路。
set -euo pipefail
PORT="${1:-/dev/cu.usbmodem1101}"
DIR="$(cd "$(dirname "$0")" && pwd)"
python3 -m esptool --chip esp32s3 -p "$PORT" write-flash 0x20000 "$DIR/firmware/firmware.bin"
