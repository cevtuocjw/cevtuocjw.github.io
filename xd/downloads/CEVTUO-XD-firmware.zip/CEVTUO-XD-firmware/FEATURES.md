# CEVTUO XD / GrooveD —— 功能总账（含原理）

> 这份文档是**功能与算法的唯一总账**：每一项都写清「它做什么 / 怎么实现 / 在哪 / 怎么验的」。
> 分发页、交接、下一轮开发都从这里取事实，不在别处再抄一份。
> 最后更新：2026-10-19

---

## 0. 系统由三块组成

```
M5 手表（ESP32-S3 固件）       手机（Android WebView App）        Mac（Deno 零依赖服务）
  Stem / Groove / Cospon / Muse   STEM / GROOVE / SEQ / NOW / LINK   /api/studio /api/groove
  触摸 + 四段弧 + 鼓垫            录音 + 编排 + 实时处理 + 导出       编曲引擎 + LLM + MIDI 桥
        └──────── USB 串口 / Wi-Fi ────────┴────────── HTTP / WS ──────────┘
```

- **手表**负责「手上有动作」：推子、鼓垫、状态灯、振动。
- **手机**负责「把想法变成作品」：哼唱采集、编排、实时处理、历史、导出。
- **Mac**负责「算和发」：乐理引擎、LLM、CoreMIDI、串口桥。没有 UI。

---

## 1. 手表端（4 个 App）

| App | 功能 | 关键实现 |
|---|---|---|
| **Stem D** | 四段弧 = 四轨音量；长按静音、双击独奏；中央黑胶可搓；白色标签显示 now playing | LVGL 弧控件 + 串口 `NP` 解析；`G1 STEM/MUTE/SOLO/MASTER/BPM/PLATTER` |
| **Groove D** | 8 个鼓垫、4 根 CC 推子、BPM/FX 旋钮、磁带机页 | 触摸事件 → `NOTEON/NOTEOFF/CC`；BPM/FX 同链路 |
| **Cospon D** | 三张 CrewTower 会话卡 + 详情浮层（环形进度 + AGENT/PROJECT/TOKENS/LIMIT/AGE + ACTIVITY） | `/api/agents/list` → 卡片；点卡进详情；`strcasecmp` 兼容状态大小写 |
| **Muse D** | 第二个 OTA 槽的入口；进入/返回 | 双系统分区 + 电源轨恢复 |

### 1.1 屏幕录制协议（给分发页 GIF）

```
CAP1 | w_lo w_hi | h_lo h_hi | w*h*2 字节 RGB565(小端) | 'E','N','D','1'
```
- 固件在 LVGL flush 回调维护 468×466 影子缓冲，`CAP 1` 后每 250ms 降采样 233×233 发一帧。
- Mac 端 `tools/grooved-capture.py` 收帧、跳过夹在帧间的日志、按实测帧距合成 GIF。
- ⚠️ 宽度必须是 **468**（写成 466 会让整屏刷新的 flush 区域全被丢弃；症状是推帧计数在涨、画面全黑）。
- ⚠️ 从录制任务里调 `lv_refr_now()` 会让整机卡死，只保留 `lv_obj_invalidate`。

---

## 2. 手机端五大页

### 2.1 STEM —— 作品层

> 一句话：把「一个想法」变成「一首东西」。

| 功能 | 怎么用 | 原理 |
|---|---|---|
| **HUM 哼唱** | 点 HUM 开始/结束 | 原生 `AudioRecord`（22050Hz/单声道）→ **YIN** 基频 → 5 帧中位 + 连续 2 帧一致才认音 → `{midi,start,dur}` |
| **风格** | Lo-Fi / Boom Bap / House / Trap / Breakbeat | 鼓型表 + 和弦进行表（见 §4.2） |
| **调式** | AUTO / Major / Minor / Dorian / Phrygian / Lydian / Mixolydian | 7 声音阶表；AUTO 用 24 调打分 |
| **音色** | 四个角色分别点选循环 | 服务端 `INSTRUMENTS` 表；手机 WebAudio 按音色选波形/包络 |
| **BPM / 小节** | ±2 BPM；2/4/8 小节 | 直接进编排参数 |
| **编曲** | 一次性生成四轨 | `/api/studio/arrange`（确定性乐理） |
| **播放** | 手机出声 + 同时发 MIDI | WebAudio 合成 + `setTimeout` 发 `NOTEON/NOTEOFF` |
| **一键成曲** | 编排 + 播放 | 同上，两个动作串起来 |
| **4 个变体 A/B/C/D** | 生成 4 份不同 seed 的编排 | `/api/studio/variations` |
| **再变一版** | busy / sparse / swing / straight / up / down / wild / hard / soft | `/api/studio/mutate` |
| **保留 / 丢弃** | 播放结束弹条 | 保留才写历史；丢弃清空当前 take |
| **处理记录** | 底部列表，最多 20 条 | 手机 `localStorage`（服务端没有写权限） |
| **哼唱做贝斯** | ON/OFF | 把哼唱下移八度当贝斯轨（36–52），而不是和弦根音 |
| **导出 .mid** | 标准 MIDI 文件 | 自写 SMF：`MThd` + `MTrk` + 变长 delta + 音色 program |
| **对话修改** | 一句中文 | `/api/studio/ask`：LLM 翻成参数；失败走关键词规则 |
| **INSPIRE 灵感 AI** | 一次给一个概念 + 参数 + 直接播放 | `/api/studio/inspire`：LLM 或本地灵感卡 |
| **AI LIVE** | 自动操盘 | 每遍自然播完 → 自动保留 → `mutate('wild')` → 继续播 |
| **和弦行** | 每小节一个和弦名，点一下试听 | 编排时按音阶级数算三音/五音，输出 `chords[]` |

### 2.2 GROOVE —— 演奏层

> 一句话：把「一个律动」变成「手上的动作」。

| 功能 | 原理 |
|---|---|
| 8 个鼓垫 | `NOTEON/NOTEOFF`；**力度按触点纵向位置**（上 127 / 下 60） |
| **BANK 三态** | DRUM（GM 鼓号）/ SYNTH（音阶音符）/ **CHORD（当前编排每小节的和弦）** |
| **ARP** | 和弦垫按 70ms 间隔琶音；同时发 MIDI |
| 4 根 CC 推子 | `CC 1 <num> <value>`；触摸纵向映射 |
| XY 垫 | X→CC1、Y→CC74 |
| **听懂鼓点** | 记录垫子击打时间 → 按 16 分格量化 → 填步进格 |
| **生成 16 步** | `/api/studio/arrange` 取鼓轨 → 填格 |
| **加花** | 末四格补军鼓/帽子 |
| **写回 STEM** | 把当前 16 步写成 STEM 片段的鼓轨 |
| **来自 STEM** | 进入 GROOVE 时自动读当前片段的鼓轨 |

### 2.3 SEQ —— 16 步 × 4 轨

- 点击格子开关；`PLAY SEQ` 按 BPM 的 16 分音符发 `NOTEON/NOTEOFF`。
- 与 GROOVE 的步进格共享同一份 `seqState`。

### 2.4 NOW —— 手机正在播放

- 通过「通知使用权」读 `MediaSession` 的标题/歌手/进度/播放态。
- 播放控制走 `MediaController.TransportControls`。
- 把媒体信息 POST 给 Mac，手表 Stem 的白色标签读这一份。

### 2.5 LINK —— 连接 / 状态 / 设置

| 功能 | 说明 |
|---|---|
| **M5 / LINK 状态卡** | Mac 服务 / 串口桥 / 手表 / MIDI / Agent / 最后更新 |
| **手表反馈条** | 手表推上来的 STEM 四轨、MASTER、BPM、LOOP 实时画成四根条 |
| **API KEY** | 填 `sk-…` → `POST /api/studio/key` → `~/.grooved/llm.key`，显示尾号与来源 |
| MAC HOST | `adb reverse` 用 `127.0.0.1`；Wi-Fi 用局域网 IP |
| SAVE / TEST | 保存地址 / 立即探测 `/api/groove/status` |
| 发送日志 | 最近 40 条发出的协议行 |

---

## 3. REAL-TIME —— 10 个旋钮 + 搓盘 + 仪表

| 控件 | 作用 | 实现 |
|---|---|---|
| **FILTER** | 低通 200–12000Hz | Biquad lowpass；同时 CC 24 |
| **DRIVE** | 波形整形 0–100 | WaveShaper 曲线；CC 25 |
| **SPACE** | 延迟湿声 | Delay + feedback + wet；CC 26 |
| **SWING** | 0–80% | 进编排参数（奇数 16 分格后推）；CC 27 |
| **CHAOS** | 0–100% | 额外帽子/装饰音/力度抖动；CC 29 |
| **ENERGY** | 0–100% | 整体力度倍率；CC 30 |
| **OCTAVE** | −24…+24 半音 | 移调（鼓不动）；CC 31 |
| **TONE** | 滤波器 Q 0–20 | Biquad Q；CC 32 |
| **CRUSH** | 位深压碎 | 量化 WaveShaper；CC 33 |
| **DETUNE** | 0–100 音分 | Oscillator.detune；CC 34 |
| **JOG / PLATTER** | 圆形转盘拖动 | 角度增量 → `PLATTER ±v`；同时压低通 |
| **STUTTER** | 8 段方波门 | 主链 gain 调度 + CC 28 |
| **CLICK** | 节拍器 | 每拍 1050Hz 短音 |
| **OUT 电平表** | 主输出 RMS | AnalyserNode（256）逐帧读时域 |
| **MIDI OUT 监视** | 最近 6 条协议行 | `send()` 的环形缓冲 |

音频链：

```
每个声部 Gain → input → filter → crush → drive → out → destination
                                              └→ delay → feedback → drive
                                              └→ delay → wet → out
out → analyser（只测，不串音）
```

---

## 4. 算法

### 4.1 音高检测：YIN

为什么不用自相关：纯周期信号的**每个周期倍数**都同样高，取全局最大会落到大 lag。
离线实测（22050Hz / 1024 样本 / 440Hz + 2% 噪声）：全局最大 lag 451 → 读成 **48.9Hz**。

YIN：

1. 差分函数 `d(τ)=Σ(x[i]-x[i+τ])²`
2. 累积均值归一化 `d'(τ)=d(τ)·τ / Σ_{j≤τ} d(j)`
3. 取第一个 `d'<0.20` 的谷（并走到局部最小）
4. 抛物线插值 → `f = sr/τ`

离线验证：110/220/330/440/660/880Hz **全部正确**。
再叠 5 帧中位 + 连续 2 帧一致（±1 半音），抑制单帧抖动。

### 4.2 调性检测与调式

- 12 个音级直方图，按音长加权。
- 与 12 个大调 / 12 个小调的 Krumhansl 权重相关，取最高分。
- 可被 `scale` 参数覆盖成 7 种调式之一。
- 和弦名：由音阶级数算根音/三音/五音，按实际移调落到音名（m / dim / aug / 大三）。

### 4.3 编曲引擎（确定性）

| 风格 | 鼓型（16 分格） | 和弦进行（级数） |
|---|---|---|
| Lo-Fi | kick 0/3/10，snare 4/12，hat 2/6/10/14 | i–VI–III–VII |
| Boom Bap | kick 0/3/10，snare 4/12，hat 每 2 格 | i–III–IV–IV |
| House | kick 每 4 格，clap 4/12，hat 2/6/10/14 | i–VI–III–VII |
| Trap | kick 0/6/10，snare 8，hat 每格 | i–i–VI–VII |
| Breakbeat | kick 0/10，snare 4/12，hat 2/6/10/14 | i–III–i–IV |

- **和弦**：每小节一个三和弦（级数叠三度），可整小节 / stab。
- **贝斯**：和弦根音移到 C2–B3；`bassFromHum` 时改用哼唱下移。
- **旋律**：哼唱量化到 16 分格并吸附调内；没有哼唱时按动机生成。
- **chaos**：额外帽子（概率 ~chaos/1.7）、装饰音（~chaos/2.6）。
- **energy**：全轨力度 × `0.65 + energy×0.7`。
- **swing**：奇数 16 分格后推 `swing×0.5` 格。
- **humanize**：step ±0.02、力度 ±10 × humanize。
- **transpose**：非鼓轨整体 ±24 半音。
- 同一 `seed + 参数 + 哼唱` 永远给同一份编排（LCG，不是随机抽卡）。

### 4.4 音色合成（手机 WebAudio）

| 角色 | 可选 | 波形 / 包络 |
|---|---|---|
| BASS | 808 / Sub / Saw / Square / FM / Pluck / Reese / Upright | 正弦/锯齿/方波/三角；Reese 额外 +22 音分失谐；Sub 滤波 900Hz |
| CHORDS | Pad / Organ / E-Piano / Pluck / Bell / Strings / Brass / Marimba / Choir | Pad 慢起音；Strings 0.18s 起音；Brass 方波 0.04s；Marimba/Bell 短衰减；Choir/Flute 5.2Hz 颤音 |
| LEAD | Lead / Pluck / Bell / Flute / Square / Strings / Brass / Marimba / Acid | Acid 滤波 Q=12；其余按波形/包络 |
| DRUMS | Kit / 808 / Break | 808 kick 更低更长（150→32Hz，0.55s）；snare/hat 噪声 + 高通 |

### 4.5 MIDI 文件导出

- Format 0，division 480（16 分音符 = 120 tick）。
- 事件：tempo meta → 每轨 program change → note on/off → end of track。
- 音轨通道：drums 9（GM 鼓）、bass 1、chords 2、melody 3。
- Program 映射：808/kit 0、sub 38、saw 81、square 80、fm 88、pluck 45、pad 89、organ 19、epiano 4、bell 9、flute 73、strings 48、brass 61、marimba 12、choir 52、acid 81。
- ⚠️ 文件布局必须是 `[MTrk][4 字节长度][事件]`，长度只数事件；第一版写成 `[长度][MTrk]`，解析器把 `MTrk` 当长度（16732419）。

### 4.6 手机播放声音 → 四段 CC（MediaProjection）

- `MediaProjection` + `AudioPlaybackCaptureConfiguration`（USAGE_MEDIA/GAME/UNKNOWN）。
- 一阶低通在 200/800/3000Hz 切四段，RMS → 0..127。
- 快起慢落（`env = max(rms, env×0.8)`），20Hz 发 `CC 20–23`。
- ⚠️ Android 14+：先 `startForeground(mediaProjection)` 再 `getMediaProjection`。

### 4.7 听懂鼓点

- 记录每次垫子 `pointerdown` 的时间戳与音高。
- 取最后 16 个 16 分格窗口，`step = round((t-t0)/stepMs) % 16`。
- 鼓号映射：36→KICK、38→SNARE、42/46→HAT、39→CLAP。

### 4.8 手表状态回传

- 手表 → 串口 → Mac `POST /api/groove/ingest`（`G1 STEM/MUTE/SOLO/MASTER/BPM/LOOP/FX/START/STOP`）。
- Mac 存进 `groove.state` 并通过 WebSocket `/api/state` 广播。
- 手机 `applyRemote()` 更新推子、静音、独奏、MASTER、BPM、LOOP，并画四根反馈条。
- 判据：`updatedAt` 距今 ≤12s 才算 ON，否则显示 `Ns`（不假装在线）。

---

## 5. API 一览

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/studio/arrange` | 哼唱 + 参数 → 四轨编排 |
| POST | `/api/studio/variations` | 一次 2–6 个变体 |
| POST | `/api/studio/mutate` | busy/sparse/swing/straight/up/down/wild/hard/soft |
| POST | `/api/studio/ask` | 对话改参数 + 执行动作 |
| POST | `/api/studio/inspire` | 灵感 AI（LLM 或本地卡片） |
| GET | `/api/studio/instruments` | 音色清单 |
| GET/POST/DELETE | `/api/studio/key` | DeepSeek key 设置/清除/状态 |
| GET | `/api/studio/dice` | 全参数随机 |
| POST | `/api/groove/send` | 发 MIDI 协议行（`G1 …`） |
| POST | `/api/groove/ingest` | 手表状态回传 |
| GET | `/api/groove/status` | bridge 发送计数/错误 |
| GET | `/api/agents/list` | CrewTower 会话 |
| GET | `/api/midi/status` | MIDI 端口/helper |
| WS | `/api/state` | 设备状态广播 |

### 5.1 `/arrange` 参数

```json
{
  "notes":[{"midi":60,"start":0,"dur":300}],
  "style":"lofi|boombap|house|trap|break",
  "bpm":92, "bars":4, "density":0.6,
  "swing":0.2, "humanize":0.12, "chaos":0.2, "energy":0.6,
  "transpose":0, "scale":"major|minor|dorian|phrygian|lydian|mixolydian",
  "bassFromHum":false, "seed":0,
  "instruments":{"drums":"kit","bass":"808","chords":"pad","melody":"lead"}
}
```

### 5.2 `/ask` 返回

```json
{"ok":true,"by":"llm|rules","say":"…","action":"play|stop|keep|drop|dice|variations|null",
 "patch":{"style":…,"bpm":…,"chaos":…,"instruments":{"bass":"808"}}}
```

---

## 6. 屏幕适配

- 手机（411×960）：底部标签栏、每页独立滚动；STEM 内容约 1500px，可滚。
- **展开屏（≥700px，Fold 内屏 822×910）**：`main.tab.on` 变两列网格：
  - STEM：AI STUDIO（左）+ REAL-TIME（右），下方推子/走带全宽；
  - GROOVE：AI 律动（左）+ AUDIO（右），鼓垫/CC 全宽；
  - LINK：状态卡 + API KEY 并排；
  - chip 行改成换行（不横向滚动），JOG 压到 92px。
- 矮屏（≤700px 高）：收装饰尺寸，不收可点尺寸。

---

## 7. 验证矩阵（真机 + CDP）

| 项 | 结果 |
|---|---|
| 五页布局 411×960 | 零溢出（内容长的页可滚） |
| 展开屏 822×910 | `grid 381px 381px`，两列生效 |
| 哼唱录音 | 开始/停止/电平正常，无崩溃 |
| 编曲 | `C major · 92 BPM · 4 小节 · 4 轨` |
| 和弦名 | `C / Am / F / G`，点击可试听 |
| 变体 | 4 个 |
| 骰子 | 随机参数全量生效 |
| 灵感 AI | 标题「夜行脉冲」+ 概念 + 自动播放 |
| AI LIVE | 自然播完 → 自动变异 → 继续播放 |
| 和弦垫 | BANK·CHORD 标签显示和弦名，点击发和弦 |
| 听懂鼓点 | 6 下 → `[2,1,2,0]` |
| 写回 STEM | 20 个鼓音 |
| 导出 .mid | 770B、91 note-on、tempo 92、结构逐字节校验 |
| 手表反馈 | ingest 后四轨 31/70/78/78%，MASTER 77 / BPM 111 / LOOP |
| JS 异常 | 0 |

---

## 8. 已知限制

1. **真实哼唱识别率**未由人声验证（离线音高算法正确；真机只验了录音链路）。
2. 音色是 **WebAudio 合成**，不是采样音源。
3. 手表**不接收**手机的编排（下行命令未做）；目前是手表 → 手机的反馈。
4. `MediaProjection` 抓播放声音的授权后链路尚未端到端验证。
5. 服务端历史不落盘（无写权限），历史只在手机 `localStorage`。
6. Mac 端 LLM 需要 key；没有 key 时对话退回关键词规则，灵感退回本地卡片。

---

## 9. 文件地图

```
device/app/app_*/                 四个手表 App
device/app/shared/grooved_capture.* 录制缓冲
device/tools/apply-app.sh         铺进 upstream
tools/grooved-serial-midi.swift   串口桥（手表 ↔ Mac MIDI/HTTP）
tools/grooved-capture.py          收帧合成 GIF
tools/frames-to-gif.py            裁帧重出 GIF
link/server.ts                    零依赖 HTTP/WS 服务
link/key.ts                       LLM key 唯一装载点
link/features/studio.ts           编曲引擎 + 灵感 + 对话
link/features/groove.ts           手机 → 手表/MIDI 协议
link/features/agents.ts           CrewTower 会话
link/features/midi.ts             Mac MIDI helper
android/app/src/main/assets/index.html   手机端全部 UI/逻辑
android/app/src/main/java/.../MainActivity.java       WebView 宿主 + 媒体/音频/文件桥
android/app/src/main/java/.../AudioCaptureService.java 播放声音 → CC
android/app/src/main/java/.../HumRecorder.java       麦克风 → YIN → 音符
android/build.sh                  无 Gradle 打包
```

---

## 10. 视觉系统：12 个 Dribbble 参考与采用点（2026-10-20 更新）

> 规则：**每个参考至少落两个点**，而且每个落点都必须是一个能操作/会动的组件，
> 不是一张贴图。下面每行都能在真机上指出来。

| # | 参考 | 采用点 ① | 采用点 ②（本轮新增） | 落在哪 |
|---|---|---|---|---|
| 1 | [Music — Slava Kornilov](https://dribbble.com/shots/25645360-Music) | 中心彩色核心 + 点阵轨道环 | **轨道会转**（46s 一圈）+ 背后超大 “Music” 字 + XL 展开 | `#tab-now` / `#discdots` / `.pword` |
| 2 | [Music Wave — Geex Arts](https://dribbble.com/shots/27241914-Music-Wave) | 彩色大圆按钮 | **细刻度轮**（SEQ 外圈 72 根）+ 黑胶下的实时波形带 | `.wavewheel` / `#seqring` / `#deckwave` |
| 3 | [Music Mix — Geex Arts](https://dribbble.com/shots/26761441-Music-Mix) | 底部中央发光 NOW + 玻璃卡 | **环境光晕**（三团缓慢漂浮的极光）+ 分层玻璃 | `.aurora` / `.aicard` / `.tabs` |
| 4 | [Music Play — Geex Arts](https://dribbble.com/shots/27260922-Music-Play) | 有机 blob | **对角线渐大的黑点**（无封面时的视觉）+ 全幅封面模糊底 + 圆盘进度环 | `#nfallback` / `#tab-now::before` / `#discprog` |
| 5 | [Dashboard](https://dribbble.com/shots/25706399-Music-App-Dashboard-UI-Concept) | 浮动走带条 + 多栏玻璃 | **浮动条里的实时波形** + 六格状态卡 | `#floatbar` / `#fbwave` / LINK 状态卡 |
| 6 | [ES Polyphonic Synth](https://dribbble.com/shots/18831756-ES-POLYPHONIC-SYNTH-VST) | 弧形进度旋钮 + 发光 chip | **LCD 屏**（显示最后动的旋钮 + 频谱） | `.fxknob` / `.lcd` |
| 7 | [Cruz GR MIDI](https://dribbble.com/shots/27771393-Cruz-GR-MIDI-Controller) | 彩色玻璃大垫 + 力度条 | **每轨 M/S + 力度格**（点阵上拖=重音） | `.pads` / `.seqtrk` / `.seqcell.v2` |
| 8 | [Mix Music — Geex Arts](https://dribbble.com/shots/26761233-Mix-Music) | 径向和弦弧 + 点阵步进 | **三个宏旋钮** + 径向 16 步轮 | `#chordarc` / `.seqmacros` / `#seqring` |
| 9 | [Vinyl Record Store](https://dribbble.com/shots/23424412-Vinyl-Record-Store-Mobile-App) | **红胶 + 唱臂**（可搓，松手有惯性） | **三段 EQ 推子 + NOISE/MAIN/VOCAL 三个实体旋钮**（全部接进音频链） | `.deck` / `#jog` / `.dfader` / `.dknob` |
| 10 | [Neumorphic Dark Volume Knobs](https://dribbble.com/shots/21408863-Neumorphic-Dark-Volume-Knobs) | 凸起外环 + 刻入刻度 | **凹井 + 彩色进度弧 + 小白点指针**（SVG 弧，不重绘 conic） | `.fxknob` |
| 11 | [Knóbz Skeuomorphic UI](https://dribbble.com/shots/14326768-Kn-bz-Skeuomorphic-UI-Sample-for-Figma) | 玻璃胶囊按钮（LED 点） | **高光玻璃垫 + 金属旋钮帽** | `.glassbtn` / `.pad` / `.dknob` |
| 12 | [Knob 03 — Light up the grill](https://dribbble.com/shots/22440734-Knob-03-Light-up-the-grill) | 铜色玻璃穹顶 + 斜向高光 | **34 点点阵灯圈**（跟着输出电平点亮） | `.dome` / `#grilldots` |

### 10.0.1 视频参考是怎么看的

Music Wave / Music Play 是视频 shot。上一轮只按静帧理解了「半圆轮 + 彩色按钮」，
这一轮把视频帧取下来后修正了两处：**按钮是正圆、不是方块**；
**底部是一圈很细的刻度轮**（不是粗弧）。落地成 `.wavewheel` 的 9 个圆垫
和 `#seqring` 的 72 根刻度。Music Play 的“斜向渐大黑点”也补进了无封面状态。

### 10.1 新增能力（同一轮）

- **采样音源**：`assets/samples/*.wav`（kick/snare/hat/clap/marimba/pluck/strings/choir，Python 合成）。
  WebView 在 `file://` 下 fetch 不到同目录文件 ⇒ 走原生 `AndroidFile.readAsset()` 读 base64，再 `decodeAudioData`。
- **手机 → 手表**：`G1 NP …` / `G1 SESS …` 经 server → bridge → `writeSerial()`；
  bridge 日志 `[to-device] …` 是唯一可观测到的证据（设备无回执）。保留片段时可 AUTO 同步。
- **MediaProjection 全链路已验**：授权后服务前台运行（`foregroundServiceType=mediaProjection`），
  播放时四段条 73/63/55/69%，server 收到 `G1 CC 1 23 115`。
- **Android 14+ 要显式请求整个屏幕**：`createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())`，
  否则默认弹的是"选一个 App"的单应用选择器。

### 10.2 本轮验证

```
旋钮      10 个 .fxknob + 4 个推子 .knob（类名分开，互不污染）
采样      8 个全部加载（kick/snare/hat/clap/marimba/pluck/strings/choir）
拖动       fxf 12000 → 7300
鼓垫      力度条 47%、hit 态、BANK·CHORD 显示和弦名
浮动走带   播放中 label=❚❚，标题=LOFI · C major
手机→手表  bridge: [to-device] NP LOFI · C major|GrooveD|1
投影      server lastLine=G1 CC 1 23 115，sent=2028
展开屏     822×910：两列 381+381，GROOVE 一屏装下
JS 异常    0
```

---

## 11. 组件清单（每个功能一个组件）

| 组件 | 选择器 / 文件 | 参考 | 说明 |
|---|---|---|---|
| **PLAYER** | `#tab-now` / `.disc` / `.pcard` | Music (Slava) | 白色播放器：会转的点阵轨道、模糊色谱核心、XL、耳机贴片、大走带、环形 MASTER、3×3 点阵、超大 “Music” 水印 |
| **ALBUM COVER** | `#cover` / `#nalbum` / `.ncover` | Vinyl + Music Play | 原生桥读 `METADATA_KEY_ALBUM_ART`/`ART`，168px JPEG base64 下行；无封面时用 5 个渐大黑点；下面一条小封面卡 |
| **MUSE AI** | `#nai` / `#disc` 点击 | — | 读当前歌名/歌手 → `/api/studio/ask`；离线时本地确定性建议；「做成律动」把 patch 写进 AI 参数并生成 |
| **VINYL DECK** | `.deck` / `#jog` / `#tonearm` | Vinyl Record Store | 奶油色面板、红胶凹槽、可转标签、唱臂；拖动=搓盘（惯性 + 压低通），松手归位 |
| **DECK MIXER** | `.dfader` / `#dmain` / `#dnoise` / `#dvocal` | Vinyl Record Store | 低/中/高三段 EQ；MAIN=MASTER；NOISE=真实底噪；VOCAL=2.8kHz presence |
| **NEUMORPHIC KNOB** | `.fxknob` × 13 | Neumorphic Dark Volume Knobs | 外环凸起、刻度刻入、凹井、SVG 进度弧、旋转白点；拖拽用 rAF 合帧，FILTER 走对数映射 |
| **LCD** | `.lcd` / `#lcdwave` | ES Poly | 显示最后动的旋钮与值 + 32 段频谱 |
| **GLASS GRILL** | `.dome` / `#grilldots` | Knob 03 | 铜色玻璃穹顶 + 斜向高光；34 点灯圈随输出电平亮；点一下触发 STUTTER |
| **GLASS BUTTONS** | `.glassbtn` | Knóbz | STUTTER / CLICK / JOG 0 三颗胶囊，LED 点与按下高光 |
| **PAD** | `.pad` | Cruz GR | 4×2 彩色玻璃垫、左上名称、右上音名、底部力度条 |
| **WAVE CHORDS** | `.wavewheel` / `.wavepad` | Music Wave | 9 个彩色正圆和弦垫（C/Am/F/G/Dm/Em/E7/Bm7/Gm），按下本地合成 + MIDI |
| **CHORD ARC** | `#chordarc` | Mix Music | 每小节一条彩色弧 |
| **SEQ 2.0** | `#tab-seq` / `#seqring` / `.seqcell` | Mix Music + Music Wave | 16 步径向轮、力度三档、M/S、模式 A–D、随机/移位/复制/概率/摆动/TAP/AI 生成/加花/本地试听 |
| **FLOAT BAR** | `#floatbar` / `#fbwave` | Dashboard | 曲名 / 播放 / BPM / 实时波形 |
| **AURORA** | `.aurora` | Music Mix | 三团缓慢漂浮的极光，按页面显隐 |
| **NAV** | `.tabs` | Music Mix | 底部中央发光 NOW 圆钮 |

### 11.0.1 这一轮修掉的两个“手感”问题

- **FILTER 旋转不跟手**：三个原因一起修 —— ① 每次 pointermove 都写 DOM + 重绘 conic-gradient
  ⇒ 改成 **rAF 合帧** + **SVG stroke-dasharray**；② 线性映射在低频段太粗 ⇒ 改**对数**；
  ③ 输入步长 50Hz ⇒ 改 10Hz。
- **多边形 blob 像一坨泥**：直接删掉那个 canvas，换成 Knob 03 的玻璃穹顶 + 灯圈。
  顶部那句 `requestAnimationFrame(drawBlob)` 也随之停掉（没有元素就不再自循环）。

### 11.1 最终一轮的修正

- **类名冲突**：播放器的 `.transport` 和 STEM 页的走带同名，导致 STEM 页出现一个 383px 的白色大圆。
  播放器改成 `.ptransport`，已修。
- **旋钮类名冲突**：新旋钮原先也叫 `.knob`，和 Stem 推子的白色滑块同名；改成 `.fxknob`。
- **视口适配**：播放器在宽屏用 `#tab-now.on{display:block}` 覆盖两列网格，保持单列构图。

### 11.2 仍与参考有差距的地方（如实记录）

1. **字体**：参考用几何无衬线（Circular/Inter 一类），当前用系统字体；未打包字体文件。
2. **播放器水印**：参考里 “Music” 在手机外面；我们把它做成页面内的低透明度水印（0.032）。
3. **圆盘点阵**：参考是弧段上大小交替的点；我们 32 个点、每 5 个加大，方向一致但数量不同。
4. **Material 光影**：参考是 3D 渲染级软阴影；我们用 CSS 多层阴影近似。
5. **像素级一致**需要逐屏截图对比 + 字体/图标资产，当前达到“同一套设计语言、结构一一对应”。

---

## 12. 2026-10-20 第二轮：logo / 白灰夜间 / 系统栏

| 项 | 实现 | 在哪 |
|---|---|---|
| **黑胶标签 logo + 歌名** | `logo-mark.png`（用户提供）→ 奶油标签 + `darken` 融合白底；歌名来自 `__media`，10 字截断 | `#jog` 的 `drawVinylDisc()` / `deckTitle` |
| **白灰渐变（夜间）** | 冷白→炭灰径向 + 纵向渐变；极光只剩白/灰；`color-scheme:dark` | `html,body` / `.aurora` |
| **状态栏/导航栏可见** | 移除沉浸式 flags；`setDecorFitsSystemWindows(true)`；Android 15 `windowOptOutEdgeToEdgeEnforcement` | `MainActivity` / `res/values/styles.xml` / manifest |
| **系统栏动态配色** | `AndroidMedia.setSystemBars()`；NOW 米白+深图标，其余夜间灰+白图标 | `MediaBridge` / `paintSystemBars()` |
| **离线生成兜底** | SEQ / GROOVE 生成失败时按风格密度本地随机，并如实标注 | `#seqgen` / `#genbeat` 的 catch |
| **真机系统栏** | 已装 SM-F9660 (SDK 36)：WebView `screenY=110 / h=2371`，页面 `innerHeight=903`（整屏 960）⇒ 状态栏+导航栏在 WebView 外 | `adb` + WebView CDP `/json` |


---

## 13. 2026-10-20 第三轮：NOW 首页 / 浅色 / PERFORM / Cospon D

| 项 | 实现 | 在哪 |
|---|---|---|
| **NOW 首页** | 默认 tab = now；底部 NOW 默认高亮 | `<body data-tab="now">` / tabs |
| **玻璃大标题** | `CEVTUO D`，浅色白玻璃 / 夜间低透明白字 | `.bigmark` |
| **删除圆盘黑点** | `#nfallback` 移除 | `#disc` |
| **CEVTUO NOW AI** | 徽标、面板标题、提示全部改名 | `#dbadge` / `.naihead` / `#naihint` |
| **CEVTUO Groove AI** | 原 INSPIRE 按钮 + `aiby` 来源文案 | `#inspire` / `inspireNow` |
| **默认浅色 + 夜间按钮** | `data-theme` + localStorage；顶栏 & NOW 两个 ☾/☀ | `applyTheme()` / `.themebtn` |
| **系统栏跟随主题** | 浅色 `#F4F5F7` 深图标；NOW 米白；夜间 `#15171B` 白图标 | `paintSystemBars()` |
| **播放圆盘指针** | 绕圆心的 `.ringrotor` + rAF | `#ringknob` |
| **PERFORM 穹顶** | 74px、白色指针、拖动旋转、灯圈按方向亮、映射 ENERGY | `#dome` / `layoutGrill()` / `meterLoop()` |
| **折叠屏** | `ResizeObserver` + `.vinylwrap` + 切页重新量 | `fitJog()` / `layoutGrill()` |
| **Cospon D 自启** | 两个 LaunchAgent + `tools/grooved.sh`；LINK 显示 Agent 1/0 与会话 | `~/Library/LaunchAgents` / LINK |
| **手机 LAN** | 服务监听 `0.0.0.0:8765`，HOST 填局域网 IP 即可 | `GROOVED_HOST` |

---

## 14. 2026-10-20 第四轮：手表 Cospon D 消息 / 审批 / Wi-Fi

| 项 | 实现 | 在哪 |
|---|---|---|
| **最近 3 条消息** | `MSG` 行带 user/assistant 最近 3 条；`_msgs[SLOTS][3][180]`；详情页独立滚动 | `link/features/agents.ts` `readMessages()` / `app_cospon.cpp` `_msgs` |
| **不再只显示 no activity** | 卡片活动行为空时退回最新一条消息；有消息就显示消息摘要 | `apply_row()` |
| **ALLOW / DENY 两个键** | 有待批时浮层出现；发送 `G1 PERM <id> allow|deny`；桥转 `/api/agents/decide` | `_perm_panel` / `show_perm()` / `send_perm()` |
| **WIFI 一键** | `GetHAL().setWifiEnabled(true)`；无凭据进配置 AP；连上后 2s 轮询 `/api/agents/watch` | `_wifi_btn` / `wifi_poll_task()` |
| **Mac 地址进 NVS** | `NET <ip>` → namespace `grooved` / key `net`，重启不丢 | `load_net_host()` / `save_net_host()` |
| **USB 与 Wi-Fi 同一套协议** | 两条链路都送进 `handle_line()`，不分叉 | `app_cospon.cpp` |
| **手机发送 Mac 地址** | LINK「发送 Mac 地址到手表」→ `/api/groove/status` 的 `lanIp` → `NET` | `#m5net` handler |
| **语音键** | 未实现（按用户指示，难则跳过）；下一窗口若做，放在一轮结束 idle 时，作为第三键 | — |

**验证状态**：固件已构建并刷入（RAM 30.7% / Flash 85.2%，写入+校验通过）；
MSG/PERM/decide 链路已用 HTTP 验证；**手表 Wi-Fi 与权限浮层尚未在真机完整走一次**。

### 14.1 消息选择与字节安全

- `readMessages()` 先收 16 条、滤掉图片占位/续接摘要/工具结果/中断提示，再取最后 3 条；
  每条 48 字。这样最新的 assistant 回复不会被 3 条 user 消息挤掉。
- `/api/agents/watch` 按 UTF-8 字节裁字段（agent/app 36、state 18、activity 110、
  message 150、perm detail 110），对应手表 `activity[120]` / `_msgs[..][180]` 的缓冲区。
- 实测返回 `user / assistant / user` 三条，`PERM` 从出现到 `decide` 后消失全链路通过。

---

## 15. 2026-10-20 第五轮：COSPON D 对话 / 两个动作 / 字体 / SWSH 页

| 项 | 实现 | 在哪 |
|---|---|---|
| **快照不闪** | `AG → SESS* → MSG* → END`；END 才提交 stage 并重画 | `app_cospon.cpp` `_snap/_stage` |
| **不显示宿主 App** | 卡片标题=project、副标题=agent、右侧=age；不再显示 `d.app` | `apply_row()` / `fill_detail()` |
| **最近 8 条** | 服务端收 32 条、滤噪声、取 8；每条 70 字 | `readMessages()` |
| **展开以对话为主** | 隐藏圆环/指标；消息区 288×290、flex + WRAP + 自适应高度、可滚动 | `_detail_msgs` / `_dm` |
| **不再长方形** | 12px/1BPP 全 CJK + 中文标点/全角；服务端/桥过滤无字形字符 | `lv_font_grooved_cjk12.c` / `clipMsg()` / `sanitize()` |
| **WIFI 双向** | 开→关/关→开；按钮显示 action，状态行显示状态 | `wifi_cb()` |
| **CONTINUE** | Codex：`codex exec resume`；其它：复制提示词 | `/api/agents/action` |
| **HANDOFF** | 写 `docs/handoff-时间.md` + pbcopy 提示词 | `/api/agents/action` |
| **两个键只在 idle** | `fill_detail` 按 `state == idle` 显隐 | `_act_continue/_act_handoff` |
| **launchd TCC** | 服务复制到 `~/Library/Application Support/grooved-link`，`grooved.sh` 自动同步 | `com.cevtuo.grooved-link.plist` / `grooved.sh` |
| **分发页** | SWSH 版式，3490 中文字，8 段录屏 + 6 手表图 | usersite `xd/index.html` |

**未验**：手表 Wi-Fi 端到端、权限 hook、Claude CLI resume、真实会话的 COSPON 录屏。

---

## 16. 2026-10-20 第六轮：Wi-Fi 轮询读不满整份快照（"连上了却什么都不显示"）

| 项 | 结论 |
|---|---|
| **症状** | 手表 Wi-Fi 打开并连上路由器，拔掉 USB 后 COSPON D 一直没有任何会话内容；USB 模式下同一份数据正常。 |
| **根因** | `wifi_poll_task()` 只调用一次 `esp_http_client_read(cli, buf, 4095)`。`/api/agents/watch` 最多 3 个会话 × 8 条消息（单条 230 字节上限），整份快照上限约 **6.8KB**；`END` 落在后 2.7KB，固件永远收不到提交信号。 |
| **为什么 USB 没事** | 串口桥是逐行写 `AG/SESS/MSG/PERM/END`，没有单次 4KB 读取上限。 |
| **修复** | 按块循环读到 `esp_http_client_is_complete_data_received()`；16KB 响应缓冲；每个响应开始前 `_snap=false`；超时 1500→3000ms。 |
| **可诊断性** | 状态行显示 `WIFI <ip> \| NO HOST / CONN FAIL / SHORT / EMPTY`；底部 `LIVE` / 具体失败原因，不再统一显示 `NO BRIDGE`。 |
| **构建** | PlatformIO 构建 + 刷入通过；RAM 28.3%、Flash 95.2%（4,929,085 / 5,177,344 bytes）。 |
| **发布** | 新增 `CEVTUO-XD-firmware.zip`（源码 + 字体 + bin + flash 脚本）和 `CEVTUO-XD-mac.zip`；生成脚本 `device/tools/make-package.sh`。 |
| **未验** | 还需要真机完整走一次：配网 → LINK 发 Mac 地址 → 拔 USB → 观察状态行与轮询。 |

**判据（下次先量这个）**：`curl http://<Mac-IP>:8765/api/agents/watch | wc -c` 必须在 4KB 上下浮动；
按 3 会话 × 8 条 × 230 字节算出的上限是 ~6.8KB，任何"只读一次固定缓冲"的实现都会被它咬到。

---

## 17. 2026-10-20 第七轮：应用矩阵 / 实机截图 / 消息与动作回执

| 项 | 结论 |
|---|---|
| **分发页应用矩阵** | 六个应用集中列出：GrooveD / Stem D / Groove D / COSPON D / Muse D / CEVTUO XD Web；每个带 logo、章节跳转和下载。 |
| **截图** | 6 张手机实机截图（SM-F9660）+ Mac 网页控制台截图；不是设计稿。 |
| **Slogan** | `Music AI OS for makers` 改为小字；主标题改为 `CEVTUO XD`。 |
| **移除** | 分发页不再列「还没做到 / 需要你」。 |
| **COSPON D 只有用户消息** | Cherry Studio transcript 里 assistant 正文只在一轮结束时落盘，进行中只有 thinking / tool_use。`readMessages()` 反向扫描时若最新是 `tool_use`/`thinking`，补一条「正在调用 <工具>：<描述>」。 |
| **动作回执** | 旧版写 `_detail_state`，每 2 秒被快照覆盖；现在单独存 `_act_status` + 20 秒过期，详情和底栏都显示 `ACT … READY/FAIL`。 |
| **剪贴板假成功** | launchd 服务里 `pbcopy` 退出 0 但 `pbpaste` 为空，接口却回 `copied:true`。现在写入后读回校验，失败改用 `osascript` 写剪贴板；`ok` 同时要求文件与剪贴板都成功。 |
| **实测** | CONTINUE / HANDOFF 都 `ok:true, copied:true`，`pbpaste` 读得到提示词；HANDOFF 写 `docs/handoff-20261020-1438.md`。 |
| **固件** | 重新构建并刷入：RAM 28.3%（92,756 / 327,680），Flash 95.2%（4,929,813 / 5,177,344）。 |

---

## 18. 2026-10-20 第八轮：COSPON D 复古硬件界面 / 过程与计时 / CONTINUE 注入

| 项 | 结论 |
|---|---|
| **视觉语言** | 参考复古手持设备：纯黑屏、米白文字、单一橙色呼吸点、全大写点阵标签。英文标签/数字用 LVGL 自带 `unscii_8/16`（`apply-app.sh` 会打开对应 Kconfig），中文正文仍用 12px CJK 字体。 |
| **圆盘安全布局** | 详情页铺一层整屏黑底 + 430×430 圆形面板；标题、状态、两侧信息柱、中间列表、底部按键全部按半径 215 的圆计算，按钮从旧的 y=350 上移到 338，避免被表盘压角。 |
| **两侧信息** | 左柱 `CTX`：上下文百分比 / tokens；点一下切换 `CHAT ↔ STEPS`。右柱 `TURN`：本轮耗时（分/秒）。 |
| **过程列表** | 服务端从 transcript 反向取最近 6 次 `tool_use`，`/watch` 发 `STEP <slot>|<text>`；固件在 STEPS 视图显示。 |
| **本轮计时** | 服务端 `turnSec` = 现在 − 最后一条 user 消息时间；`SESS ...|age|turnSec`。固件显示 `WORKING/WAITING/IDLE  Xm Ys`，卡片状态行也带分钟。 |
| **最新对话居中** | 消息区内容变化时，按最后一条消息的矩形中心把滚动位置调到列表中线；内容没变不重排，用户滚动不会被拉回。 |
| **呼吸点** | working 时橙色 8px 点 900ms 明暗循环；其它状态常亮状态色。 |
| **CONTINUE（Cherry/Claude）** | Cherry 没有 CLI resume，也没有会话注入 HTTP API（23333 只有 LLM 代理）。改成 UI 自动化：激活 Cherry → 校验前台确实是 Cherry Studio → 点输入框 → Cmd+V → Return（working 时 Shift+Return 立即引导）。**前台不是 Cherry 就报错，绝不往别的 App 粘。** |
| **消息过滤** | 去掉 `No response requested.` 这类系统占位，避免占掉最近 8 条。 |
| **固件** | RAM 29.2%（95,796 / 327,680），Flash 95.3%（4,935,709 / 5,177,344）。 |
| **未验** | 真机触摸滚动、STEPS 切换、CONTINUE 注入、Wi-Fi 端到端仍需本人操作确认。 |

### Wi-Fi 端到端验证（必须记着）

1. COSPON D → `WIFI ON`。
2. 手机连 `M5StopWatch-XXXX` 配置 AP，填家里 Wi-Fi。
3. 回手机 App 的 LINK 页按「发送 Mac 地址到手表」。
4. 拔掉 USB，看状态行：正常 `WIFI 192.168.x.x`，底部 `LIVE`。
   - `NO HOST`：Mac 地址没发到。
   - `CONN FAIL`：Mac 服务/防火墙（必须监听 `0.0.0.0:8765`）。
   - `SHORT`：响应仍不完整。
