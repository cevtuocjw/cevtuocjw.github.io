# CEVTUO XD · Mac 宿主服务

手表上的 COSPON D 显示的是 Mac 上 agent 会话的状态；手机 App 的 MIDI / 编曲 / AI 也走这里。
Mac 端没有 UI，只有两个常驻进程：

| 进程 | 作用 |
|---|---|
| `grooved-link`（Deno） | HTTP `:8765`：编曲引擎、LLM、agent 快照、审批队列、动作 |
| `grooved-bridge`（Swift） | USB 串口桥：把 `AG/SESS/MSG/PERM/END` 写给手表，把 `G1 ...` 读回来 |

## 安装

```bash
bash install.sh          # 需要 deno（brew install deno）
bash install.sh uninstall
```

安装位置是 `~/Library/Application Support/grooved-{link,bridge}/`。
**不要**把服务放在 `~/Documents` 下：launchd 没有那个目录的 TCC 权限，
进程会卡在 `open()` —— 活着、日志也正常，但端口永远不监听。

验证：

```bash
curl -s http://127.0.0.1:8765/health
curl -s http://127.0.0.1:8765/api/agents/list
lsof -nP -iTCP:8765 -sTCP:LISTEN        # 必须是 0.0.0.0:8765，手表才能从局域网访问
```

## 关键环境变量

- `GROOVED_HOST=0.0.0.0`：Wi-Fi 直连必须。默认 `127.0.0.1` 只够 `adb reverse` 用。
- LLM key：手机 LINK 页填 `sk-…`，写到 `~/.grooved/llm.key`。
- 会话来源：读 CrewTower 的机器级会话表，不额外挂 hook。

## 重新编译串口桥

```bash
swiftc -O tools/grooved-serial-midi.swift -o tools/grooved-serial-midi
```

包里带的是 Apple Silicon 二进制；Intel Mac 请按上面这条重新编译。
