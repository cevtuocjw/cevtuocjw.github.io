#!/usr/bin/env bash
# 安装 Mac 端：Deno 服务 + 串口桥，并注册 LaunchAgent（登录自启）。
#   bash install.sh            # 安装并启动
#   bash install.sh uninstall  # 卸载
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
UID_N="$(id -u)"
LA="$HOME/Library/LaunchAgents"
SUP="$HOME/Library/Application Support"
LABELS=(com.cevtuo.grooved-link com.cevtuo.grooved-bridge)

if [ "${1:-install}" = "uninstall" ]; then
  for l in "${LABELS[@]}"; do launchctl bootout "gui/$UID_N/$l" >/dev/null 2>&1 || true; rm -f "$LA/$l.plist"; done
  echo "uninstalled"; exit 0
fi

DENO="$(command -v deno || true)"
[ -x "$DENO" ] || { echo "✗ 没找到 deno（brew install deno）"; exit 1; }

mkdir -p "$LA" "$HOME/Library/Logs"
# ⚠️ launchd 读 ~/Documents 会被 TCC 卡住（进程活着但端口不 bind），所以装到 Application Support。
mkdir -p "$SUP/grooved-link" "$SUP/grooved-bridge"
rsync -a --delete "$ROOT/link/" "$SUP/grooved-link/"
cp "$ROOT/tools/grooved-serial-midi" "$SUP/grooved-bridge/"
chmod +x "$SUP/grooved-bridge/grooved-serial-midi"

cat > "$LA/com.cevtuo.grooved-link.plist" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.cevtuo.grooved-link</string>
  <key>ProgramArguments</key><array>
    <string>$DENO</string><string>run</string>
    <string>--allow-net</string><string>--allow-env</string>
    <string>--allow-read</string><string>--allow-write</string>
    <string>--allow-run</string><string>--allow-sys</string>
    <string>--unstable-net</string><string>--no-config</string>
    <string>$SUP/grooved-link/server.ts</string>
  </array>
  <key>WorkingDirectory</key><string>$HOME</string>
  <key>EnvironmentVariables</key><dict>
    <key>GROOVED_HOST</key><string>0.0.0.0</string>
  </dict>
  <key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$HOME/Library/Logs/grooved-link.log</string>
  <key>StandardErrorPath</key><string>$HOME/Library/Logs/grooved-link.log</string>
</dict></plist>
PL

cat > "$LA/com.cevtuo.grooved-bridge.plist" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.cevtuo.grooved-bridge</string>
  <key>ProgramArguments</key><array>
    <string>$SUP/grooved-bridge/grooved-serial-midi</string>
  </array>
  <key>WorkingDirectory</key><string>$HOME</string>
  <key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$HOME/Library/Logs/grooved-serial.log</string>
  <key>StandardErrorPath</key><string>$HOME/Library/Logs/grooved-serial.log</string>
</dict></plist>
PL

for l in "${LABELS[@]}"; do
  launchctl bootout "gui/$UID_N/$l" >/dev/null 2>&1 || true
  launchctl bootstrap "gui/$UID_N" "$LA/$l.plist"
done
sleep 1
curl -s --max-time 3 http://127.0.0.1:8765/health && echo
echo "installed; logs: ~/Library/Logs/grooved-*.log"
