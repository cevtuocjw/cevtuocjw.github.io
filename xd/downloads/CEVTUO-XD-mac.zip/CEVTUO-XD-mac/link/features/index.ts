/**
 * 功能注册表 —— **只有这一份**。
 *
 * 服务端从这里拿全部功能，手机/设备也从 `/api/features` 拿同一份名字。
 * 两边各写一份的症状是「加了一个功能，但手机上永远不出现」——
 * 而那种错**一个日志都不会有**（这个项目在模式表上已经吃过一次，
 * 见 `protocol.ts` 的 MODE_HUE 注释）。
 *
 * ⚠️ 加新功能：写 `link/features/<id>.ts`，在这里加一行。
 *   **别去改 server.ts** —— 它不认识任何一个具体功能，这是刻意的。
 */
import { createAgentsFeature } from "./agents.ts";
import { createMidiFeature } from "./midi.ts";
import { createGrooveFeature } from "./groove.ts";
import { createMediaFeature } from "./media.ts";
import { createStudioFeature } from "./studio.ts";
import type { Feature } from "./types.ts";

export type { Feature, FeatureCtx, FeatureId, DeviceSnapshot } from "./types.ts";

export function createFeatures(): Feature[] {
  return [
    createAgentsFeature(),
    createMidiFeature(),
    createGrooveFeature(),
    createMediaFeature(),
    createStudioFeature(),
  ];
}

// ⚠️ **不要**在这里导出 `FEATURE_TITLES = createFeatures().map(...)` 之类的常量。
// 那会**再建一套功能实例**（各带自己的状态、自己的 rev），于是"名字"和"数据"
// 来自两个互不相干的副本 —— 正是这个文件开头在防的那件事。
// 名字从 `createFeatures()` 拿到的**同一份**实例上读。
