/**
 * Stem / Groove 功能 —— 手机（或任何 HTTP 客户端）→ 手表 / Mac MIDI 的控制入口。
 *
 * 链路：
 *   Android App ──HTTP──▶ 本服务 /api/groove/send
 *                        └──TCP 127.0.0.1:9001──▶ tools/grooved-serial-midi
 *                                                 └──▶ CoreMIDI（以及写不写回串口由它决定）
 *
 * ⚠️ 为什么走 TCP 不走 UDP：实测 UDP "每条一个连接"的写法会丢第 4 条，
 *    而丢一条控制消息的后果是"推子不动"，且**没有任何报错**。
 * ⚠️ 协议只认行首 `G1 `：和设备串口是同一套，别在这里另造一种格式。
 */
import type { Feature, FeatureCtx } from "./types.ts";

const HOST = "127.0.0.1";
const PORT = 9001;

let conn: Deno.Conn | null = null;
let lastLine = "";
let lastAt = 0;
let sent = 0;
let lastError = "";

/** 手表推上来的那一份状态。手机靠它把手表上的动作**显示出来**（双向的第一步）。 */
const state = {
  stems: [100, 100, 100, 100],
  mutes: [false, false, false, false],
  solos: [false, false, false, false],
  master: 100,
  loop: false,
  fx: 0,
  bpm: 120,
  playing: false,
  updatedAt: 0,
};
let rev = 0;

/** Mac 的局域网 IPv4：手机把它发给手表，WiFi 轮询才知道连哪。 */
function getLanIp(): string {
  try {
    for (const a of Deno.networkInterfaces()) {
      const fam = String(a.family);
      if ((fam === "IPv4" || fam === "4") &&
          !a.address.startsWith("127.") && !a.address.startsWith("169.254.")) {
        return a.address;
      }
    }
  } catch { /* 没有网络接口就返回空 */ }
  return "";
}

async function writeLine(line: string): Promise<void> {
  const data = new TextEncoder().encode(line + "\n");
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      if (!conn) {
        conn = await Deno.connect({ hostname: HOST, port: PORT });
      }
      await conn.write(data);
      lastLine = line;
      lastAt = Date.now();
      sent++;
      lastError = "";
      return;
    } catch (e) {
      // 连接死了（bridge 重启）⇒ 关掉重连一次，第二次还失败就如实抛。
      try { conn?.close(); } catch { /* 已经断了 */ }
      conn = null;
      lastError = String(e);
      if (attempt === 1) throw e;
    }
  }
}

export function createGrooveFeature(): Feature {
  return {
    id: "groove",
    title: "Stem",

    routes: {
      /** POST /api/groove/send  { line: "G1 STEM 0 64" } 或 { lines: [...] } */
      "/send": async (req: Request, ctx: FeatureCtx) => {
        if (req.method !== "POST") return ctx.json({ error: "POST only" }, 405);
        let body: { line?: unknown; lines?: unknown };
        try {
          body = await req.json();
        } catch {
          return ctx.json({ error: "bad json" }, 400);
        }
        const list: string[] = [];
        if (typeof body.line === "string") list.push(body.line);
        if (Array.isArray(body.lines)) {
          for (const l of body.lines) if (typeof l === "string") list.push(l);
        }
        if (!list.length) return ctx.json({ error: "need line or lines" }, 400);
        if (list.length > 32) return ctx.json({ error: "too many lines" }, 400);

        for (const line of list) {
          // 只放行协议行；长度上限防一条垃圾把 bridge 撑爆。
          // SESS 一行的字段多（agent|app|state|activity|tokens|limit|project|age），
          // 64 不够；上限放到 240，仍然防一条垃圾把 bridge 撑爆。
          if (!line.startsWith("G1 ") || line.length > 240 || line.includes("\n")) {
            return ctx.json({ error: `bad line: ${line.slice(0, 24)}` }, 400);
          }
        }
        try {
          for (const line of list) await writeLine(line);
          return ctx.json({ ok: true, sent: list.length });
        } catch (e) {
          return ctx.json({ ok: false, error: String(e) }, 503);
        }
      },

      /** GET /api/groove/status —— 给手机端判断"bridge 在不在" */
      /** POST /api/groove/ingest {line} —— 手表/串口那边发来的状态，只用来同步显示 */
      "/ingest": async (req: Request, ctx: FeatureCtx) => {
        if (req.method !== "POST") return ctx.json({ error: "POST only" }, 405);
        let body: { line?: unknown; lines?: unknown };
        try { body = await req.json(); } catch { return ctx.json({ error: "bad json" }, 400); }
        const list: string[] = [];
        if (typeof body.line === "string") list.push(body.line);
        if (Array.isArray(body.lines)) for (const l of body.lines) if (typeof l === "string") list.push(l);
        for (const line of list) {
          const p = line.replace(/^G1 /, "").split(" ");
          const n = (i: number, d = 0) => Number(p[i] ?? d);
          switch (p[0]) {
            case "STEM": { const i = n(1); if (i >= 0 && i < 4) state.stems[i] = n(2); break; }
            case "MUTE": { const i = n(1); if (i >= 0 && i < 4) state.mutes[i] = n(2) !== 0; break; }
            case "SOLO": { const i = n(1); if (i >= 0 && i < 4) state.solos[i] = n(2) !== 0; break; }
            case "MASTER": state.master = n(1); break;
            case "LOOP": state.loop = n(1) !== 0; break;
            case "FX": state.fx = n(1); break;
            case "BPM": state.bpm = n(1); break;
            case "START": case "CONT": state.playing = true; break;
            case "STOP": state.playing = false; break;
          }
        }
        state.updatedAt = Date.now();
        rev++;
        return ctx.json({ ok: true });
      },

      "/status": (_req: Request, ctx: FeatureCtx) =>
        ctx.json({
          sent,
          lastLine,
          lastAt,
          ageSec: lastAt ? Math.round((Date.now() - lastAt) / 1000) : null,
          error: lastError || null,
          lanIp: getLanIp(),
        }),
    },

    snapshot() {
      return { sent, lastLine, lastAt, state };
    },

    rev() {
      return sent + rev;
    },
  };
}
