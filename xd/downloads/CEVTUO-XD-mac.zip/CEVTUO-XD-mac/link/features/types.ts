/**
 * 「一个功能」在这里是什么意思。
 *
 * ── 读者 2026-10-16 定的规矩 ─────────────────────────────────────
 * 「**midi 功能、agent 功能还有其他功能都是分开的功能，不是合在一起的**」。
 *
 * 所以每个功能是一个**自足模块**：自己的状态、自己的路由、自己给设备/手机的那一份快照。
 * 服务端不认识任何一个具体功能，它只知道"有一串 Feature"。
 *
 * ⚠️ 为什么不是"一个大 server.ts 里分几段 if"：
 *   那种写法**看起来**也分开了，但每加一个功能都要去改那个大文件，
 *   而且功能的边界只存在于注释里 —— 删掉一个功能的残留会散落在三处。
 *   这个项目已经吃过一次同形状的亏（模式表抄了三份）。
 *
 * ⚠️⚠️ 但**别为了"分开"去造抽象**。这里的 Feature 只有四件事，
 *   而且每一件都是服务端**必须**知道的（要挂路由、要推快照、要算变更）。
 *   任何"只服务于某一个功能"的东西都不该出现在这个接口上。
 */

export type FeatureId = "agents" | "midi" | "pet" | "groove" | "media" | "studio";

export interface DeviceSnapshot {
  online: boolean;
  /** 设备上报的那一份；离线时是**最后一次收到**的，不要拿它当"现在"。 */
  state: unknown;
}

export interface FeatureCtx {
  /** 设备状态（只读）。功能可以据此决定自己推什么。 */
  device(): DeviceSnapshot;
  /** 请求一次广播 —— 功能自己知道什么时候变了。 */
  broadcast(): void;
  /**
   * **现在有没有人在看**（手机开着页面 / 设备在线）。
   *
   * ⚠️ 这个不是装饰：`grooved-hook` 靠它决定"要不要等一下"。
   * 没人在看的时候还傻等 25 秒，等于**每一次权限确认都平白慢 25 秒** ——
   * 而人在电脑前的时候，那 25 秒纯粹是浪费。
   */
  watchers(): number;
  json(o: unknown, status?: number): Response;
}

export interface Feature {
  id: FeatureId;
  /** 手机/设备上显示的名字。**唯一真源** —— 前端不许再抄一份。 */
  title: string;
  /**
   * 这个功能自己的路由。
   *
   * 键是**相对路径**（`""` = 根，`/decide` = `/api/<id>/decide`），
   * 服务端负责拼前缀。功能之间不能互相挂路由。
   */
  routes: Record<string, (req: Request, ctx: FeatureCtx) => Response | Promise<Response>>;
  /** 推给客户端的那一份。必须 JSON 可序列化，且**不许包含函数/循环引用**。 */
  snapshot(): unknown;
  /**
   * 单调递增的版本号。**变了才广播** —— 每 2 秒无脑广播会让
   * `snapshot()` 里的 `ageSec` 这种"每秒都在变"的字段把整条通道塞满。
   */
  rev(): number;
  /**
   * 可选的周期性工作（每 2 秒调一次）。抛异常不许炸掉别的功能。
   *
   * ⚠️ 它**要收 ctx**：功能需要从设备状态推自己的状态（midi 的"在不在走"就是）。
   * 第一版签名是 `tick(): void`，于是 midi 那边只能留一个空的 tick ——
   * 而 `running` 永远是 false ⇒ **时钟一条都不发**，测试也没测出来
   * （因为它"没报错、接口也回 200"）。实测：3 秒 / 120BPM 期望 144 条，实际 15 条。
   */
  tick?(ctx: FeatureCtx): void;
  /** 健康/诊断用的一行字。 */
  status?(): string;
}
