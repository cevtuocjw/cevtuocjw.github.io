/**
 * MIDI 功能的纯函数测试。
 *
 * ⚠️ 这一层**测不到"真的发出去了没有"** —— 那要靠 `tools/midi-probe`
 * 在接收端量（见工具注释：计数器不是证据）。这里测的是"值算得对不对"。
 * **两层都要有，而且不能互相冒充。**
 */
import assert from "node:assert/strict";
import {
  ccBytes,
  createMidiFeature,
  isRunning,
  labelOf,
  levelToCC,
  MODE_NOTE,
  modeNote,
  noteBytes,
} from "./midi.ts";
import type { FeatureCtx } from "./types.ts";

Deno.test("isRunning：离线时**不许**算在走（拔了线时钟还在跑是最坏的）", () => {
  assert.equal(isRunning(true, 120), true);
  assert.equal(isRunning(false, 120), false);
  assert.equal(isRunning(true, 0), false);
  assert.equal(isRunning(true, NaN), false);
  assert.equal(isRunning(false, 0), false);
  // 怎么才会红：把 `online &&` 去掉。
  // ⚠️ 这条不是洁癖：设备可能**刚推完一帧就掉线**，那时 BPM 还留着上次的值，
  // 而人就站在拔了线的板子前面 —— DAW 那边节拍器还在跑，他找不到原因。
});

Deno.test("levelToCC：夹进 0..127，越界不许漏出去", () => {
  assert.equal(levelToCC(0), 0);
  assert.equal(levelToCC(1), 127);
  assert.equal(levelToCC(0.5), 64);
  assert.equal(levelToCC(9.9), 127, "越界没夹紧 —— 会发出非法字节");
  assert.equal(levelToCC(-3), 0);
  assert.equal(levelToCC(NaN), 0);
  // 怎么才会红：把 Math.max/min 那一对去掉。
  // ⚠️ MIDI 数据字节的最高位必须是 0；128 会被接收端当成状态字节，
  // 把流**从那里拆错位**（后面所有消息都乱），而本地一点异常都没有。
});

Deno.test("modeNote 六个模式各一个音，未知的退回默认", () => {
  const notes = Object.keys(MODE_NOTE).map(modeNote);
  assert.equal(new Set(notes).size, notes.length, "有两个模式撞了同一个音");
  assert.equal(modeNote("NOW"), 60);
  assert.equal(modeNote("不存在的模式"), 60);
  // 怎么才会红：把 MODE_NOTE 里两个值改成一样。
  // ⚠️ 撞音的症状是"切到某个模式，Mac 上没反应" —— 用户会以为模式切换坏了。
});

Deno.test("字节构造：note on/off 与 CC 的形状", () => {
  assert.deepEqual(noteBytes(60, true), [0x90, 60, 100]);
  assert.deepEqual(noteBytes(60, false), [0x80, 60, 0]);
  assert.deepEqual(ccBytes(1, 64), [0xb0, 1, 64]);
  assert.deepEqual(ccBytes(1, 999), [0xb0, 1, 127], "越界没夹紧");
  // 怎么才会红：把 `| MIDI_CHANNEL` 去掉 ⇒ 通道变成 0x0F。
});

Deno.test("labelOf：人看得懂（手机监视器就靠它）", () => {
  assert.equal(labelOf([0xf8]), "clock");
  assert.equal(labelOf([0xfa]), "start");
  assert.equal(labelOf([0xfc]), "stop");
  assert.equal(labelOf(noteBytes(60, true)), "note on  ch1 60 vel100");
  assert.equal(labelOf(noteBytes(60, false)), "note off ch1 60");
  assert.equal(labelOf(ccBytes(1, 64)), "cc1 ch1 = 64");
  // velocity=0 的 note on 在 MIDI 里等价于 note off —— 显示上必须说 off，
  // 否则监视器里会看到一串 "note on vel0"，读起来像 bug。
  assert.equal(labelOf([0x90, 60, 0]), "note off ch1 60");
});

Deno.test("功能契约：路由、快照可序列化、panic 会记两条", () => {
  const f = createMidiFeature();
  assert.equal(f.id, "midi");
  for (const k of ["/now", "/port", "/sent", "/panic", "/log", "/status"]) {
    assert.ok(f.routes[k], `缺路由 ${k}`);
  }
  const ctx: FeatureCtx = {
    device: () => ({ online: true, state: { bpm: 120, level: 0.5, mode: "NOW" } }),
    broadcast: () => {},
    watchers: () => 0,
    json: (o, s = 200) => new Response(JSON.stringify(o), { status: s }),
  };
  const snap = f.snapshot();
  assert.doesNotThrow(() => JSON.stringify(snap));
  // 没起 helper 的时候 helperAlive 必须是 false —— 否则界面上永远显示"运行中"。
  assert.equal((snap as { helperAlive: boolean }).helperAlive, false);

  (f.routes["/panic"] as (r: Request, c: FeatureCtx) => Response)(new Request("http://x/"), ctx);
  const recent = (f.snapshot() as { recent: { label: string }[] }).recent;
  assert.equal(recent.length, 2, "panic 应当同时发 CC123 和 CC120");
  assert.deepEqual(recent.map((m) => m.label), ["cc123 ch1 = 0", "cc120 ch1 = 0"]);
  // 怎么才会红：panic 里只发一个 CC。
  // ⚠️ 两个都发是因为有些音源只认其中一个 —— 而这是"救急"按钮，不能只救一半。
});

Deno.test("/now 现算 playing（不等 tick 那 2 秒）", async () => {
  const f = createMidiFeature();
  const mkCtx = (online: boolean, bpm: number): FeatureCtx => ({
    device: () => ({ online, state: { bpm, level: 0, mode: "NOW" } }),
    broadcast: () => {},
    watchers: () => 0,
    json: (o, s = 200) => new Response(JSON.stringify(o), { status: s }),
  });
  const playing = async (c: FeatureCtx): Promise<boolean> => {
    const out = (f.routes["/now"] as (r: Request, c: FeatureCtx) => Response | Promise<Response>)(
      new Request("http://x/"), c);
    return ((await (await Promise.resolve(out)).json()) as { playing: boolean }).playing;
  };

  // ⚠️ 直接调 /now，**不调 tick** —— 第一版 playing 只在 tick 里更新，
  // 于是按下走带之后时钟要晚 2 秒才起步（实测：节拍器晚 2 秒等于没用）。
  assert.equal(await playing(mkCtx(true, 120)), true);
  assert.equal(await playing(mkCtx(false, 120)), false);
  // 怎么才会红：把 /now 里的 syncRunning 调用去掉 —— 这条会立刻红，
  // 因为那时 running 还是构造时的初值 false。
});
