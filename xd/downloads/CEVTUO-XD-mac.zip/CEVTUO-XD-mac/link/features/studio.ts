/**
 * Studio —— 哼唱 → 编曲 → MIDI 的「作曲」功能。
 *
 * 和 groove 的区别（这一条要写死在代码里，不然两个功能迟早长成一样）：
 *   · groove = **演奏层**：鼓垫、16 步、CC，一条一条发出去的实时动作。
 *   · studio = **作品层**：把一条哼唱变成一个有几轨、有调性、有结构的编排，
 *     再整段播出去 / 导出。
 *
 * ⚠️ 这里没有"AI 作曲"的魔法。编曲是**确定的乐理**（调性检测 + 三和弦 +
 *    每种风格的鼓型），每一步都能复算；LLM 只负责把一句人话翻译成
 *    `{style,bpm,bars,density}` 这几个参数。把两者混成一句"AI 帮你编曲"，
 *    下次出问题就没人能说清是乐理错了还是模型抽风。
 *
 * ⚠️ 服务端是 `--allow-read --allow-net --allow-env`，**没有写权限** ——
 *    所以历史记录存在手机端 localStorage，不在这里假装持久化。
 */
import { chatOnce } from "../ai.ts";
import { keyStatus, loadKey, setUserKey } from "../key.ts";
import type { Feature } from "./types.ts";

export type Style = "lofi" | "boombap" | "house" | "trap" | "break";
const STYLES: Style[] = ["lofi", "boombap", "house", "trap", "break"];

export interface InNote {
  midi: number;
  /** 相对于哼唱开始的毫秒 */
  start: number;
  dur: number;
  vel?: number;
}

export interface OutNote {
  step: number;
  midi: number;
  dur: number;
  vel: number;
}

export interface Arrangement {
  id: string;
  at: number;
  title: string;
  style: Style;
  bpm: number;
  bars: number;
  density: number;
  swing?: number;
  humanize?: number;
  bassFromHum?: boolean;
  chaos?: number;
  energy?: number;
  transpose?: number;
  scale?: ScaleMode;
  instruments?: Record<Role, Instrument>;
  keyName: string;
  chords: string[];
  mode: ScaleMode;
  stepsPerBar: number;
  tracks: { id: string; name: string; program: number; instrument: Instrument; notes: OutNote[] }[];
  hum: InNote[];
  log: string[];
}

const MAJOR = [0, 2, 4, 5, 7, 9, 11];
const MINOR = [0, 2, 3, 5, 7, 8, 10];
const NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

export type ScaleMode = "major" | "minor" | "dorian" | "phrygian" | "lydian" | "mixolydian";
export const SCALES: Record<ScaleMode, number[]> = {
  major: MAJOR,
  minor: MINOR,
  dorian: [0, 2, 3, 5, 7, 9, 10],
  phrygian: [0, 1, 3, 5, 7, 8, 10],
  lydian: [0, 2, 4, 6, 7, 9, 11],
  mixolydian: [0, 2, 4, 5, 7, 9, 10],
};

export type Role = "drums" | "bass" | "chords" | "melody";
export type Instrument =
  | "kit" | "808" | "acoustic"
  | "sub" | "saw" | "square" | "fm" | "pluck" | "reese" | "upright"
  | "pad" | "organ" | "epiano" | "bell" | "strings" | "brass" | "marimba" | "choir"
  | "lead" | "flute" | "acid";

export const INSTRUMENTS: Record<Role, { id: Instrument; name: string }[]> = {
  drums: [
    { id: "kit", name: "Acoustic Kit" },
    { id: "808", name: "808" },
    { id: "acoustic", name: "Break Kit" },
  ],
  bass: [
    { id: "808", name: "808 Bass" },
    { id: "sub", name: "Sub" },
    { id: "saw", name: "Saw" },
    { id: "square", name: "Square" },
    { id: "fm", name: "FM" },
    { id: "pluck", name: "Pluck" },
    { id: "reese", name: "Reese" },
    { id: "upright", name: "Upright" },
  ],
  chords: [
    { id: "pad", name: "Pad" },
    { id: "organ", name: "Organ" },
    { id: "epiano", name: "E-Piano" },
    { id: "pluck", name: "Pluck" },
    { id: "bell", name: "Bell" },
    { id: "strings", name: "Strings" },
    { id: "brass", name: "Brass" },
    { id: "marimba", name: "Marimba" },
    { id: "choir", name: "Choir" },
  ],
  melody: [
    { id: "lead", name: "Lead" },
    { id: "pluck", name: "Pluck" },
    { id: "bell", name: "Bell" },
    { id: "flute", name: "Flute" },
    { id: "square", name: "Square" },
    { id: "strings", name: "Strings" },
    { id: "brass", name: "Brass" },
    { id: "marimba", name: "Marimba" },
    { id: "acid", name: "Acid" },
  ],
};

function pickInstrument(role: Role, want: unknown): Instrument {
  const list = INSTRUMENTS[role];
  if (typeof want === "string" && list.some((x) => x.id === want)) return want as Instrument;
  return list[0].id;
}

const PROGRESSION: Record<Style, number[]> = {
  lofi: [0, 5, 3, 4],
  boombap: [0, 3, 4, 4],
  house: [0, 5, 3, 4],
  trap: [0, 0, 5, 4],
  break: [0, 3, 0, 4],
};

const DRUMS: Record<Style, { kick: number[]; snare: number[]; hat: number[]; clap?: number[]; open?: number[] }> = {
  lofi: { kick: [0, 3, 10], snare: [4, 12], hat: [2, 6, 10, 14] },
  boombap: { kick: [0, 3, 10], snare: [4, 12], hat: [0, 2, 4, 6, 8, 10, 12, 14] },
  house: { kick: [0, 4, 8, 12], snare: [], clap: [4, 12], hat: [2, 6, 10, 14], open: [2, 6, 10, 14] },
  trap: { kick: [0, 6, 10], snare: [8], hat: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15] },
  break: { kick: [0, 10], snare: [4, 12], hat: [2, 6, 10, 14] },
};

const BASS_RHYTHM: Record<Style, number[]> = {
  lofi: [0, 9],
  boombap: [0, 6, 10],
  house: [0, 4, 8, 12],
  trap: [0, 6, 10],
  break: [0, 8, 10],
};

/* 小 LCG：同一份输入永远给同一份编曲。没有它，'再生成一次' 就变成了抽卡。 */
function rng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** 用音高直方图在 24 个调里打分。权重是 Krumhansl 那套经验的简化版。 */
function detectKey(notes: InNote[]): { tonic: number; mode: "major" | "minor"; keyName: string } {
  const majorW = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
  const minorW = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];
  const hist = new Array(12).fill(0);
  for (const n of notes) {
    const pc = ((Math.round(n.midi) % 12) + 12) % 12;
    hist[pc] += 1 + Math.min(1, (n.dur || 100) / 500);
  }
  let best = { score: -1, tonic: 0, mode: "major" as "major" | "minor" };
  for (let t = 0; t < 12; t++) {
    for (const mode of ["major", "minor"] as const) {
      const w = mode === "major" ? majorW : minorW;
      let score = 0;
      for (let pc = 0; pc < 12; pc++) score += hist[(t + pc) % 12] * w[pc];
      if (score > best.score) best = { score, tonic: t, mode };
    }
  }
  return { tonic: best.tonic, mode: best.mode, keyName: `${NAMES[best.tonic]} ${best.mode}` };
}

function snapToScale(midi: number, tonic: number, scale: number[]): number {
  let best = midi, bestD = 99;
  for (let d = -3; d <= 3; d++) {
    const m = Math.round(midi) + d;
    const pc = ((m - tonic) % 12 + 12) % 12;
    if (scale.includes(pc) && Math.abs(d) < bestD) { best = m; bestD = Math.abs(d); }
  }
  return best;
}

function triad(degree: number, tonic: number, scale: number[]): number[] {
  const pick = (d: number) => tonic + scale[d % 7] + 12 * Math.floor(d / 7);
  return [pick(degree), pick(degree + 2), pick(degree + 4)];
}

function noteToStep(ms: number, bpm: number): number {
  // 16 分音符 = 60000 / bpm / 4
  return Math.round(ms / (60000 / bpm / 4));
}

export function arrange(input: {
  notes: InNote[];
  style: Style;
  bpm: number;
  bars: number;
  density: number;
  title?: string;
  /** 变体种子：同一个种子永远给同一份编排 */
  seed?: number;
  /** 0..0.6：奇数 16 分格往后推 swing/2 格 */
  swing?: number;
  /** 0..1：音高/音量的小抖动，让它不像网格 */
  humanize?: number;
  /** 用哼唱本身做贝斯（下移八度），而不是和弦根音 */
  bassFromHum?: boolean;
  /** 0..1：额外帽子/装饰音/力度抖动，越大越"野" */
  chaos?: number;
  /** 0..1：整体力度与鼓的厚度 */
  energy?: number;
  /** -24..24 半音，整体移调（鼓不动） */
  transpose?: number;
  /** 覆盖调式（默认由哼唱判 major/minor） */
  scale?: ScaleMode;
  instruments?: Partial<Record<Role, string>>;
}): Arrangement {
  const style = STYLES.includes(input.style) ? input.style : "lofi";
  const bpm = Math.max(50, Math.min(180, Math.round(input.bpm || 92)));
  const bars = [2, 4, 8].includes(input.bars) ? input.bars : 4;
  const density = Math.max(0, Math.min(1, input.density ?? 0.6));
  const swing = Math.max(0, Math.min(0.8, input.swing ?? 0));
  const humanize = Math.max(0, Math.min(1, input.humanize ?? 0.12));
  const chaos = Math.max(0, Math.min(1, input.chaos ?? 0.2));
  const energy = Math.max(0, Math.min(1, input.energy ?? 0.6));
  const transpose = Math.max(-24, Math.min(24, Math.round(input.transpose ?? 0)));
  const hum = (input.notes || [])
    .filter((n) => Number.isFinite(n.midi) && Number.isFinite(n.start))
    .slice(0, 256);

  const key = detectKey(hum.length ? hum : [{ midi: 60, start: 0, dur: 400 }]);
  const scaleMode: ScaleMode = input.scale && input.scale in SCALES ? input.scale : key.mode;
  const scale = SCALES[scaleMode];
  const keyName = `${NAMES[key.tonic]} ${scaleMode}`;
  const steps = bars * 16;
  const log: string[] = [];
  log.push(`调性：${keyName}（${input.scale ? "指定" : `从 ${hum.length} 个哼唱音判出来`}）`);
  const instruments: Record<Role, Instrument> = {
    drums: pickInstrument("drums", input.instruments?.drums),
    bass: pickInstrument("bass", input.instruments?.bass),
    chords: pickInstrument("chords", input.instruments?.chords),
    melody: pickInstrument("melody", input.instruments?.melody),
  };

  const rand = rng(hashStr(`${style}:${bpm}:${bars}:${keyName}:${hum.length}:${input.seed ?? 0}:${chaos}`));
  const tracks: Arrangement["tracks"] = [];

  /* ── 鼓 ── */
  const d = DRUMS[style];
  const drums: OutNote[] = [];
  for (let bar = 0; bar < bars; bar++) {
    const off = bar * 16;
    for (const s of d.kick) drums.push({ step: off + s, midi: 36, dur: 1, vel: 112 });
    for (const s of d.snare) drums.push({ step: off + s, midi: 38, dur: 1, vel: 104 });
    for (const s of d.clap || []) drums.push({ step: off + s, midi: 39, dur: 1, vel: 96 });
    for (const s of d.hat) drums.push({ step: off + s, midi: 42, dur: 1, vel: 70 });
    for (const s of d.open || []) if (density > 0.4) drums.push({ step: off + s, midi: 46, dur: 2, vel: 82 });
    // 最后一小节加花：密度越高，加得越满
    if (bar === bars - 1 && density > 0.55) {
      for (let i = 13; i < 16; i++) if (rand() < density) drums.push({ step: off + i, midi: 38, dur: 1, vel: 90 });
    }
  }
  tracks.push({ id: "drums", name: "DRUMS", program: 0, instrument: instruments.drums, notes: drums });

  /* ── 和弦（每小节一个三和弦，按 style 的进行） ── */
  const prog = PROGRESSION[style];
  const chords: OutNote[] = [];
  const chordNames: string[] = [];
  const bass: OutNote[] = [];
  for (let bar = 0; bar < bars; bar++) {
    const degree = prog[bar % prog.length];
    const t = triad(degree, key.tonic, scale);
    // 和弦名：用音阶级数算三音/五音，再按实际移调落到音名上
    const rootDeg = scale[degree % 7] + 12 * Math.floor(degree / 7);
    const thirdDeg = scale[(degree + 2) % 7] + 12 * Math.floor((degree + 2) / 7);
    const fifthDeg = scale[(degree + 4) % 7] + 12 * Math.floor((degree + 4) / 7);
    const i3 = ((thirdDeg - rootDeg) % 12 + 12) % 12;
    const i5 = ((fifthDeg - rootDeg) % 12 + 12) % 12;
    let quality = i3 === 4 ? "" : "m";
    if (i5 === 6) quality = "dim";
    else if (i5 === 8) quality = "aug";
    const pc = ((key.tonic + rootDeg + transpose) % 12 + 12) % 12;
    chordNames.push(NAMES[pc] + quality);
    const root = t[0] + 36; // 贝斯落在 C2–B3，别掉到 C0
    // 和弦铺底：整小节，但密度低时改成两下 stab
    const chordHits = density > 0.65 ? [0, 6, 10] : [0, 8];
    for (const h of chordHits) {
      for (const m of t) chords.push({ step: bar * 16 + h, midi: m + 48, dur: 4, vel: 62 });
    }
    for (const s of BASS_RHYTHM[style]) {
      bass.push({ step: bar * 16 + s, midi: root, dur: 2, vel: 100 });
    }
  }
  if (input.bassFromHum && hum.length) {
    const fromHum: OutNote[] = [];
    for (const n of hum) {
      const step = noteToStep(n.start, bpm);
      if (step < 0 || step >= steps) continue;
      let m = snapToScale(n.midi, key.tonic, scale);
      while (m > 52) m -= 12;
      while (m < 36) m += 12;
      fromHum.push({
        step,
        midi: m,
        dur: Math.max(1, noteToStep(n.dur || 200, bpm)),
        vel: 100,
      });
    }
    bass.length = 0;
    bass.push(...fromHum);
    log.push(`贝斯：用哼唱本身（下移到 36–52），${fromHum.length} 个音`);
  }
  tracks.push({ id: "chords", name: "CHORDS", program: 0, instrument: instruments.chords, notes: chords });
  tracks.push({ id: "bass", name: "BASS", program: 33, instrument: instruments.bass, notes: bass });

  /* ── 旋律：哼唱量化 + 吸附到调内；没有哼唱就用同一套音阶生成 ── */
  const melody: OutNote[] = [];
  if (hum.length) {
    for (const n of hum) {
      const step = noteToStep(n.start, bpm);
      if (step < 0 || step >= steps) continue;
      const dur = Math.max(1, noteToStep(n.dur || 200, bpm));
      melody.push({
        step,
        midi: snapToScale(n.midi, key.tonic, scale),
        dur: Math.min(steps - step, dur),
        vel: Math.max(40, Math.min(120, n.vel || 96)),
      });
    }
    log.push(`哼唱：${hum.length} 个音，量化到 ${melody.length} 个 16 分格`);
  } else {
    const motif = [0, 2, 1, 4, 3, 2, 4, 1];
    for (let bar = 0; bar < bars; bar++) {
      for (let i = 0; i < 8; i++) {
        if (rand() > 0.45 + density * 0.4) continue;
        const deg = motif[(i + bar) % motif.length];
        melody.push({
          step: bar * 16 + i * 2,
          midi: key.tonic + scale[deg % 7] + 48 + (i > 4 ? 12 : 0),
          dur: 2,
          vel: 80 + Math.round(rand() * 20),
        });
      }
    }
    log.push("没有哼唱输入 ⇒ 按调性生成了 8 分音符动机");
  }
  tracks.push({ id: "melody", name: "MELODY", program: 0, instrument: instruments.melody, notes: melody });

  // ── 移调：鼓不动，其余整体上下移 ──
  if (transpose !== 0) {
    for (const tr of tracks) {
      if (tr.id === "drums") continue;
      for (const n of tr.notes) n.midi = Math.max(24, Math.min(96, n.midi + transpose));
    }
  }

  // ── chaos：额外帽子与装饰音；energy：整体力度 ──
  if (chaos > 0) {
    for (let bar = 0; bar < bars; bar++) {
      for (let s = 0; s < 16; s++) {
        if (chaos > rand() * 1.7 && !drums.some((n) => Math.floor(n.step) === bar * 16 + s && n.midi === 42)) {
          drums.push({ step: bar * 16 + s, midi: 42, dur: 1, vel: 46 + Math.round(rand() * 28) });
        }
        if (chaos > rand() * 2.6) {
          const deg = Math.floor(rand() * 7);
          melody.push({
            step: bar * 16 + s,
            midi: key.tonic + scale[deg] + 48 + 12 * Math.floor(rand() * 3),
            dur: 1,
            vel: 58 + Math.round(rand() * 30),
          });
        }
      }
    }
    log.push(`chaos ${Math.round(chaos * 100)}%`);
  }
  const energyGain = 0.65 + energy * 0.7;
  for (const tr of tracks) {
    for (const n of tr.notes) n.vel = Math.max(20, Math.min(127, Math.round(n.vel * energyGain)));
  }
  if (Math.abs(transpose) > 0) log.push(`移调 ${transpose > 0 ? "+" : ""}${transpose}`);

  // ── 律动感：swing 把奇数 16 分格往后推，humanize 加一点点抖动 ──
  for (const tr of tracks) {
    for (const n of tr.notes) {
      const odd = Math.floor(n.step) % 2 === 1;
      n.step = n.step + (odd ? swing * 0.5 : 0) + (rand() * 2 - 1) * humanize * 0.02;
      const dv = Math.round((rand() * 2 - 1) * humanize * 10);
      n.vel = Math.max(30, Math.min(127, n.vel + dv));
    }
    tr.notes.sort((a, b) => a.step - b.step);
  }
  if (swing > 0) log.push(`swing ${Math.round(swing * 100)}%`);
  log.push(`鼓 ${drums.length} / 和弦 ${chords.length} / 贝斯 ${bass.length} / 旋律 ${melody.length}`);
  return {
    id: `a${Date.now().toString(36)}`,
    at: Date.now(),
    title: input.title || `${style.toUpperCase()} · ${key.keyName}`,
    style, bpm, bars, density,
    swing, humanize, bassFromHum: !!input.bassFromHum,
    chaos, energy, transpose, scale: scaleMode, instruments,
    keyName,
    chords: chordNames,
    mode: scaleMode,
    stepsPerBar: 16,
    tracks,
    hum,
    log,
  };
}

/* ────────────────────────── 对话修改 ────────────────────────── */

const ASK_SYSTEM = `你是 GrooveD 的编曲助手。用户会用一句中文提出修改，也可能让你直接做事。
只输出一个 JSON 对象，不要 markdown，不要解释：
{"say":"一句中文回答","action":"play|stop|keep|drop|dice|variations|null",
 "style":"lofi|boombap|house|trap|break","bpm":50-180,"bars":2|4|8,"density":0-1,
 "swing":0-0.8,"chaos":0-1,"energy":0-1,"transpose":-24..24,
 "scale":"major|minor|dorian|phrygian|lydian|mixolydian",
 "instruments":{"drums":"kit|808|acoustic","bass":"808|sub|saw|square|fm|pluck","chords":"pad|organ|epiano|pluck|bell","melody":"lead|pluck|bell|flute|square"}}
没提到的字段输出 null。instruments 里只填要换的角色。`;

interface Patch {
  style?: Style | null;
  bpm?: number | null;
  bars?: number | null;
  density?: number | null;
  swing?: number | null;
  chaos?: number | null;
  energy?: number | null;
  transpose?: number | null;
  scale?: ScaleMode | null;
  instruments?: Partial<Record<Role, string>> | null;
}
type Action = "play" | "stop" | "keep" | "drop" | "dice" | "variations";
function keywordAction(prompt: string): Action | null {
  const p = prompt.toLowerCase();
  if (/播放|放起来|放一遍|试听/.test(p)) return "play";
  if (/停|别放|暂停/.test(p)) return "stop";
  if (/保留|就要这个|留下|存下/.test(p)) return "keep";
  if (/丢弃|丢掉|不要了|删掉/.test(p)) return "drop";
  if (/随机|骰子|随便|来点意外/.test(p)) return "dice";
  if (/变体|再来几|几个版本|换一个版本/.test(p)) return "variations";
  return null;
}

function keywordPatch(prompt: string): Patch {
  const p = prompt.toLowerCase();
  const patch: Patch = {};
  const styleMap: [RegExp, Style][] = [
    [/lofi|lo-fi|低保真|慵懒|复古|爵士/, "lofi"],
    [/boom|bap|嘻哈|说唱|old ?school|boom-bap/, "boombap"],
    [/house|house|浩室|舞曲|四拍/, "house"],
    [/trap|trap|陷阱|808|808/, "trap"],
    [/break|碎拍|dnb|drum ?and ?bass|jungle/, "break"],
  ];
  for (const [re, s] of styleMap) if (re.test(p)) { patch.style = s; break; }
  const bpm = p.match(/(\d{2,3})\s*(?:bpm|拍)?/);
  if (bpm) patch.bpm = Number(bpm[1]);
  if (/慢|舒缓|放松|慢一点/.test(p)) patch.bpm = 78;
  if (/快|急|加速|快一点/.test(p)) patch.bpm = 128;
  if (/简单|简一点|少一点|干净/.test(p)) patch.density = 0.35;
  if (/复杂|复杂一点|花|多打|密/.test(p)) patch.density = 0.85;
  if (/两小节|2 ?小节/.test(p)) patch.bars = 2;
  if (/八小节|8 ?小节/.test(p)) patch.bars = 8;
  if (/四小节|4 ?小节/.test(p)) patch.bars = 4;
  if (/更野|乱一点|疯狂|随机感|多来点随机/.test(p)) patch.chaos = 0.8;
  if (/稳一点|规律|干净一点|不要乱/.test(p)) patch.chaos = 0.1;
  if (/更猛|硬一点|响一点|有力/.test(p)) patch.energy = 0.9;
  if (/轻一点|柔一点|安静|小一点/.test(p)) patch.energy = 0.3;
  if (/高八度|升八度/.test(p)) patch.transpose = 12;
  if (/低八度|降八度|沉一点/.test(p)) patch.transpose = -12;
  if (/多利亚/.test(p)) patch.scale = "dorian";
  if (/弗里几亚|phrygian/.test(p)) patch.scale = "phrygian";
  if (/利底亚|lydian/.test(p)) patch.scale = "lydian";
  if (/混合利底亚|mixolydian/.test(p)) patch.scale = "mixolydian";
  if (/大调/.test(p)) patch.scale = "major";
  if (/小调/.test(p)) patch.scale = "minor";
  if (/摇摆|swing|三连/.test(p)) patch.swing = 0.45;
  if (/不要摇摆|straight|正拍/.test(p)) patch.swing = 0;
  const ins: Partial<Record<Role, string>> = {};
  if (/808/.test(p)) {
    if (/贝斯|bass/.test(p)) ins.bass = "808";
    else ins.drums = "808";
  }
  if (/原声鼓|真鼓|acoustic/.test(p)) ins.drums = "kit";
  if (/锯齿|saw/.test(p)) ins.bass = "saw";
  if (/方波|square/.test(p)) ins.bass = "square";
  if (/fm|调频/.test(p) && /贝斯|bass/.test(p)) ins.bass = "fm";
  if (/次低音|sub/.test(p)) ins.bass = "sub";
  if (/电钢|钢琴|epiano|piano/.test(p)) ins.chords = "epiano";
  if (/风琴|organ/.test(p)) ins.chords = "organ";
  if (/铺底|pad/.test(p)) ins.chords = "pad";
  if (/铃|bell/.test(p)) { ins.chords = "bell"; ins.melody = "bell"; }
  if (/长笛|flute/.test(p)) ins.melody = "flute";
  if (/拨弦|pluck/.test(p)) { ins.chords = "pluck"; ins.melody = "pluck"; }
  if (/主音|lead/.test(p)) ins.melody = "lead";
  if (Object.keys(ins).length) patch.instruments = ins;
  return patch;
}

async function askLLM(prompt: string, current: Record<string, unknown>): Promise<{ say: string; patch: Patch; action: Action | null } | null> {
  const key = await loadKey();
  if (!key) return null;
  try {
    const raw = await chatOnce([
      { role: "system", content: ASK_SYSTEM },
      { role: "user", content: `当前：${JSON.stringify(current)}。用户说：${prompt}` },
    ], { apiKey: key, temperature: 0.3, maxTokens: 220, signal: AbortSignal.timeout(12000) });
    const m = raw.match(/\{[\s\S]*\}/);
    if (!m) return null;
    const j = JSON.parse(m[0]);
    const patch: Patch = {};
    if (typeof j.style === "string" && STYLES.includes(j.style)) patch.style = j.style;
    if (Number.isFinite(j.bpm)) patch.bpm = Math.max(50, Math.min(180, Math.round(j.bpm)));
    if ([2, 4, 8].includes(j.bars)) patch.bars = j.bars;
    if (Number.isFinite(j.density)) patch.density = Math.max(0, Math.min(1, j.density));
    if (Number.isFinite(j.swing)) patch.swing = Math.max(0, Math.min(0.8, j.swing));
    if (Number.isFinite(j.chaos)) patch.chaos = Math.max(0, Math.min(1, j.chaos));
    if (Number.isFinite(j.energy)) patch.energy = Math.max(0, Math.min(1, j.energy));
    if (Number.isFinite(j.transpose)) patch.transpose = Math.max(-24, Math.min(24, Math.round(j.transpose)));
    if (typeof j.scale === "string" && j.scale in SCALES) patch.scale = j.scale as ScaleMode;
    if (j.instruments && typeof j.instruments === "object") {
      const ins: Partial<Record<Role, string>> = {};
      for (const role of ["drums", "bass", "chords", "melody"] as Role[]) {
        const want = j.instruments[role];
        if (typeof want === "string" && INSTRUMENTS[role].some((x) => x.id === want)) ins[role] = want;
      }
      if (Object.keys(ins).length) patch.instruments = ins;
    }
    let action = typeof j.action === "string" &&
      ["play", "stop", "keep", "drop", "dice", "variations"].includes(j.action)
      ? j.action as Action : null;
    // 模型经常漏掉"808 当贝斯"这类明确指名 ⇒ 用关键词规则补上，别让一句人话白说。
    const kw = keywordPatch(prompt);
    if (kw.instruments) patch.instruments = { ...(patch.instruments || {}), ...kw.instruments };
    if (!action) action = keywordAction(prompt);
    return { say: typeof j.say === "string" ? j.say.slice(0, 120) : "改好了", patch, action };
  } catch {
    return null;
  }
}

const INSPIRATION_CARDS = [
  { title: "午夜地铁", concept: "末班车的轮轨声，冷色霓虹，低音在窗上震。", style: "lofi", bpm: 78, bars: 4, scale: "dorian", chaos: 0.35, energy: 0.45, swing: 0.28, instruments: { drums: "kit", bass: "sub", chords: "epiano", melody: "pluck" } },
  { title: "雨后霓虹", concept: "水洼里的招牌倒影，鼓点像雨滴落在铁皮上。", style: "house", bpm: 124, bars: 4, scale: "minor", chaos: 0.25, energy: 0.75, swing: 0.05, instruments: { drums: "kit", bass: "saw", chords: "pad", melody: "bell" } },
  { title: "地下室", concept: "水泥墙、单只灯泡、808 在角落里嗡嗡响。", style: "trap", bpm: 140, bars: 2, scale: "phrygian", chaos: 0.6, energy: 0.85, swing: 0.0, instruments: { drums: "808", bass: "808", chords: "bell", melody: "square" } },
  { title: "旧磁带", concept: "磁带机卡了一秒，鼓组像从旧收音机里出来。", style: "boombap", bpm: 88, bars: 4, scale: "mixolydian", chaos: 0.4, energy: 0.55, swing: 0.35, instruments: { drums: "acoustic", bass: "upright", chords: "organ", melody: "flute" } },
  { title: "玻璃温室", concept: "很轻的弦乐、水滴一样的马林巴，光从顶上漏下来。", style: "break", bpm: 96, bars: 4, scale: "lydian", chaos: 0.45, energy: 0.4, swing: 0.2, instruments: { drums: "kit", bass: "pluck", chords: "strings", melody: "marimba" } },
  { title: "霓虹车库", concept: "四个人在车库里，鼓机比人还响。", style: "break", bpm: 132, bars: 4, scale: "minor", chaos: 0.7, energy: 0.95, swing: 0.0, instruments: { drums: "808", bass: "reese", chords: "brass", melody: "acid" } },
];

let asks = 0;
let lastAsk = "";

export function createStudioFeature(): Feature {
  return {
    id: "studio",
    title: "Studio",
    routes: {
      "/arrange": async (req, ctx) => {
        if (req.method !== "POST") return ctx.json({ error: "POST only" }, 405);
        let body: any;
        try { body = await req.json(); } catch { return ctx.json({ error: "bad json" }, 400); }
        const notes: InNote[] = Array.isArray(body?.notes) ? body.notes : [];
        if (notes.length > 256) return ctx.json({ error: "too many notes" }, 400);
        const a = arrange({
          notes,
          style: body?.style,
          bpm: body?.bpm,
          bars: body?.bars,
          density: body?.density,
          title: body?.title,
          seed: Number(body?.seed) || 0,
          swing: Number(body?.swing) || 0,
          humanize: body?.humanize,
          bassFromHum: !!body?.bassFromHum,
          chaos: body?.chaos,
          energy: body?.energy,
          transpose: body?.transpose,
          scale: body?.scale,
          instruments: body?.instruments,
        });
        return ctx.json(a);
      },

      /** 一次给 4 个变体 —— 每个变体是一个新片段，前端用 A/B/C/D 试听。 */
      "/variations": async (req, ctx) => {
        if (req.method !== "POST") return ctx.json({ error: "POST only" }, 405);
        let body: any;
        try { body = await req.json(); } catch { return ctx.json({ error: "bad json" }, 400); }
        const n = Math.max(2, Math.min(6, Number(body?.n) || 4));
        const items = [];
        for (let i = 1; i <= n; i++) {
          items.push(arrange({
            notes: Array.isArray(body?.notes) ? body.notes : [],
            style: body?.style,
            bpm: body?.bpm,
            bars: body?.bars,
            density: body?.density,
            seed: i,
            swing: Number(body?.swing) || 0,
            humanize: body?.humanize,
            bassFromHum: !!body?.bassFromHum,
            chaos: body?.chaos,
            energy: body?.energy,
            transpose: body?.transpose,
            scale: body?.scale,
            instruments: body?.instruments,
            title: body?.title ? `${body.title} #${i}` : undefined,
          }));
        }
        return ctx.json({ ok: true, items });
      },

      /** 在当前片段上做一次变异（更密/更疏/更 swing），返回一个新片段。 */
      "/mutate": async (req, ctx) => {
        if (req.method !== "POST") return ctx.json({ error: "POST only" }, 405);
        let body: any;
        try { body = await req.json(); } catch { return ctx.json({ error: "bad json" }, 400); }
        const op = String(body?.op || "busy");
        let density = Number(body?.density ?? 0.6);
        let swing = Number(body?.swing ?? 0);
        let chaos = Number(body?.chaos ?? 0.2);
        let energy = Number(body?.energy ?? 0.6);
        let transpose = Number(body?.transpose ?? 0);
        let humanize = Number(body?.humanize ?? 0.12);
        if (op === "busy") { density = Math.min(1, density + 0.25); chaos = Math.min(1, chaos + 0.15); }
        else if (op === "sparse") { density = Math.max(0.1, density - 0.25); chaos = Math.max(0, chaos - 0.15); }
        else if (op === "swing") swing = Math.min(0.8, swing + 0.25);
        else if (op === "straight") swing = 0;
        else if (op === "up") transpose = Math.min(24, transpose + 12);
        else if (op === "down") transpose = Math.max(-24, transpose - 12);
        else if (op === "wild") { chaos = Math.min(1, chaos + 0.35); humanize = Math.min(1, humanize + 0.25); }
        else if (op === "hard") energy = Math.min(1, energy + 0.3);
        else if (op === "soft") energy = Math.max(0, energy - 0.3);
        const a = arrange({
          notes: Array.isArray(body?.notes) ? body.notes : [],
          style: body?.style,
          bpm: body?.bpm,
          bars: body?.bars,
          density,
          swing, chaos, energy, transpose, humanize,
          bassFromHum: !!body?.bassFromHum,
          scale: body?.scale,
          instruments: body?.instruments,
          seed: Math.floor(Math.random() * 100000),
          title: body?.title ? `${body.title} · ${op}` : undefined,
        });
        return ctx.json(a);
      },

      /** 可选音色清单 —— 手机从这一份建选择器，别在前端再抄一张表。 */
      "/instruments": (_req, ctx) => ctx.json({ roles: INSTRUMENTS }),

      /** 灵感 AI：给一个概念（LLM 或本地卡片），直接返回一套可播放的参数。 */
      "/inspire": async (req, ctx) => {
        if (req.method !== "POST") return ctx.json({ error: "POST only" }, 405);
        const key = await loadKey();
        if (key) {
          try {
            const raw = await chatOnce([
              { role: "system", content: `你是音乐制作人的灵感搭子。只输出 JSON：
{"title":"2-5 字中文曲名","concept":"一句中文画面感描述",
 "style":"lofi|boombap|house|trap|break","bpm":50-180,"bars":2|4|8,
 "scale":"major|minor|dorian|phrygian|lydian|mixolydian",
 "chaos":0-1,"energy":0-1,"swing":0-0.8,
 "instruments":{"drums":"kit|808|acoustic","bass":"808|sub|saw|square|fm|pluck|reese|upright","chords":"pad|organ|epiano|pluck|bell|strings|brass|marimba|choir","melody":"lead|pluck|bell|flute|square|strings|brass|marimba|acid"}}
不要 markdown。` },
              { role: "user", content: `给我一个可以马上做出来的电子乐灵感。${Math.random().toString(36).slice(2, 7)}` },
            ], { apiKey: key, temperature: 0.95, maxTokens: 320, signal: AbortSignal.timeout(15000) });
            const m = raw.match(/\{[\s\S]*\}/);
            if (m) {
              const j = JSON.parse(m[0]);
              const cfg = {
                title: String(j.title || "无题").slice(0, 12),
                concept: String(j.concept || "").slice(0, 80),
                style: STYLES.includes(j.style) ? j.style : "lofi",
                bpm: Math.max(50, Math.min(180, Math.round(j.bpm || 92))),
                bars: [2, 4, 8].includes(j.bars) ? j.bars : 4,
                scale: (j.scale in SCALES) ? j.scale : "minor",
                chaos: Math.max(0, Math.min(1, Number(j.chaos ?? 0.3))),
                energy: Math.max(0, Math.min(1, Number(j.energy ?? 0.6))),
                swing: Math.max(0, Math.min(0.8, Number(j.swing ?? 0.1))),
                instruments: {
                  drums: pickInstrument("drums", j.instruments?.drums),
                  bass: pickInstrument("bass", j.instruments?.bass),
                  chords: pickInstrument("chords", j.instruments?.chords),
                  melody: pickInstrument("melody", j.instruments?.melody),
                },
                by: "llm",
              };
              return ctx.json({ ok: true, ...cfg });
            }
          } catch {
            // 模型挂了就走本地卡片，不让"灵感"变成错误框。
          }
        }
        const card = INSPIRATION_CARDS[Math.floor(Math.random() * INSPIRATION_CARDS.length)];
        return ctx.json({ ok: true, ...card, by: "cards" });
      },

      /** 骰子：随机风格/BPM/小节/密度/chaos/energy/音色/调式，返回一份参数。 */
      "/dice": (_req, ctx) => {
        const r = (a: number, b: number) => a + Math.floor(Math.random() * (b - a + 1));
        const pick = <T>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
        const scale = pick(Object.keys(SCALES) as ScaleMode[]);
        const instruments = {
          drums: pick(INSTRUMENTS.drums).id,
          bass: pick(INSTRUMENTS.bass).id,
          chords: pick(INSTRUMENTS.chords).id,
          melody: pick(INSTRUMENTS.melody).id,
        };
        return ctx.json({
          ok: true,
          style: pick(STYLES),
          bpm: r(62, 150),
          bars: pick([2, 4, 8]),
          density: +(0.25 + Math.random() * 0.7).toFixed(2),
          chaos: +(Math.random() * 0.8).toFixed(2),
          energy: +(0.4 + Math.random() * 0.6).toFixed(2),
          swing: +(Math.random() * 0.45).toFixed(2),
          humanize: +(0.05 + Math.random() * 0.3).toFixed(2),
          transpose: pick([-12, -5, 0, 0, 0, 5, 12]),
          scale,
          instruments,
        });
      },

      /** DeepSeek key 的设置页入口。只回 hint，不回完整 key。 */
      "/key": async (req, ctx) => {
        if (req.method === "GET") return ctx.json(await keyStatus());
        if (req.method === "POST") {
          let body: any;
          try { body = await req.json(); } catch { return ctx.json({ error: "bad json" }, 400); }
          const k = String(body?.key ?? "").trim();
          if (k && !k.startsWith("sk-")) return ctx.json({ ok: false, error: "key 应以 sk- 开头" }, 400);
          const r = setUserKey(k || null);
          return ctx.json({ ...r, ...(await keyStatus()) });
        }
        if (req.method === "DELETE") {
          const r = setUserKey(null);
          return ctx.json({ ...r, ...(await keyStatus()) });
        }
        return ctx.json({ error: "GET/POST/DELETE" }, 405);
      },

      "/ask": async (req, ctx) => {
        if (req.method !== "POST") return ctx.json({ error: "POST only" }, 405);
        let body: any;
        try { body = await req.json(); } catch { return ctx.json({ error: "bad json" }, 400); }
        const prompt = String(body?.prompt || "").slice(0, 200);
        if (!prompt.trim()) return ctx.json({ error: "need prompt" }, 400);
        const cur = {
          style: body?.style || "lofi",
          bpm: Number(body?.bpm) || 92,
          bars: Number(body?.bars) || 4,
          density: Number(body?.density) ?? 0.6,
          swing: Number(body?.swing) ?? 0,
          chaos: Number(body?.chaos) ?? 0.2,
          energy: Number(body?.energy) ?? 0.6,
          transpose: Number(body?.transpose) ?? 0,
          scale: body?.scale || "",
          instruments: body?.instruments || {},
        };
        asks++;
        lastAsk = prompt;
        const llm = await askLLM(prompt, cur);
        if (llm) return ctx.json({ ok: true, by: "llm", ...llm });
        const patch = keywordPatch(prompt);
        const action = keywordAction(prompt);
        const changed = Object.keys(patch).length || action;
        const say = changed
          ? "按你说的改了（本地规则，没用到模型）"
          : "这句我没听出要改什么；可以试试「慢一点」「换成 house」「贝斯用 808」「随机一下」";
        return ctx.json({ ok: true, by: "rules", say, patch, action });
      },

      "/styles": (_req, ctx) =>
        ctx.json({
          styles: STYLES.map((s) => ({
            id: s,
            name: { lofi: "Lo-Fi", boombap: "Boom Bap", house: "House", trap: "Trap", break: "Breakbeat" }[s],
          })),
        }),
    },

    snapshot() {
      return { asks, lastAsk };
    },

    rev() {
      return asks;
    },

    status() {
      return asks ? `asks=${asks}` : "idle";
    },
  };
}
