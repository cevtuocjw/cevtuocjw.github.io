/**
 * 功能 · Media —— 手机正在播放什么（给手表 Stem-D 的白色标签用）。
 *
 * 数据来自手机 App 的 MediaSession（每次都带 title/artist/playing）。
 * Mac 自己不猜：没有上报 = 没有音乐，不编造。
 *
 * ⚠️ 手机没装/没授权时这里**永远是空**，而空和"没在放"在界面上必须能分开：
 * snapshot 里带 `stale`，超过 30 秒没上报就是 stale。
 */
import type { Feature } from "./types.ts";

export interface NowPlaying {
  title: string;
  artist: string;
  album: string;
  playing: boolean;
  position: number;
  duration: number;
  pkg: string;
  updatedAt: number;
}

export function createMediaFeature(): Feature {
  let now: NowPlaying = {
    title: "", artist: "", album: "", playing: false,
    position: 0, duration: 0, pkg: "", updatedAt: 0,
  };
  let rev = 0;
  let lastFp = "";

  const fp = (n: NowPlaying) => `${n.title}|${n.artist}|${n.playing}|${n.duration}`;

  return {
    id: "media",
    title: "Now Playing",
    routes: {
      /** GET /api/media */
      "": (_req, ctx) => ctx.json({
        now,
        stale: !now.updatedAt || Date.now() - now.updatedAt > 30000,
      }),

      /** POST /api/media/report —— 手机每次媒体状态变化时上报 */
      "/report": async (req, ctx) => {
        const body = await req.json().catch(() => null) as Record<string, unknown> | null;
        if (!body) return ctx.json({ error: "bad_payload" }, 400);
        const s = (v: unknown) => (typeof v === "string" ? v.slice(0, 160) : "");
        const n = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? Math.max(0, v) : 0);
        now = {
          title: s(body.title),
          artist: s(body.artist),
          album: s(body.album),
          playing: !!body.playing,
          position: n(body.position),
          duration: n(body.duration),
          pkg: s(body.pkg),
          updatedAt: Date.now(),
        };
        const f = fp(now);
        if (f !== lastFp) { lastFp = f; rev++; ctx.broadcast(); }
        return ctx.json({ ok: true });
      },
    },
    snapshot: () => ({
      now,
      stale: !now.updatedAt || Date.now() - now.updatedAt > 30000,
    }),
    rev: () => rev,
  };
}
