/**
 * 功能 · MIDI —— 把设备的状态变成真的 MIDI 消息，推进 Mac 的虚拟端口。
 *
 * ── 一个必须说清的架构决定：**时钟在 Swift 那边，不在这里** ──────────
 *
 * MIDI 的时钟是 **24 PPQN**：120 BPM 下每秒 48 个 tick。
 * 而这个服务端的心跳是 **2 秒一次**（`tick()` 的节奏，跟 agent 的刷新共用）。
 * 拿 2 秒去生成 48Hz 的东西，等于把时钟建立在"顺便"上。
 *
 * ⇒ **deno 这边只提供"该以什么速度走"（BPM/电平/模式），
 *   真正的时钟由 `tools/grooved-midi.swift` 用 CoreMIDI + 本地定时器发。**
 *   这不是妥协：MIDI 时钟本来就是**本地的**东西 —— 让它跨一次网络往返，
 *   抖动会比节拍本身还大。
 *
 * ── 为什么不用 rtpmidid ─────────────────────────────────────────
 * 上一轮方案 §6 说要 Wi-Fi UDP → `rtpmidid` → 虚拟端口。实测**本机没装 rtpmidid**，
 * 也没装 node/npm 去装它。但 **swiftc 在**（Swift 6.4 / CommandLineTools）⇒
 * 四十行 CoreMIDI 就能建一个"GrooveD"虚拟源，零依赖、零安装。
 * （见 `tools/grooved-midi.swift`，`bash tools/build-midi.sh` 编译。）
 */

import type { DeviceState } from "../protocol.ts";
import type { Feature, FeatureCtx } from "./types.ts";

/** MIDI 通道（0 起）。故意用 1 号通道（下标 0）—— GM 里那是钢琴。 */
export const MIDI_CHANNEL = 0;

export interface MidiMessage {
  /** 单调递增序号，客户端用来断点续传。 */
  seq: number;
  /** Unix ms。 */
  at: number;
  /** 原始字节。0x90 = note on，0xB0 = CC，0xF8 = clock。 */
  bytes: number[];
  /** 人看得懂的一句话，手机上的监视器就显示这个。 */
  label: string;
}

export const NOTE_ON = 0x90;
export const NOTE_OFF = 0x80;
export const CC = 0xb0;
export const CLOCK = 0xf8;
export const START = 0xfa;
export const STOP = 0xfc;
export const CONTINUE = 0xfb;

/**
 * 「现在算不算在走」。
 *
 * ⚠️ 这条判据不能只看 BPM > 0。设备可能**刚推完一帧就掉线** ——
 * 那时 BPM 还留着上次的值，而人已经拔了线。
 * 所以：**在线 且 有 BPM** 才算在走。离线一律停表（并且发 STOP）。
 */
export function isRunning(online: boolean, bpm: number): boolean {
  return online && Number.isFinite(bpm) && bpm > 0;
}

/** 电平 → CC1（调制轮）。0..1 → 0..127。 */
export function levelToCC(level: number): number {
  const v = Math.max(0, Math.min(1, Number.isFinite(level) ? level : 0));
  return Math.round(v * 127);
}

/**
 * 六个模式 → 六个音（C 大调五声 + 一个）。
 *
 * 为什么是音而不是别的：用户在设备上切模式时，**Mac 那边应该听得见**。
 * 一个短促的音比任何日志都快地告诉他"收到了"。
 * ⚠️ 用五声音阶（C D E G A）是刻意的：随便两个音叠在一起都不会难听，
 * 因为切模式可能很快。
 */
export const MODE_NOTE: Record<string, number> = {
  NOW: 60,     // C4
  BUILD: 62,   // D4
  READ: 64,    // E4
  MEET: 67,    // G4
  PRESENT: 69, // A4
  REST: 72,    // C5
};

export function modeNote(mode: string): number {
  return MODE_NOTE[mode] ?? 60;
}

/** note on/off 的字节。velocity 0 的 note on 等价于 note off，但显式写 off 更清楚。 */
export function noteBytes(note: number, on: boolean): number[] {
  return [(on ? NOTE_ON : NOTE_OFF) | MIDI_CHANNEL, note & 0x7f, on ? 100 : 0];
}
export function ccBytes(controller: number, value: number): number[] {
  return [CC | MIDI_CHANNEL, controller & 0x7f, Math.max(0, Math.min(127, value | 0)) & 0x7f];
}

export function labelOf(bytes: number[]): string {
  const [s] = bytes;
  if (s === CLOCK) return "clock";
  if (s === START) return "start";
  if (s === STOP) return "stop";
  if (s === CONTINUE) return "continue";
  const kind = s & 0xf0, ch = (s & 0x0f) + 1;
  const d1 = bytes[1] ?? 0, d2 = bytes[2] ?? 0;
  if (kind === NOTE_ON && d2 > 0) return `note on  ch${ch} ${d1} vel${d2}`;
  if (kind === NOTE_OFF || (kind === NOTE_ON && d2 === 0)) return `note off ch${ch} ${d1}`;
  if (kind === CC) return `cc${d1} ch${ch} = ${d2}`;
  return `0x${s.toString(16)}`;
}

export function createMidiFeature(): Feature {
  /** 环形缓冲：手机上只显示最近这些，**不无限增长**。 */
  const LOG_MAX = 200;
  const log: MidiMessage[] = [];
  let seq = 0;
  let rev = 0;
  let lastMode = "";
  let running = false;
  /** 端口名由 Swift 那侧上报（它建了才知道）。 */
  let port = "";
  let helperSeen = 0;
  let sentTotal = 0;
  let sendFailures = 0;

  /**
   * 「在不在走」的**唯一**入口。
   *
   * ⚠️ 第一版这段逻辑只写在 `tick()` 里，而 tick 是 2 秒一次的 ——
   * 于是按下走带之后时钟晚 2 秒起步。**同一个状态有两个写入点就会这样**：
   * 一个写、一个漏。所以只留这一个函数，两边都调它。
   */
  const syncRunning = (online: boolean, bpm: number): void => {
    const next = isRunning(online, bpm);
    if (next === running) return;
    running = next;
    rev++;
    // 走 / 停 的跳变也进日志 —— 手机上的监视器要能看见它，
    // 否则用户分不清"没在走"和"监视器坏了"。
    push(next ? [START] : [STOP]);
  };

  const push = (bytes: number[], at = Date.now()): void => {
    seq++;
    log.push({ seq, at, bytes, label: labelOf(bytes) });
    if (log.length > LOG_MAX) log.splice(0, log.length - LOG_MAX);
    rev++;
  };

  return {
    id: "midi",
    // ⚠️ id 和 title 故意不同名：`id` 是技术键（出现在 `/api/midi/*`、
    // `tools/grooved-midi.swift`、手机页的分页、测试里），改它是纯 churn；
    // `title` 是**产品名**，读者 2026-10-16 定的。
    title: "Groove D",

    routes: {
      /**
       * Swift 那侧轮询这个来决定"以什么速度走"。
       * ⚠️ 它必须**便宜** —— 这是唯一一个被高频调用的接口。
       */
      "/now": (_req: Request, ctx: FeatureCtx) => {
        const { online, state } = ctx.device();
        const s = state as DeviceState;
        helperSeen = Date.now();
        // ⚠️ 在这里**现算** playing，而不是等 tick 那 2 秒一次的心跳。
        // 实测第一版就是等 tick 的 ⇒ 用户按下走带之后，**时钟要晚 2 秒才起步**，
        // 而节拍器晚 2 秒等于没用。helper 每 200ms 问一次这里，所以延迟被压到 200ms。
        syncRunning(online, s.bpm);
        return json({
          bpm: s.bpm,
          level: s.level,
          mode: s.mode,
          playing: running,
          port,
        });
      },

      /** 端口名上报（Swift 侧建完端口才知道）。 */
      "/port": async (req: Request) => {
        const b = await req.json().catch(() => null) as { port?: string } | null;
        if (!b?.port) return json({ error: "no_port" }, 400);
        if (port !== b.port) { port = b.port; rev++; }
        helperSeen = Date.now();
        return json({ ok: true, port });
      },

      /** Swift 侧把**真的发出去的**回报上来 —— 手机上的监视器靠它。 */
      "/sent": async (req: Request) => {
        const b = await req.json().catch(() => null) as { count?: number; port?: string; failures?: number } | null;
        const n = Math.max(0, Math.min(10000, Number(b?.count ?? 0)));
        const f = Math.max(0, Math.min(10000, Number(b?.failures ?? 0)));
        sentTotal += n;
        // ⚠️ 失败数也要收：只报成功、不报失败的话，"发不出去"和"没在发"
        //    在界面上长得一模一样（都是 0）。
        sendFailures = Math.max(sendFailures, f);
        helperSeen = Date.now();
        if (b?.port && b.port !== port) port = b.port;
        return json({ ok: true, total: sentTotal });
      },

      /** 手动的"全停" —— 键盘上按错了、或者声音卡住了的时候用。 */
      "/panic": () => {
        // CC123 = All Notes Off，CC120 = All Sound Off。两个都发，
        // 因为有些音源只认其中一个 —— 而这是"救急"按钮，不能只救一半。
        push(ccBytes(123, 0));
        push(ccBytes(120, 0));
        return json({ ok: true, sent: 2 });
      },

      "/log": (req: Request) => {
        const since = Number(new URL(req.url).searchParams.get("since") ?? 0);
        return json({ seq, messages: log.filter((m) => m.seq > since) });
      },

      "/status": () => json({ port, sentTotal, sendFailures, helperAgeSec: helperSeen ? Math.round((Date.now() - helperSeen) / 1000) : -1, logSeq: seq }),
    },

    snapshot: () => ({
      port,
      playing: running,
      sentTotal,
      /**
       * ⚠️ Swift 那侧的"活着吗"要有上限：超过 10 秒没来问过就当它没在跑。
       * 不这么判的话，用户关掉 helper 之后手机上还是显示"运行中"。
       */
      helperAlive: helperSeen > 0 && Date.now() - helperSeen < 10_000,
      sendFailures,
      recent: log.slice(-24),
    }),

    rev: () => rev,

    tick: (ctx: FeatureCtx) => {
      // ⚠️ tick 里**不生成 clock**（见文件头）。这里只保证"在不在走"是新的 ——
      // 即使没有 helper 在轮询 `/now`，手机那一侧也能看到状态变。
      const { online, state } = ctx.device();
      syncRunning(online, (state as DeviceState).bpm);
    },

    status: () => (port ? `端口 ${port}，已发 ${sentTotal} 条` : "没有 MIDI 端口（helper 没起）"),
  };
}

const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
