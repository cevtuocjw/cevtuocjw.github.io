/**
 * agent 功能的测试。
 *
 * ⚠️ 这个文件里**最重要的不是覆盖率，是那几条"安全"断言**。
 * 批准这件事出错的方式和别的不一样：它出错时**通常什么都不会发生** ——
 * agent 照常干活、日志干净，直到事后才发现它改了一个没人批准的文件。
 * 所以下面每一条都写清了"它怎么才会红"。
 */
import assert from "node:assert/strict";
import {
  agentBrief,
  agentPromptLine,
  cfToUnix,
  CF_EPOCH_OFFSET,
  createAgentsFeature,
  describeRequest,
  parseOne,
  parseSessions,
  rankAgents,
  readStatus,
  SAFE_FALLBACK,
  type AgentSession,
} from "./agents.ts";
import type { FeatureCtx } from "./types.ts";

/** 从真实 sessions.json 抄下来的一条（值都是那天实测的）。 */
const real = {
  id: "claude:5330c1cd-ddd1-4ecc-bee9-5c7ef996d21c",
  terminal: { appName: "Cherry Studio", bundleID: "com.kangfenmao.CherryStudio" },
  context: { limit: 1000000, tokens: 269687, model: "deepseek-flash" },
  status: { working: { activity: "Inventory pet app assets" } },
  updatedAt: 813831748.240696,
  startedAt: 813831721.351976,
  agent: "claudeCode",
};

const ctx = (): FeatureCtx => ({
  device: () => ({ online: false, state: {} }),
  broadcast: () => {},
  // ⚠️ 0 = 没人在看。注册接口会把这个数带回去，hook 靠它决定要不要等。
  watchers: () => 0,
  json: (o, s = 200) =>
    new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json" } }),
});

const post = (body: unknown) =>
  new Request("http://x/", { method: "POST", body: JSON.stringify(body) });

/* ───────────────────────── 安全：这几条是重点 ───────────────────────── */

Deno.test("⚠️ 默认回退必须是 ask，**永远不许是 allow**", () => {
  assert.equal(SAFE_FALLBACK, "ask");
  // 怎么才会红：把 SAFE_FALLBACK 改成 "allow"。
  //
  // ⚠️ 为什么专门钉这一条：**CrewTower 的 notch-hook 实测就是失败的**（见下）。
  // 一个 fail-open 的 hook 出错时**没有任何症状** —— 这正是最不能靠"我记得"
  // 来保证的东西，必须有一条断言挡着。实测证据：
  //   $ echo '{"hook_event_name":"PermissionRequest",...}' |
  //       HOME=/tmp/emptyhome notch-hook --engine claude --decide-on PermissionRequest
  //   {"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"allow"}}}
  // ⇒ socket 连不上时它**自动批准**。我们不抄这个选择。
});

Deno.test("⚠️ /decide 只认三个词，拼错的**不能**变成 allow", async () => {
  const f = createAgentsFeature();
  // ⚠️ 这些都是 **async** 处理器 —— 直接读 `.status` 会得到 `undefined`
  // （Promise 没有 status），而 `undefined !== 400` 会让断言**红得莫名其妙**。
  // 第一版就是这么错的。**处理器的 async 与否是这个接口契约的一部分**。
  const h = f.routes["/decide"] as (r: Request, c: FeatureCtx) => Promise<Response>;
  assert.ok(h);
  const c = ctx();
  // 白名单之外的每一个都必须 400 —— 包括最危险的那几个拼法。
  for (const bad of ["ALLOW", "agree", "yes", "1", "true", "", undefined, "permit", "allow "]) {
    const r = await h(post({ id: "x", behavior: bad }), c);
    assert.equal(r.status, 400, `坏行为被放行了：${JSON.stringify(bad)}`);
  }
  // 怎么才会红：把白名单换成 `if (!behavior) return 400`（黑名单思路）。
  // ⚠️ 黑名单在这里是错的：以后有人说"再加一个 'permit'"，
  //    它就会**绕过**这条检查 —— 而 allow 是那个危险值。
});

Deno.test("⚠️ /wait 超时回 ask，而且**不把决定写死**", async () => {
  const f = createAgentsFeature();
  const c = ctx();
  const created = await (f.routes["/request"] as (r: Request, c: FeatureCtx) => Promise<Response>)(
    post({ hook_event_name: "PermissionRequest", tool_name: "Bash", tool_input: { command: "rm -rf /tmp/x" } }),
    c,
  );
  const { id } = await created.json() as { id: string };
  assert.ok(id);

  const t0 = Date.now();
  const r = await (f.routes["/wait"] as (r: Request, c: FeatureCtx) => Promise<Response>)(
    new Request(`http://x/?id=${id}&timeout=1`),
    c,
  );
  const body = await r.json() as { behavior: string; by: string };
  assert.equal(body.behavior, "ask", "超时没有回 ask");
  assert.equal(body.by, "timeout");
  assert.ok(Date.now() - t0 >= 900, "没等够 1 秒就返回了");
  // 怎么才会红：把超时那一支改成 `res({b:"allow"})`。
  // ⚠️ 为什么"不写死"也要断言：用户可能在 10 秒后才点 ——
  // 超时只是"这次轮询先回去问 Claude Code"，不是"这件事作废了"。
  // UI 上那一条必须**还留着**，否则用户看到一条还没答的请求突然消失。
  const pend = await (f.routes["/pending"] as (r: Request, c: FeatureCtx) => Promise<Response>)(new Request("http://x/"), c);
  const { pending } = await pend.json() as { pending: { id: string }[] };
  assert.ok(pending.some((p) => p.id === id), "超时之后请求被丢掉了 —— 用户再点就没用了");
});

Deno.test("手机上点一下，长轮询立刻被唤醒", async () => {
  const f = createAgentsFeature();
  const c = ctx();
  const created = await (f.routes["/request"] as (r: Request, c: FeatureCtx) => Promise<Response>)(
    post({ tool_name: "Write", tool_input: { file_path: "/tmp/a.txt" } }),
    c,
  );
  const { id } = await created.json() as { id: string };

  const t0 = Date.now();
  const waiting = (f.routes["/wait"] as (r: Request, c: FeatureCtx) => Promise<Response>)(
    new Request(`http://x/?id=${id}&timeout=30`),
    c,
  );
  await new Promise((r) => setTimeout(r, 60));
  const d = await (f.routes["/decide"] as (r: Request, c: FeatureCtx) => Promise<Response>)(
    post({ id, behavior: "deny", by: "phone" }),
    c,
  );
  assert.equal(d.status, 200);

  const body = await (await waiting).json() as { behavior: string; by: string };
  assert.equal(body.behavior, "deny");
  assert.equal(body.by, "phone");
  assert.ok(Date.now() - t0 < 5000, "唤醒太慢 —— 多半在轮询而不是被推");
  // 怎么才会红：把 `resolve` 里的 `for (const w of ws) w(...)` 删掉
  // ⇒ 只能靠超时返回，手机上点完要等满 timeout 才生效（体感是"点了没反应"）。

  // 同一条不能被批两次（第二次 409）—— 否则两个 hook 会拿到两个不同的答案。
  const again = await (f.routes["/decide"] as (r: Request, c: FeatureCtx) => Promise<Response>)(
    post({ id, behavior: "allow" }),
    c,
  );
  assert.equal(again.status, 409, "同一条请求被批了两次");
});

Deno.test("describeRequest：挑错字段 = 用户看不到自己在批什么", () => {
  assert.equal(
    describeRequest({ tool_name: "Bash", tool_input: { command: "rm -rf build" } }).detail,
    "rm -rf build",
  );
  assert.equal(
    describeRequest({ tool_name: "Write", tool_input: { file_path: "/a/b.ts" } }).detail,
    "/a/b.ts",
  );
  assert.equal(
    describeRequest({ tool_name: "WebFetch", tool_input: { url: "https://x.com" } }).detail,
    "https://x.com",
  );
  // 没有已知字段 ⇒ 退回 JSON 摘要，**不许是空字符串**（空格子和"没有参数"看起来一样）。
  // 有参数但不认识 ⇒ 退回 JSON 摘要（总比空着好）
  const odd = describeRequest({ tool_name: "Whatever", tool_input: { a: 1 } });
  assert.equal(odd.detail, '{"a":1}');
  const none = describeRequest({ tool_name: "X" });
  assert.equal(none.detail, "(没有参数)");
  // 长命令要截断（一整段 100KB 的 base64 会把手机页面撑爆）。
  const long = describeRequest({ tool_name: "Bash", tool_input: { command: "x".repeat(5000) } });
  assert.ok(long.detail.length <= 401, `没截断：${long.detail.length}`);
  assert.ok(long.detail.endsWith("…"));
  // 怎么才会红：把 firstOf 的 key 列表里 "command" 删掉。
});

/* ───────────────────────── 解析（从旧文件搬过来） ───────────────────────── */

Deno.test("CoreFoundation 纪元：813831748 是 2026 年，不是 1995 年", () => {
  const iso = new Date(cfToUnix(813831748.240696) * 1000).toISOString();
  assert.ok(iso.startsWith("2026-"), `换算错了：${iso}`);
  assert.equal(iso.slice(0, 16), "2026-10-16T08:22");
  // 怎么才会红：把 CF_EPOCH_OFFSET 改成 0。
  // ⚠️ 错了之后 ageSec 会是 9.7 亿秒，而**它看起来仍然像个时间**。
});

Deno.test("纪元换算在两个方向上都不吞数", () => {
  assert.equal(cfToUnix(0), CF_EPOCH_OFFSET);
  assert.equal(cfToUnix(NaN), 0);
  assert.equal(cfToUnix(undefined as unknown as number), 0);
});

Deno.test("status 的四种形状都被认出来，不认识的不会变成 idle", () => {
  assert.equal(readStatus({ working: { activity: "跑测试" } }).state, "working");
  assert.equal(readStatus({ working: { activity: "跑测试" } }).activity, "跑测试");
  assert.equal(readStatus({ idle: {} }).state, "idle");
  assert.equal(readStatus({ waiting: { message: "等你批准" } }).state, "waiting");
  assert.equal(readStatus({ teleporting: {} }).state, "unknown");
  assert.equal(readStatus(null).state, "unknown");
  assert.equal(readStatus("working").state, "unknown");
  // 怎么才会红：把 `known[key] ?? "unknown"` 写成 `?? "idle"`。
  // idle 会排到最后、变灰 —— 等于把"需要你"的东西藏起来。
});

Deno.test("真实那一条能被完整解析出来", () => {
  const s = parseOne(real);
  assert.ok(s);
  assert.equal(s.app, "Cherry Studio");
  assert.equal(s.state, "working");
  assert.equal(s.activity, "Inventory pet app assets");
  assert.equal(s.tokens, 269687);
  assert.equal(s.limit, 1000000);
});

Deno.test("缺字段不抛，缺 id 就丢掉", () => {
  const bare = parseOne({ id: "codex:abc" });
  assert.ok(bare);
  assert.equal(bare.app, "—");
  assert.equal(bare.state, "unknown");
  assert.equal(parseOne(null), null);
  assert.equal(parseOne({}), null);
});

Deno.test("parseSessions：数组和对象包着的都能读，垃圾一律 []", () => {
  assert.equal(parseSessions(JSON.stringify([real])).length, 1);
  assert.equal(parseSessions(JSON.stringify({ a: real })).length, 1);
  for (const junk of ["", "{", "null", "42", '"x"', "[]"]) {
    assert.deepEqual(parseSessions(junk), [], `${JSON.stringify(junk)} 没被吃掉`);
  }
  // 怎么才会红：把 try/catch 去掉 ⇒ CrewTower 恰好在写文件时读到半截 JSON 就 500。
});

Deno.test("排序：'在等你'必须排第一，哪怕它是最旧的那条", () => {
  const mk = (id: string, state: AgentSession["state"], updatedAt: number): AgentSession => ({
    id, agent: "claudeCode", app: "X", state, activity: "", model: "",
    tokens: 0, limit: 0, cwd: "", startedAt: 0, updatedAt, ageSec: 0,
  });
  const now = 1_000_000_000;
  const ranked = rankAgents([
    mk("a", "idle", now - 1), mk("b", "working", now - 2), mk("c", "waiting", now - 9999), mk("d", "working", now - 3),
  ], now * 1000);
  assert.equal(ranked[0].id, "c");
  assert.deepEqual(ranked.map((x) => x.state), ["waiting", "working", "working", "idle"]);
  assert.deepEqual(ranked.filter((x) => x.state === "working").map((x) => x.id), ["b", "d"]);
  // 怎么才会红：把 `weight` 那项去掉，只按 updatedAt 排。
});

Deno.test("ageSec 由传入的 now 算；没时间戳给 -1 不是 0", () => {
  const s: AgentSession = {
    id: "x", agent: "a", app: "P", state: "working", activity: "", model: "",
    tokens: 0, limit: 0, cwd: "", startedAt: 0, updatedAt: 1000, ageSec: 0,
  };
  assert.equal(rankAgents([s], 1300 * 1000)[0].ageSec, 300);
  // -1（不知道多久）和 0（刚刚）在界面上差很远。
  assert.equal(rankAgents([{ ...s, updatedAt: 0 }], 1300 * 1000)[0].ageSec, -1);
});

Deno.test("agentPromptLine：空列表是**空字符串**，把真实的带进去，waiting 要说出来", () => {
  assert.equal(agentPromptLine([]), "");
  const line = agentPromptLine([{
    id: "claude:x", agent: "claudeCode", app: "Cherry Studio", state: "working",
    activity: "改 app.js", model: "deepseek-flash", tokens: 288000, limit: 1000000,
    cwd: "", startedAt: 0, updatedAt: 0, ageSec: 0,
  }]);
  for (const frag of ["Cherry Studio", "正在做", "改 app.js", "288k", "1000k"]) {
    assert.ok(line.includes(frag), `缺了 ${frag}：${line}`);
  }
  const w = agentPromptLine([{
    id: "c:y", agent: "claudeCode", app: "ChatGPT", state: "waiting",
    activity: "", model: "", tokens: 0, limit: 0, cwd: "", startedAt: 0, updatedAt: 0, ageSec: 0,
  }]);
  assert.ok(w.includes("在等用户"), `waiting 没被说出来：${w}`);
  // 怎么才会红：把空列表改成 `return agentBrief(list)`（闲聊后面会挂一句"没有 agent 在跑"）。
});

Deno.test("agentBrief：空列表说的话和'有会话但都闲'不一样", () => {
  assert.equal(agentBrief([]), "没有 agent 在跑");
  const idle: AgentSession = {
    id: "x", agent: "a", app: "ChatGPT", state: "idle", activity: "", model: "",
    tokens: 0, limit: 0, cwd: "", startedAt: 0, updatedAt: 0, ageSec: 0,
  };
  const b = agentBrief([idle]);
  assert.ok(b.includes("ChatGPT"));
  assert.ok(!b.includes("在跑"));
});

/* ───────────────────────── 功能契约 ───────────────────────── */

Deno.test("功能契约：路由表、快照可序列化、rev 单调", () => {
  const f = createAgentsFeature();
  assert.equal(f.id, "agents");
  assert.ok(f.title.length > 0);
  for (const k of ["/request", "/wait", "/pending", "/decide"]) {
    assert.ok(f.routes[k], `缺路由 ${k}`);
  }
  // 快照必须能 JSON 序列化 —— 带函数/循环引用会让**整个 WebSocket 广播**炸掉，
  // 而那会表现为"手机页面整体不更新"，看起来和 agent 没关系。
  const snap = f.snapshot();
  assert.doesNotThrow(() => JSON.stringify(snap));
  assert.ok(Array.isArray((snap as { list: unknown[] }).list));
  // ⚠️ 初值**不是 0**：构造时就 refresh 过一次（会话表读进来 ⇒ 变了）。
  // 第一版断言的是 `=== 0`，红了一次 —— 而红的是断言，不是产品。
  const r0 = f.rev();
  assert.ok(Number.isInteger(r0) && r0 >= 0, `rev 不是个非负整数：${r0}`);
  // 怎么才会红：在 snapshot 里塞一个函数或一个 Map。
});

Deno.test("坏 payload 不 500，回 400", async () => {
  const f = createAgentsFeature();
  const c = ctx();
  const h = f.routes["/request"] as (r: Request, c: FeatureCtx) => Promise<Response>;
  const r = await h(new Request("http://x/", { method: "POST", body: "这不是 JSON" }), c);
  assert.equal(r.status, 400);
  // 怎么才会红：把 `await req.json().catch(() => null)` 的 catch 去掉。
});
