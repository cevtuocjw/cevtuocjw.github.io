/**
 * 功能 · Agent —— 「Mac 上现在有哪些 AI 在干活、干到哪了、要不要我点一下」
 *
 * ── 数据从哪来（为什么不去自己挂 hook）──────────────────────────
 *
 * CrewTower 已经在这台机器上把采集做完了，而且是**机器级**的：它给
 * Claude / Codex / DSH 都挂了 hook，把每个会话归一成一条记录写进
 * `sessions.json`，**连别的 App 里跑的会话都能看到**（`terminal.appName`）。
 *
 * 我们再挂一套只会得到**第二份互不相干的真相**，而两份必然漂移 ——
 * 这是这个项目反复踩的形状。所以：**读它那一份**。
 *
 * ⚠️ 但它是**依赖**不是我们的数据 ⇒ 每个字段都留退路，不认识的一律不抛。
 *
 * ── 批准这件事（⚠️ 读之前先看 `SAFE_FALLBACK`）───────────────────
 *
 * 实测（REA + 直接跑）CrewTower 的 `notch-hook` 在**连不上它自己**时输出：
 *
 *     {"hookSpecificOutput":{"hookEventName":"PermissionRequest",
 *                            "decision":{"behavior":"allow"}}}
 *
 * ⇒ **CrewTower 没开的时候，所有权限请求被自动批准。** 那是 fail-open。
 *
 * 我们**不抄这个选择**。理由不是"更安全"这种空话，是具体的：
 * 一个 fail-open 的 hook 出错时，症状是**没有任何症状** ——
 * agent 照常干活、日志干净，只有事后才发现它改了一个没人批准的文件。
 * 而 fail-closed（`ask`）出错时，用户只是被多问一次。**代价不对称。**
 */

import type { Feature, FeatureCtx } from "./types.ts";

/* ───────────────────────── 会话表（读 CrewTower） ───────────────────────── */

export const SESSIONS_PATH =
  `${Deno.env.get("HOME")}/Library/Application Support/CrewTower/sessions.json`;

/**
 * ⚠️⚠️ `updatedAt` / `startedAt` 是 **CoreFoundation 纪元**（2001-01-01）。
 * 实测 `813831748.24 + 978307200 = 1792138948` → 2026-10-16T08:22:28Z，
 * 和那个文件 mtime 逐秒吻合。直接 `new Date(x*1000)` 得到 **1995 年** ——
 * 而它**看起来仍然像个日期**，所以不会有人怀疑到换算上。
 */
export const CF_EPOCH_OFFSET = 978307200;
export const cfToUnix = (cf: number): number => (Number.isFinite(cf) ? cf + CF_EPOCH_OFFSET : 0);

export type AgentState = "working" | "waiting" | "idle" | "unknown";

export interface AgentMessage { role: string; text: string }

export interface AgentSession {
  id: string;
  agent: string;
  app: string;
  state: AgentState;
  activity: string;
  /** 最近 8 条 user/assistant 文本（来自 transcriptPath；读不到就用 activity 兜底） */
  messages: AgentMessage[];
  /** 本轮从最后一条 user 消息到现在经过的秒数（右侧 TURN） */
  turnSec: number;
  /** 这个会话从开始到现在的总时长（顶部 TOTAL） */
  sessionSec: number;
  /** 最近 6 次工具调用（name + 一句描述），给手表的过程列表 */
  steps: string[];
  transcriptPath: string;
  model: string;
  tokens: number;
  limit: number;
  cwd: string;
  startedAt: number;
  updatedAt: number;
  ageSec: number;
}

const str = (v: unknown): string => (typeof v === "string" ? v : "");
const num = (v: unknown): number => (typeof v === "number" && Number.isFinite(v) ? v : 0);

/**
 * `status` 是**只有一个键的单键对象**：`{working:{activity}}` / `{idle:{}}`。
 * 我们不写死哪些键合法 —— CrewTower 加一种状态是它的事，
 * 写死的话我们会在它升级那天**静默地把新状态显示成 unknown**。
 * ⚠️ 但 unknown **绝不能**被读成 `idle`：idle 会排到最后、变灰，
 * 等于把"需要你"的东西藏起来。
 */
export function readStatus(status: unknown): { state: AgentState; activity: string } {
  if (!status || typeof status !== "object") return { state: "unknown", activity: "" };
  const obj = status as Record<string, unknown>;
  const key = Object.keys(obj)[0] ?? "";
  const body = (obj[key] ?? {}) as Record<string, unknown>;
  const activity = str(body.activity) || str(body.message) || str(body.detail);
  const known: Record<string, AgentState> = {
    working: "working", running: "working",
    waiting: "waiting", blocked: "waiting", needs_approval: "waiting", permission: "waiting",
    idle: "idle", done: "idle",
  };
  return { state: known[key] ?? "unknown", activity };
}

export function parseOne(raw: unknown): AgentSession | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const id = str(o.id);
  if (!id) return null;
  const terminal = (o.terminal ?? {}) as Record<string, unknown>;
  const context = (o.context ?? {}) as Record<string, unknown>;
  const { state, activity } = readStatus(o.status);
  return {
    id,
    agent: str(o.agent) || id.split(":")[0] || "unknown",
    app: str(terminal.appName) || "—",
    state, activity,
    messages: [],
    turnSec: 0,
    sessionSec: 0,
    steps: [],
    transcriptPath: str(o.transcriptPath),
    model: str(context.model),
    tokens: num(context.tokens),
    limit: num(context.limit),
    cwd: str(o.cwd),
    startedAt: cfToUnix(num(o.startedAt)),
    updatedAt: cfToUnix(num(o.updatedAt)),
    ageSec: 0,
  };
}

/** 坏输入一律 `[]`，**不抛** —— 抛一次整个面板就空了，而空面板和"没人在跑"一样。 */
export function parseSessions(text: string): AgentSession[] {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return [];
  }
  const list = Array.isArray(data)
    ? data
    : (data && typeof data === "object" ? Object.values(data as Record<string, unknown>) : []);
  return list.map(parseOne).filter((x): x is AgentSession => x !== null);
}

/** 「在等你」永远排第一 —— 一条 waiting 埋在十条 idle 底下 = 这个功能等于没做。 */
export function rankAgents(list: AgentSession[], nowMs: number): AgentSession[] {
  const weight: Record<AgentState, number> = { waiting: 0, working: 1, unknown: 2, idle: 3 };
  return list
    .map((s) => ({ ...s, ageSec: s.updatedAt ? Math.max(0, Math.round(nowMs / 1000 - s.updatedAt)) : -1 }))
    .sort((a, b) => (weight[a.state] - weight[b.state]) || (b.updatedAt - a.updatedAt));
}

export function agentBrief(list: AgentSession[]): string {
  if (!list.length) return "没有 agent 在跑";
  const w = list.filter((s) => s.state === "working").length;
  const t = list.filter((s) => s.state === "waiting").length;
  const head = list[0];
  const parts = [`${list.length} 会话`];
  if (w) parts.push(`${w} 在跑`);
  if (t) parts.push(`${t} 等你`);
  parts.push(`${head.app} · ${head.activity || head.state}`);
  return parts.join(" | ");
}

/**
 * 给**矿灵自己看**的那一行。空列表必须是**空字符串** ——
 * 否则每一句闲聊后面都跟着"没有 agent 在跑"，模型会忍不住说出来。
 */
export function agentPromptLine(list: AgentSession[]): string {
  if (!list.length) return "";
  const one = (s: AgentSession) => {
    const tok = s.limit > 0
      ? `（上下文 ${Math.round(s.tokens / 1000)}k/${Math.round(s.limit / 1000)}k）`
      : "";
    const what = s.activity ? `「${s.activity}」` : "";
    const label = s.state === "working" ? "正在做" : s.state === "waiting" ? "**在等用户**" : "空闲";
    return `${s.app} ${label}${what}${tok}`;
  };
  return `Mac 上的 AI agent 现状：${list.map(one).join("；")}。`;
}

/* ───────────────────────── 批准队列 ───────────────────────── */

export type Behavior = "allow" | "deny" | "ask";

/**
 * ⚠️ 没拿到决定时回什么。
 *
 * `ask` = **交还给 Claude Code 自己的权限流程**（它会正常弹窗问你）。
 * 这是**唯一**可接受的默认值：`allow` 是 CrewTower 那边的选择，
 * 而它的失败模式是静默的（见文件头）。`deny` 又会让"没人看手机"变成"活干不了"。
 */
export const SAFE_FALLBACK: Behavior = "ask";

export interface Approval {
  id: string;
  /** Claude Code 传来的原始 payload（我们已经挑出要显示的字段，但原始那份留着）。 */
  raw: Record<string, unknown>;
  event: string;
  tool: string;
  /** 工具参数里最像"人要看的那一句话"的那条，例如整条 bash 命令。 */
  detail: string;
  cwd: string;
  sessionId: string;
  /** 哪个 App 发来的（从会话表反查；查不到就是空）。 */
  app: string;
  createdAt: number;
  /** 决定；null = 还没人答。 */
  decision: Behavior | null;
  decidedAt: number;
  /** 谁答的：`phone` / `device` / `timeout` / `test`。 */
  decidedBy: string;
}

/** 等待者：hook 那边长轮询，一有决定立刻唤醒。 */
type Waiter = (b: Behavior, by: string) => void;

const approvals = new Map<string, Approval>();
const waiters = new Map<string, Waiter[]>();
let approvalSeq = 0;

/** 只保留最近的若干条；参数里可能带密钥，**超时就丢**。 */
export const APPROVAL_TTL_MS = 10 * 60 * 1000;
export const APPROVAL_KEEP = 40;

const clip = (s: string, n: number) => (s.length > n ? s.slice(0, n) + "…" : s);

/**
 * 从 Claude Code 的 `PermissionRequest` payload 里挑出"人要看的那一句"。
 *
 * ⚠️ 挑错字段的后果是**用户看不到他在批什么** —— 而他会点"允许"。
 * 所以这里对几个常见的工具各自挑最像命令的那个字段，挑不到就退回整个 JSON 的短摘要。
 */
export function describeRequest(payload: Record<string, unknown>): {
  tool: string; detail: string; cwd: string; sessionId: string;
} {
  const tool = str(payload.tool_name) || str(payload.toolName) || "(未知工具)";
  const input = (payload.tool_input ?? payload.toolInput ?? {}) as Record<string, unknown>;
  const firstOf = (...keys: string[]) => {
    for (const k of keys) {
      const v = input[k];
      if (typeof v === "string" && v.trim()) return v.trim();
    }
    return "";
  };
  let detail = firstOf("command", "file_path", "path", "url", "pattern", "query", "prompt");
  if (!detail) {
    // ⚠️ 空的 `{}` 要当成"没有参数"，不能原样显示成 `{}` ——
    // 那看起来像"参数是一对花括号"，而用户会以为这是命令本身然后点允许。
    // （这条是测试抓出来的：我原来只判了 `!detail`，而 `JSON.stringify({})` 是 `"{}"`，truthy。）
    const keys = Object.keys(input);
    if (keys.length) {
      try {
        detail = JSON.stringify(input);
      } catch {
        detail = "";
      }
    }
  }
  if (!detail) detail = "(没有参数)";
  return {
    tool,
    detail: clip(detail.replace(/\s+/g, " "), 400),
    cwd: str(payload.cwd),
    sessionId: str(payload.session_id) || str(payload.sessionId),
  };
}

function resolve(id: string, behavior: Behavior, by: string): boolean {
  const a = approvals.get(id);
  if (!a || a.decision !== null) return false;
  a.decision = behavior;
  a.decidedAt = Date.now();
  a.decidedBy = by;
  const ws = waiters.get(id) ?? [];
  waiters.delete(id);
  for (const w of ws) w(behavior, by);
  return true;
}

function prune(now: number): void {
  for (const [id, a] of approvals) {
    if (now - a.createdAt > APPROVAL_TTL_MS) approvals.delete(id);
  }
  if (approvals.size > APPROVAL_KEEP) {
    // Map 保持插入顺序 ⇒ 最旧的在最前面。
    for (const id of [...approvals.keys()].slice(0, approvals.size - APPROVAL_KEEP)) {
      approvals.delete(id);
    }
  }
}

/* ───────────────────────── 最近消息 ───────────────────────── */

const msgCache = new Map<string, { mtime: number; msgs: AgentMessage[] }>();

/** 只读一次 transcript，拿到「本轮起点」和最近工具调用。按 mtime 缓存。 */
const metaCache = new Map<string, { mtime: number; steps: string[]; lastUserTs: number }>();
export function readMeta(path: string): { steps: string[]; lastUserTs: number } {
  if (!path) return { steps: [], lastUserTs: 0 };
  try {
    const st = Deno.statSync(path);
    const mt = st.mtime?.getTime() ?? 0;
    const hit = metaCache.get(path);
    if (hit && hit.mtime === mt) return hit;
    const lines = Deno.readTextFileSync(path).split("\n");
    const steps: string[] = [];
    let lastUserTs = 0;
    for (let i = lines.length - 1; i >= 0; i--) {
      const line = lines[i].trim();
      if (!line) continue;
      let o: Record<string, unknown>;
      try { o = JSON.parse(line) as Record<string, unknown>; } catch { continue; }
      const msg = (o.message ?? o.payload ?? o) as Record<string, unknown>;
      const role = str(msg.role);
      if (!lastUserTs && role === "user") {
        const t = Date.parse(str(o.timestamp));
        if (Number.isFinite(t)) lastUserTs = t;
      }
      if (steps.length < 6 && role === "assistant" && Array.isArray(msg.content)) {
        for (const x of msg.content as unknown[]) {
          if (!x || typeof x !== "object") continue;
          const b = x as Record<string, unknown>;
          if (b.type !== "tool_use") continue;
          const name = str(b.name) || "tool";
          const inp = (b.input ?? {}) as Record<string, unknown>;
          const desc = str(inp.description) || str(inp.command).split("\n")[0] || str(inp.file_path);
          steps.push(desc ? `${name} - ${desc}` : name);
          break;
        }
      }
      if (lastUserTs && steps.length >= 6) break;
    }
    steps.reverse();
    const out = { mtime: mt, steps, lastUserTs };
    metaCache.set(path, out);
    return out;
  } catch {
    return { steps: [], lastUserTs: 0 };
  }
}


function clipMsg(s: string, n: number): string {
  // ⚠️ 手表字体只覆盖 ASCII / 中文 / 中文标点。其它字符（emoji、零宽、
  // 数学符号）在 Montserrat/思源里没有字形，会显示成一个个长方形。
  // 在服务端就丢掉它们 —— 不能指望每台设备都装全套字体。
  s = s.replace(/\[([^\]]*)\]\([^)]*\)/g, "$1"); // markdown 链接只留文字
  s = s.replace(/[#*`>_~]+/g, " ");                 // markdown 记号不占手表宽度
  s = s.replace(/[^\x20-\x7e\u3000-\u303f\uff00-\uffef\u4e00-\u9fff\u2000-\u206f]/g, " ");
  s = s.replace(/\s+/g, " ").trim();
  return s.length > n ? s.slice(0, n) + "…" : s;
}

/** 从 Claude/Codex 的 JSONL 里倒着找最近 3 条 user/assistant 文本。
 *  读不到就退回 CrewTower 的 activity —— 不能让手表只显示 (no activity)。 */
export function readMessages(path: string, fallback: string): AgentMessage[] {
  const fb = fallback ? [{ role: "activity", text: clipMsg(fallback, 160) }] : [];
  if (!path) return fb;
  try {
    const st = Deno.statSync(path);
    const cached = msgCache.get(path);
    const mt = st.mtime?.getTime() ?? 0;
    if (cached && cached.mtime === mt) return cached.msgs;
    const lines = Deno.readTextFileSync(path).split("\n");
    // ⚠️ 不能"凑够 3 条就停" —— 最近 3 行经常全是 user（含图片占位、续接摘要），
    // 于是最新的 assistant 回复永远轮不到。先多收 32 条、滤掉噪声，再取最后 8 条。
    const picked: AgentMessage[] = [];
    // 一轮进行中时，assistant 的文本还没落盘（transcript 里只有 thinking / tool_use）。
    // 如果不补一条，手表上就只剩用户自己说的话 —— 看起来像"对面没在干活"。
    let live = "";
    let seenText = false;
    for (let i = lines.length - 1; i >= 0 && picked.length < 32; i--) {
      const line = lines[i].trim();
      if (!line) continue;
      let o: Record<string, unknown>;
      try { o = JSON.parse(line) as Record<string, unknown>; } catch { continue; }
      const msg = (o.message ?? o.payload ?? o) as Record<string, unknown>;
      const role = str(msg.role);
      if (role !== "user" && role !== "assistant") continue;
      let text = "";
      const content = msg.content;
      if (typeof content === "string") text = content;
      else if (Array.isArray(content)) {
        text = content
          .filter((x) => x && typeof x === "object" && (x as Record<string, unknown>).type === "text")
          .map((x) => str((x as Record<string, unknown>).text))
          .join(" ");
      }
      if (!text) text = str(msg.text);
      if (!text) {
        // 只为了拿到"最近一次 assistant 在做什么"；反向扫描，第一个就是最新的。
        if (!seenText && role === "assistant" && !live && Array.isArray(content)) {
          for (const x of content) {
            if (!x || typeof x !== "object") continue;
            const b = x as Record<string, unknown>;
            if (b.type === "tool_use") {
              const name = str(b.name) || "工具";
              const inp = (b.input ?? {}) as Record<string, unknown>;
              const desc = str(inp.description) || str(inp.command).split("\n")[0] || str(inp.file_path);
              live = desc ? `正在调用 ${name}：${desc}` : `正在调用 ${name}`;
              break;
            }
            if (b.type === "thinking") { live = "正在思考"; }
          }
        }
        continue;
      }
      // 工具结果 / 系统注入 / 图片占位 / 续接摘要不是"人想看的那句话"
      if (text.startsWith("<") || text.includes("tool_result")) continue;
      if (text.startsWith("[Image:")) continue;
      if (text.startsWith("This session is being continued from a previous conversation")) continue;
      if (text.startsWith("[Request interrupted")) continue;
      if (text.trim() === "No response requested.") continue;
      // 手表一行 180 字节；中文 3 字节 ⇒ 最多 48 字（含角色前缀也不溢出）
      picked.push({ role, text: clipMsg(text, 70) });
      seenText = true;
    }
    picked.reverse();
    const out = picked.slice(-8);
    // 反向扫描时，live 只会在"遇到任何文本之前"被设置 ⇒ 它一定比所有文本都新。
    // 所以只要有，就补成一条 AI 消息（说明这一轮还在跑）。
    if (live) out.push({ role: "assistant", text: clipMsg(live, 70) });
    const msgs = out.length ? out : fb;
    msgCache.set(path, { mtime: mt, msgs });
    return msgs;
  } catch {
    return fb;
  }
}

/* ───────────────────────── 一键动作 ───────────────────────── */

function pad2(n: number): string { return String(n).padStart(2, "0"); }

function handoffStamp(): string {
  const d = new Date();
  return `${d.getFullYear()}${pad2(d.getMonth() + 1)}${pad2(d.getDate())}-` +
    `${pad2(d.getHours())}${pad2(d.getMinutes())}`;
}

async function readClipboard(): Promise<string> {
  try {
    const r = await new Deno.Command("/usr/bin/osascript", {
      args: ["-e", "the clipboard as text"], stdout: "piped", stderr: "null",
    }).output();
    return new TextDecoder().decode(r.stdout).trimEnd();
  } catch {
    return "";
  }
}

async function copyToClipboard(text: string): Promise<boolean> {
  const head = text.slice(0, 24);
  // ① 首选 pbcopy。⚠️ 必须在**同一个进程上下文**里读回来验证：
  //    launchd 服务里 pbcopy 可能退出 0 但剪贴板里什么都没有。
  try {
    const p = new Deno.Command("/usr/bin/pbcopy", { stdin: "piped", stdout: "null", stderr: "null" });
    const child = p.spawn();
    const w = child.stdin.getWriter();
    await w.write(new TextEncoder().encode(text));
    await w.close();
    const st = await child.status;
    if (st.success) {
      const back = await new Deno.Command("/usr/bin/pbpaste", { stdout: "piped" }).output()
        .then((r) => new TextDecoder().decode(r.stdout)).catch(() => "");
      if (back.includes(head)) return true;
    }
  } catch { /* 走下面的 osascript */ }

  // ② launchd agent 里 pbcopy 可能没有 pasteboard 权限；osascript 走 GUI 会话通常可以。
  try {
    const tmp = await Deno.makeTempFile({ suffix: ".txt" });
    await Deno.writeTextFile(tmp, text);
    const r = await new Deno.Command("/usr/bin/osascript", {
      args: ["-e", `set the clipboard to (read (POSIX file "${tmp}") as «class utf8»)`],
      stdout: "null", stderr: "null",
    }).output();
    const back = await readClipboard();
    await Deno.remove(tmp).catch(() => {});
    return r.success && back.includes(head);
  } catch {
    return false;
  }
}

/** 生成一份可交接的 Markdown，写到会话 cwd/docs/ 下，并把开头那句话复制到剪贴板。 */
export async function makeHandoff(s: AgentSession): Promise<Record<string, unknown>> {
  const stamp = handoffStamp();
  const dir = `${s.cwd}/docs`;
  const file = `${dir}/handoff-${stamp}.md`;
  const msgs = s.messages.length ? s.messages : [{ role: "activity", text: s.activity }];
  const lines: string[] = [];
  lines.push(`# Handoff — ${s.cwd.split("/").filter(Boolean).pop() ?? "session"} — ${stamp}`);
  lines.push("");
  lines.push("## 会话");
  lines.push(`- Agent: \`${s.agent}\``);
  lines.push(`- 状态: \`${s.state}\``);
  lines.push(`- 项目: \`${s.cwd}\``);
  lines.push(`- 上下文: ${s.tokens} / ${s.limit}`);
  lines.push(`- Transcript: \`${s.transcriptPath}\``);
  lines.push("");
  lines.push("## 最近对话");
  for (const m of msgs) {
    lines.push(`### ${m.role === "assistant" ? "AI" : m.role === "user" ? "你" : "活动"}`);
    lines.push(m.text);
    lines.push("");
  }
  lines.push("## 下一步");
  lines.push("- 接着做完上面没有完成的部分；不要重做已经验证过的步骤。");
  lines.push("- 先读这份文档，再读相关文件；改完跑对应的验证。");
  lines.push("");
  let ok = true;
  try {
    Deno.mkdirSync(dir, { recursive: true });
    Deno.writeTextFileSync(file, lines.join("\n"));
  } catch {
    ok = false;
  }
  const prompt = `读 ${file}，然后继续。`;
  const copied = await copyToClipboard(prompt);

  // HANDOFF 不只是写文件：Cherry / Claude 会话直接把「读 handoff，然后继续」
  // 粘进当前输入框并回车（和 CONTINUE 同一个 helper，只是提示词不同）。
  // ⚠️ 试过按 Cherry 的「新任务」开新会话：AX 按钮和 Cmd+N 都不会真的切新聊天，
  //    结果会粘回当前会话。与其赌一个不可靠的新建流程，不如在**当前会话**交接，
  //    提示词里已经写明 handoff 文件路径和「不要重做已验证的步骤」。
  const isCherry = s.app.toLowerCase().includes("cherry") || s.agent.toLowerCase().includes("claude");
  let injected = false;
  let injectError = "";
  if (ok && copied && isCherry) {
    const sent = await launchHelper("send");
    injected = sent.ok;
    injectError = sent.error ?? "";
  }
  // 「文件写了」「提示词复制了」「Cherry 真的输入了」三件事都要成立才算 READY。
  const allOk = ok && copied && (!isCherry || injected);
  return {
    ok: allOk, fileOk: ok, path: file, prompt, copied,
    injected, error: allOk ? undefined : (injectError || (ok ? (copied ? "INJECT_FAIL" : "COPY_FAIL") : "WRITE_FAIL")),
  };
}

/** 可被授权的 helper App：AX 找 composer、检查草稿、Cmd+V、Return。 */
type HelperResult = { ok: boolean; error?: string; result?: string };

async function launchHelper(mode: "send" | "check"): Promise<HelperResult> {
  const home = Deno.env.get("HOME") ?? "";
  const app = `${home}/Applications/COSPOND Send.app`;
  const result = `${home}/Library/Logs/cospond-send.${Date.now()}-${Math.floor(Math.random() * 1e6)}.result`;
  const log = `${home}/Library/Logs/grooved-continue.log`;
  const note = (s: string) => {
    try {
      Deno.writeTextFileSync(log, `[${new Date().toISOString()}] ${mode} ${s}\n`, { append: true });
    } catch { /* 日志失败不能影响动作 */ }
  };

  // ⚠️ 必须走 LaunchServices（open -a），不能直接 exec 那个二进制。
  //    后台 launchd 进程直接 spawn 的子进程会被 TCC 判成父进程的身份，
  //    于是「辅助功能」里明明勾了 COSPOND Send，AXIsProcessTrusted() 仍然是 false。
  //    open -a 让 App 成为自己的 responsible process，授权才会生效。
  try { Deno.removeSync(result); } catch { /* 没有旧结果 */ }

  try {
    const args = ["-n", "-a", app, "--args", mode === "check" ? "--check" : "--send", "--result", result];
    const r = await new Deno.Command("/usr/bin/open", {
      args, stdout: "piped", stderr: "piped",
    }).output();
    if (!r.success) {
      const err = new TextDecoder().decode(r.stderr).trim().slice(0, 200);
      note(`open failed exit=${r.code} ${err}`);
      return { ok: false, error: `open:${err || r.code}` };
    }
  } catch (e) {
    note(`open exception ${String(e).slice(0, 200)}`);
    return { ok: false, error: `open-ex:${String(e).slice(0, 160)}` };
  }

  // open 立刻返回，结果由 helper 写到文件里；最多等 8 秒（串口桥的请求超时是 12 秒）。
  for (let i = 0; i < 80; i++) {
    await new Promise((r) => setTimeout(r, 100));
    try {
      const out = Deno.readTextFileSync(result).trim();
      if (out) {
        note(`result=${out}`);
        try { Deno.removeSync(result); } catch { /* ignore */ }
        return { ok: out === "OK" || out.startsWith("CHECK trusted=1"), error: out, result: out };
      }
    } catch { /* helper 还没写完 */ }
  }
  note("result=NO_RESULT");
  return { ok: false, error: "NO_RESULT" };
}

async function helperSend(): Promise<HelperResult> {
  return await launchHelper("send");
}

async function helperCheck(): Promise<HelperResult> {
  return await launchHelper("check");
}

/**
 * 把剪贴板里的提示词送进 Cherry Studio 的输入框。
 *
 * ⚠️ 这是 UI 自动化，不是 API：Cherry 的 23333 端口只有 LLM 代理，没有"往会话发消息"的接口。
 *    所以流程是：激活窗口 → 校验前台确实是 Cherry Studio → 点输入框 → Cmd+V → Return。
 *    working 时用 Shift+Return（Cherry 自己的"立即引导"），idle 时用 Return。
 * ⚠️ 前台校验失败就直接报错，绝不往别的 App 里粘 —— 测试时曾经粘到微信输入框里过。
 */
async function cherrySend(): Promise<{ ok: boolean; error?: string }> {
  // 1) 优先走可授权的 helper App（AX 找输入框 + 草稿检查 + CGEvent）。
  //    后台服务用 AppleScript/System Events 会被 TCC 以 -1719 拒绝，helper 才能被授权。
  const h = await helperSend();
  if (h.ok) return h;
  // 有草稿 / 找不到输入框 / 前台不对：都不要再走 osascript，避免覆盖用户正在写的东西。
  if (h.error && h.error !== "NOT_TRUSTED") return h;

  // 2) helper 没有辅助功能权限时，退回 osascript（在已授权的 shell 里仍可能可用）。
  // 用 Return（排队发送）而不是 Shift+Return（立即引导）：
  // CONTINUE 的语义是"这一轮结束后继续"，不是打断当前这一轮。
  const mod = "";
  const script = `
tell application "Cherry Studio" to activate
delay 0.6
tell application "System Events"
  set frontName to name of first process whose frontmost is true
  if frontName is not "Cherry Studio" then error "frontmost is " & frontName
  tell process "Cherry Studio"
    set frontmost to true
    set {wx, wy} to position of window 1
    set {ww, wh} to size of window 1
    click at {wx + ww / 2, wy + wh - 110}
    delay 0.25
  end tell
  keystroke "v" using command down
  delay 0.25
  key code 36${mod}
end tell
return "ok"
`;
  try {
    const r = await new Deno.Command("/usr/bin/osascript", {
      args: ["-e", script], stdout: "piped", stderr: "piped",
    }).output();
    return {
      ok: r.success,
      error: r.success ? undefined
        : `helper:${h.error}; osascript:${new TextDecoder().decode(r.stderr).trim().slice(0, 160)}`,
    };
  } catch (e) {
    return { ok: false, error: String(e).slice(0, 200) };
  }
}

/** 继续处理：Codex 走 CLI resume；其它 agent 至少把提示词放进剪贴板。 */
export async function continueSession(s: AgentSession): Promise<Record<string, unknown>> {
  const prompt = "继续处理。先读当前会话上下文，接着把未完成的做完；完成后简要汇报。";
  const copied = await copyToClipboard(prompt);
  const m = s.id.match(/^codex:(.+)$/);
  if (m && s.cwd) {
    try {
      const log = `${Deno.env.get("HOME")}/Library/Logs/grooved-continue.log`;
      const codexBin = Deno.env.get("CODEX_BIN") ??
        `${Deno.env.get("HOME")}/Library/Application Support/CherryStudio/Toolchain/mise/shims/codex`;
      const p = new Deno.Command(codexBin, {
        args: ["exec", "resume", m[1], prompt, "-C", s.cwd, "-s", "workspace-write", "--approve-for-me"],
        cwd: s.cwd, stdin: "null", stdout: "null", stderr: "null",
      });
      const child = p.spawn();
      // 不阻塞请求；结果写日志，失败也不影响手表收到回执。
      child.status.then((st) => {
        try {
          Deno.writeTextFileSync(log, `[${new Date().toISOString()}] codex resume ${m[1]} exit=${st.code}\n`,
            { append: true });
        } catch { /* ignore */ }
      }).catch(() => {});
      return { ok: true, mode: "codex-resume", copied, prompt, note: "已后台执行 codex exec resume，日志在 ~/Library/Logs/grooved-continue.log" };
    } catch (e) {
      return { ok: false, mode: "codex-resume", error: String(e), copied, prompt };
    }
  }

  // Cherry Studio / Claude：它没有 CLI resume，但有输入框。
  const isCherry = s.app.toLowerCase().includes("cherry") || s.agent.toLowerCase().includes("claude");
  if (isCherry) {
    const sent = await cherrySend();
    return {
      ok: sent.ok,
      mode: sent.ok ? "cherry-paste" : "clipboard",
      injected: sent.ok,
      copied,
      prompt,
      error: sent.error,
      note: sent.ok
        ? "已把提示词粘贴到 Cherry Studio 输入框并按 Return 发送（working 时会排队到本轮结束）。"
        : "自动发送失败；提示词已在剪贴板，可手动粘贴。",
    };
  }

  return {
    ok: copied,
    mode: "clipboard",
    copied,
    prompt,
    note: "当前 agent 没有可用的自动发送方式；提示词已复制到剪贴板，粘贴到对话框即可继续。",
  };
}

/* ───────────────────────── 模块 ───────────────────────── */

export function createAgentsFeature(): Feature {
  let list: AgentSession[] = [];
  let rev = 0;
  let err = "";

  const refresh = (): void => {
    try {
      const next = rankAgents(parseSessions(Deno.readTextFileSync(SESSIONS_PATH)), Date.now());
      for (const s of next) {
        s.messages = readMessages(s.transcriptPath, s.activity);
        const meta = readMeta(s.transcriptPath);
        s.steps = meta.steps;
        s.turnSec = meta.lastUserTs ? Math.max(0, Math.floor((Date.now() - meta.lastUserTs) / 1000)) : 0;
        s.sessionSec = s.startedAt > 0 ? Math.max(0, Math.floor(Date.now() / 1000 - s.startedAt)) : 0;
      }
      // 指纹**不含** ageSec —— 它每秒都变，拿它做判据会每 2 秒都"变了"。
      const fp = (l: AgentSession[]) =>
        l.map((s) => `${s.id}|${s.state}|${s.activity}|${s.tokens}|${s.app}`).join("\n");
      if (fp(next) !== fp(list)) rev++;
      list = next;
      err = "";
    } catch (e) {
      // ⚠️ CrewTower 没开是**正常状态**（独立 App）。报错要带出去，
      // 但**不能**和"没有会话"混为一谈 —— 界面上那是两句话。
      err = e instanceof Error ? e.message : String(e);
      if (list.length) { list = []; rev++; }
    }
  };
  refresh();

  return {
    id: "agents",
    // id 是技术键，title 是产品名（见 midi.ts 的注释）。
    title: "Cospon D",

    routes: {
      /** GET /api/agents/list —— 手表 Cospon D 通过 Mac 桥来拉这份数据 */
      "/list": (_req: Request, ctx: FeatureCtx) =>
        ctx.json({
          list: list.map((a) => ({
            id: a.id,
            app: a.app,
            agent: a.agent,
            state: a.state,
            activity: a.activity,
            messages: a.messages,
            transcriptPath: a.transcriptPath,
            // 手表 Cospon D 要显示成 CrewTower 那种卡片：上下文 / 项目 / 时间。
            model: a.model,
            tokens: a.tokens,
            limit: a.limit,
            turnSec: a.turnSec,
            sessionSec: a.sessionSec,
            steps: a.steps,
            cwd: a.cwd,
            ageSec: a.ageSec,
          })),
          pending: pendingList().length,
          err,
        }),

      /** GET /api/agents/watch —— 给手表 WiFi 轮询的纯文本协议（和 USB 桥同一套行） */
      "/watch": () => {
        // ⚠️ 手表那边 activity[120] / msgs[..][180] 是**字节**，不是字符。
        // 180 个中文 = 540 字节，snprintf 会从中间截断 UTF-8 ⇒ 表尾出现半个字。
        // 这里按字节裁（不切断多字节序列），并把每个字段裁到它自己的缓冲区以内。
        const clipBytes = (v: string, max: number): string => {
          const b = new TextEncoder().encode(v);
          if (b.length <= max) return v;
          let end = max;
          while (end > 0 && (b[end] & 0xC0) === 0x80) end--; // 退到字符边界
          return new TextDecoder().decode(b.slice(0, end)).trimEnd() + "…";
        };
        const clean = (v: string, max = 110) =>
          clipBytes(v.replace(/\|/g, "/").replace(/[\r\n]+/g, " "), max);
        // WiFi 这条也要过滤没有字形的字符；否则 emoji 会在手表上变成方框。
        const safe = (v: string, max = 110) => clean(
          v.replace(/[^\x20-\x7e\u3000-\u303f\uff00-\uffef\u4e00-\u9fff\u2000-\u206f]/g, " "),
          max);
        const pend = pendingList();
        let out = `AG ${pend.length} ${list.length}\n`;
        list.slice(0, 3).forEach((s, i) => {
          const project = s.cwd.split("/").filter(Boolean).pop() ?? "";
          out += `SESS ${safe(s.agent, 36)}|${safe(s.app, 36)}|${safe(s.state, 18)}|` +
            `${safe(s.activity, 110)}|${s.tokens}|${s.limit}|${safe(project, 36)}|${s.ageSec}|${s.turnSec}|${s.sessionSec}\n`;
          (s.steps ?? []).slice(0, 6).forEach((t) => {
            out += `STEP ${i}|${safe(t, 90)}\n`;
          });
          (s.messages ?? []).slice(0, 8).forEach((m) => {
            out += `MSG ${i}|${safe(m.role, 12)}|${safe(m.text, 230)}\n`;
          });
        });
        if (pend[0]) out += `PERM ${safe(pend[0].id, 40)}|${safe(pend[0].tool, 30)}|` +
          `${safe(pend[0].detail, 110)}\n`;
        else out += "PERM -\n";
        // 快照结束：手表在这之前只写 staging，收到 END 才一次性重画。
        out += "END\n";
        return new Response(out, { headers: { "content-type": "text/plain; charset=utf-8" } });
      },

      /** 让 hook 把一个待批的请求放进来。 */
      "/request": async (req: Request, ctx: FeatureCtx) => {
        const payload = await req.json().catch(() => null) as Record<string, unknown> | null;
        if (!payload || typeof payload !== "object") {
          return json({ error: "bad_payload" }, 400);
        }
        const now = Date.now();
        prune(now);
        const id = `ap${++approvalSeq}-${now.toString(36)}`;
        const d = describeRequest(payload);
        const a: Approval = {
          id, raw: payload,
          event: str(payload.hook_event_name) || "PermissionRequest",
          tool: d.tool, detail: d.detail, cwd: d.cwd, sessionId: d.sessionId,
          // 会话表里能对上就给出来（对不上不是错误：也可能是 Codex 那边来的）。
          app: list.find((s) => s.id.endsWith(d.sessionId) && d.sessionId)?.app ?? "",
          createdAt: now, decision: null, decidedAt: 0, decidedBy: "",
        };
        approvals.set(id, a);
        rev++;
        ctx.broadcast();
        return json({ id, fallback: SAFE_FALLBACK, watchers: ctx.watchers() });
      },

      /**
       * hook 在这里**长轮询**等决定。
       * ⚠️ 超时必须有上限，而且超时返回的是 `ask` 不是 `allow`（见 SAFE_FALLBACK）。
       */
      "/wait": async (req: Request) => {
        const url = new URL(req.url);
        const id = url.searchParams.get("id") ?? "";
        const timeoutSec = Math.min(120, Math.max(1, Number(url.searchParams.get("timeout") ?? 25)));
        const a = approvals.get(id);
        if (!a) return json({ error: "unknown_id", behavior: SAFE_FALLBACK }, 404);
        if (a.decision !== null) return json({ behavior: a.decision, by: a.decidedBy });

        const behavior = await new Promise<{ b: Behavior; by: string }>((res) => {
          const timer = setTimeout(() => {
            // 超时**不写进 approvals** —— 用户十秒后还有可能点，那时仍然算数。
            const ws = (waiters.get(id) ?? []).filter((w) => w !== wrapped);
            waiters.set(id, ws);
            res({ b: SAFE_FALLBACK, by: "timeout" });
          }, timeoutSec * 1000);
          const wrapped: Waiter = (b, by) => { clearTimeout(timer); res({ b, by }); };
          waiters.set(id, [...(waiters.get(id) ?? []), wrapped]);
        });
        return json({ behavior: behavior.b, by: behavior.by });
      },

      "/pending": () => json({ pending: pendingList() }),

      /** 手表 / 手机上的两个动作：继续处理、交接。 */
      "/action": async (req: Request) => {
        const body = await req.json().catch(() => null) as
          { id?: string; action?: string } | null;
        if (!body?.id || !body.action) return json({ error: "bad_payload" }, 400);
        const s = list.find((x) => x.id === body.id);
        if (!s) return json({ error: "unknown_session" }, 404);
        if (body.action === "handoff") return json(await makeHandoff(s));
        if (body.action === "continue") return json(await continueSession(s));
        return json({ error: "bad_action" }, 400);
      },

      /** 只读诊断：trust / front / composer。不会粘贴或回车。 */
      "/helper-check": async () => json(await helperCheck()),

      /** 手机 / 设备点的那一下。 */
      "/decide": async (req: Request, ctx: FeatureCtx) => {
        const b = await req.json().catch(() => null) as { id?: string; behavior?: string; by?: string } | null;
        if (!b?.id) return json({ error: "no_id" }, 400);
        if (b.behavior !== "allow" && b.behavior !== "deny" && b.behavior !== "ask") {
          // ⚠️ 白名单，不是黑名单：一个拼错的动作**不能**悄悄变成 allow。
          return json({ error: "bad_behavior", got: b.behavior }, 400);
        }
        const ok = resolve(b.id, b.behavior, b.by || "phone");
        rev++;
        ctx.broadcast();
        return json({ ok, id: b.id, behavior: b.behavior }, ok ? 200 : 409);
      },
    },

    snapshot: () => ({
      list,
      err,
      pending: pendingList(),
      safeFallback: SAFE_FALLBACK,
      source: SESSIONS_PATH,
    }),

    rev: () => rev,

    tick: () => {
      refresh();
      // 过期的决定也要让前端知道（那一格该消失了）。
      const before = approvals.size;
      prune(Date.now());
      if (approvals.size !== before) rev++;
    },

    status: () =>
      err ? `CrewTower 会话表读不到：${err.slice(0, 80)}`
        : `${list.length} 会话，${pendingList().length} 个待批`,
  };
}

function pendingList(): Approval[] {
  return [...approvals.values()]
    .filter((a) => a.decision === null)
    .sort((a, b) => b.createdAt - a.createdAt);
}


const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
