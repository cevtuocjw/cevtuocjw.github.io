/**
 * 起一个**真的服务**来测（不是 mock）。
 *
 * 为什么值得多花这一层的钱：这一轮里三个 bug 全都躲过了"单元测试"这一级，
 * 因为它们的形状都是**跨层的**——
 *   · 状态没进 system prompt（ai.ts 对、protocol.ts 对、server.ts 没接）
 *   · 模式表注进 HTML（表对、模板对、替换没发生）
 *   · 页面 TDZ 崩溃（每个函数单独看都对）
 * 单测那一级**结构上就看不见**这三件事。所以这里必须真的起进程、真的开 socket。
 *
 * 端口是固定的：撞车时**必须报得清楚**（见下面那个 `waitForPort` 的报错文案），
 * 不要让它变成一个"莫名其妙的失败"。
 */
import assert from "node:assert/strict";
import { modeTable, PROTOCOL_VERSION, formatState, type DeviceState } from "./protocol.ts";

const PORT = 8799;
const UDP_PORT = 41299;
const BASE = `http://127.0.0.1:${PORT}`;

const env: Record<string, string> = {
  ...Deno.env.toObject(),
  GROOVED_PORT: String(PORT),
  GROOVED_UDP_PORT: String(UDP_PORT),
};

const child = new Deno.Command(Deno.execPath(), {
  args: ["run", "--allow-net", "--allow-env", "--allow-read", "--unstable-net", "link/server.ts"],
  cwd: new URL("..", import.meta.url).pathname,
  env,
  stdout: "piped",
  stderr: "piped",
}).spawn();

let serverOut = "";
(async () => {
  for await (const c of child.stdout) serverOut += new TextDecoder().decode(c);
})();
(async () => {
  for await (const c of child.stderr) serverOut += new TextDecoder().decode(c);
})();

async function waitReady(): Promise<void> {
  for (let i = 0; i < 80; i++) {
    try {
      const r = await fetch(`${BASE}/health`);
      if (r.ok) return;
    } catch { /* 还没起来 */ }
    await new Promise((r) => setTimeout(r, 100));
  }
  // ⚠️ 起不来的原因必须打出来。「测试超时了」和「端口被占了」在处理上差很远，
  // 而它们在没有这行日志的时候长得一模一样。
  throw new Error(`服务没起来（${PORT}/${UDP_PORT}）。可能是端口被占，或启动就崩了。\n--- 服务输出 ---\n${serverOut}`);
}

await waitReady();

/** 往 UDP 口灌一行，等 WS 上收到带这个时钟值的那一帧。 */
async function pushState(s: Partial<DeviceState>): Promise<Record<string, unknown>> {
  const full: DeviceState = {
    version: PROTOCOL_VERSION, clock: "00:00", mode: "NOW", focus: false,
    level: 0, bpm: 0, battery: 0, charging: false, stems: 0, ...s,
  };
  // 每一轮用**新的** socket：复用会让"上一轮没收到"和"这一轮收到了"混在一起。
  const ws = new WebSocket(`ws://127.0.0.1:${PORT}/api/state`);
  const got: Record<string, unknown>[] = [];
  await new Promise<void>((res, rej) => {
    ws.onopen = () => res();
    ws.onerror = () => rej(new Error("WS 连不上"));
  });
  ws.onmessage = (e) => got.push(JSON.parse(String(e.data)));
  await new Promise((r) => setTimeout(r, 80)); // 等第一帧 snapshot（online:false）

  const udp = Deno.listenDatagram({ port: 0, transport: "udp" });
  udp.send(new TextEncoder().encode(formatState(full)), {
    transport: "udp",
    hostname: "127.0.0.1",
    port: UDP_PORT,
  });
  for (let i = 0; i < 40; i++) {
    const hit = got.find((g) =>
      (g.state as DeviceState)?.clock === full.clock &&
      (g.state as DeviceState)?.bpm === full.bpm
    );
    if (hit) { ws.close(); udp.close(); return hit; }
    await new Promise((r) => setTimeout(r, 50));
  }
  ws.close();
  udp.close();
  throw new Error(`UDP 灌进去的 STATE 没有出现在 WS 上。收到过：${JSON.stringify(got)}`);
}

Deno.test("UDP → WebSocket：整条链路真的通", async () => {
  const frame = await pushState({ clock: "13:37", mode: "BUILD", level: 0.73, bpm: 104, battery: 88, charging: true, stems: 4 });
  assert.equal(frame.online, true, "推了状态却还是离线");
  const s = frame.state as DeviceState;
  assert.equal(s.mode, "BUILD");
  assert.equal(s.level, 0.73);
  assert.equal(s.bpm, 104);
  assert.equal(s.stems, 4);
  // 怎么才会红：把 udpLoop 里的 broadcast() 删掉 / 把 parseState 的版本判断写死。
  // ⚠️ 这一条是**整个伴侣端的主干** —— 它断了，手机上所有读数都是死的。
});

Deno.test("在线 → 离线：online 翻转，但读数**如实保留**（由一个字说清算不算数）", async () => {
  const dev: Partial<DeviceState> = { clock: "09:15", mode: "REST", level: 0.66, bpm: 72, battery: 41, stems: 2 };
  await pushState(dev);

  const on = await (await fetch(`${BASE}/health`)).json();
  assert.equal(on.device_online, true);
  assert.ok(on.last_seen_ms_ago >= 0 && on.last_seen_ms_ago < 4000, `last_seen 不合理：${on.last_seen_ms_ago}`);
  // 怎么才会红：把 lastSeen 的赋值删掉 ⇒ device_online 永远是 false。

  // 等过 OFFLINE_MS（4000）。整个套件里唯一一处必须真等的地方，所以只留一条。
  await new Promise((r) => setTimeout(r, 4300));

  const off = await (await fetch(`${BASE}/health`)).json();
  assert.equal(off.device_online, false, "超过 4s 没上报，还判在线");
  await (await fetch(`${BASE}/health`)).body?.cancel();
  // 怎么才会红：把 OFFLINE_MS 改成 Number.MAX_SAFE_INTEGER。
  // ⚠️ 两条都要：只测"推了之后在线"的话，一个**永远返回 true** 的实现能全绿 ——
  // 而那正是最坏的一种：设备拔了线，页面上一切照旧。

  // 离线这一侧也要看得见 —— 新连上的 WS 会立刻收到一帧 snapshot。
  // （不能靠"等广播"：广播只在收到 UDP 包时发生，而那会把设备变回在线。）
  const ws = new WebSocket(`ws://127.0.0.1:${PORT}/api/state`);
  const first = await new Promise<Record<string, unknown>>((res, rej) => {
    ws.onmessage = (e) => res(JSON.parse(String(e.data)));
    ws.onerror = () => rej(new Error("WS 连不上"));
  });
  ws.close();

  assert.equal(first.online, false, "离线时新连上的客户端收到的第一帧还说在线");
  const s = first.state as DeviceState;
  // ⚠️ 这两条就是那条契约本身：数值**照样发**，算不算数由 `online` 说。
  // 从前 snapshot() 会把离线时的 level 清成 0，而 bpm/电量/轨数不清 ——
  // 于是手机上是「设备离线 · BPM 104 · 4 轨 STEM · 电平 0.00」：
  // 一半活的读数，读起来像设备还在、只是恰好很安静。
  assert.equal(s.level, 0.66, "离线时电平被服务端清掉了（客户端会自己处理，这里不该清）");
  assert.equal(s.bpm, 72, "离线时读数被改写了 —— 契约是如实转发");
  assert.equal(s.stems, 2);
  // 怎么才会红：把 snapshot() 改回 `{...lastState, level: online ? lastState.level : 0}`
  // ⇒ 上面那条 assert.equal(s.level, 0.66) 立刻炸。
});

Deno.test("/api/modes 和 index.html 里注入的必须是同一份", async () => {
  const api = await (await fetch(`${BASE}/api/modes`)).json();
  assert.deepEqual(api.modes, modeTable());

  const html = await (await fetch(`${BASE}/`)).text();
  const m = html.match(/const MODES = (\[.*?\]);/s);
  assert.ok(m, "index.html 里找不到 `const MODES = [...]` —— 占位符被改了？");
  assert.deepEqual(JSON.parse(m![1]), modeTable(), "注入进 HTML 的表和 /api/modes 不一致");

  // 单源的关键一条：色相必须来自 protocol.ts，而不是页面里另抄的一份。
  assert.ok(html.includes('"#35E0D0"'), "NOW 的色相没出现在 HTML 里");
  assert.ok(!/id:\s*'NOW'[^}]*hue:\s*'#/.test(html), "HTML 里还留着手抄的模式表");
  // 怎么才会红：把 serveStatic 里那段 replace 删掉 ⇒ 匹配到的是占位符 `[]`，
  // deepEqual 立刻炸；或者把 MODE_HUE.NOW 改掉 ⇒ 最后那条 includes 炸。
});

Deno.test("/api/device 真的挡住了不认识的命令，也如实报告'没送到'", async () => {
  const post = (body: unknown) =>
    fetch(`${BASE}/api/device`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });

  const bad = await post({ cmd: "haptic:teleport" });
  assert.equal(bad.status, 400);
  assert.equal((await bad.json()).error, "bad_cmd");

  const none = await post({});
  assert.equal(none.status, 400);
  await none.body?.cancel(); // Deno 的 leak 检查器会抓没消费的响应体 —— 见文件末尾那条注释

  const ok = await post({ cmd: "haptic:tick" });
  assert.equal(ok.status, 202);
  const j = await ok.json();
  assert.equal(j.accepted, "haptic:tick");
  // ⚠️ 这条是**诚实性**断言，不是功能断言：下行通道还没接，
  // 所以现在**必须**报 delivered:false。等哪天真的接上了，
  // 这条会红 —— 那正好提醒来把它改成 true，而不是让它一直是句谎话。
  assert.equal(j.delivered, false, "下行还没接，却报告已送达");
  assert.equal(j.reason, "device_downlink_not_wired");
  // 怎么才会红：把 isValidCommand 换成 return true ⇒ 第一条 400 变 202。
});

Deno.test("静态资源：webp 的 MIME 正确，且 /api/state 不走普通 HTTP", async () => {
  const img = await fetch(`${BASE}/pet/mineral-silver-mini.webp`);
  assert.equal(img.status, 200);
  assert.equal(img.headers.get("content-type"), "image/webp");
  await img.body?.cancel(); // 1.6MB，没必要读进来

  const plain = await fetch(`${BASE}/api/state`);
  assert.equal(plain.status, 426, "普通 HTTP 打 /api/state 应当被拒");
  await plain.body?.cancel();

  const missing = await fetch(`${BASE}/../deno.json`);
  assert.ok(missing.status === 400 || missing.status === 404, "路径穿越没被挡住");
  await missing.body?.cancel();
  // ⚠️ `await x.body?.cancel()` 不是洁癖：Deno 的测试跑台有一条 **leak 检查器**，
  // 没消费的响应体会让**整条测试判失败**（报的是 "A fetch response body was created
  // but not consumed"，而不是断言失败）。这是好事 —— 不然这些连接会挂在那儿，
  // 而症状是"测试偶尔卡住"，跟这里毫无关系。第一版就是因为这个红的。
  // 怎么才会红（三条）：删 webp 那行 MIME / 删 upgradeWebSocket 前的 header 判断 /
  // 把 serveStatic 里的 `..` 判断删掉。
});

/** 收尾。⚠️ 一定要 kill —— 留着会占住 8799，下一次跑就是"端口被占"。 */
addEventListener("unload", () => child.kill());
Deno.test("收尾：关掉测试用的服务", () => {
  child.kill();
  assert.ok(true);
});
