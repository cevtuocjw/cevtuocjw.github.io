/**
 * 协议层的测试。
 *
 * ⚠️ 写这些断言时反复问的是同一个问题：**它怎么才会红？**
 * 一个答不上来的断言等于没写 —— 它会一直绿着，而它什么也没测。
 * 每条断言后面的注释里写了"怎么才会红"，`tools/negctl.ts` 会真的去把它们弄红。
 */
import assert from "node:assert/strict";
import {
  DEVICE_COMMANDS,
  formatState,
  isValidCommand,
  MODE_HUE,
  MODE_LABEL,
  MODE_PET,
  MODES,
  modeTable,
  parseState,
  PROTOCOL_VERSION,
  stateBrief,
  type DeviceState,
} from "./protocol.ts";

const base: DeviceState = {
  version: PROTOCOL_VERSION,
  clock: "21:04",
  mode: "BUILD",
  focus: true,
  level: 0.42,
  bpm: 104,
  battery: 88,
  charging: true,
  stems: 4,
};

Deno.test("formatState → parseState 往返不丢字段", () => {
  const back = parseState(formatState(base));
  assert.ok(back, "往返之后解不出来");
  assert.equal(back.clock, base.clock);
  assert.equal(back.mode, base.mode);
  assert.equal(back.focus, base.focus);
  assert.equal(back.level, base.level);
  assert.equal(back.bpm, base.bpm);
  assert.equal(back.battery, base.battery);
  assert.equal(back.charging, base.charging);
  assert.equal(back.stems, base.stems);
  // ⚠️ 光有上面这些还不够 —— 它们只证明了"这一条能往返"。
  // 如果 formatState 退化成返回一个常数，上面每一条**照样绿**（只不过解出来的是那个常数）。
  // 所以再钉一条：**两个不同的输入必须给出不同的输出**。
  // 怎么才会红：把 formatState 改成 `return "STATE|3|21:04|BUILD|...\n"` 写死。
  const other = parseState(formatState({ ...base, clock: "07:15", bpm: 90, mode: "REST" }));
  assert.ok(other);
  assert.notEqual(other.clock, back.clock, "两个不同的输入给出了同一个时钟 —— formatState 可能退化成常数了");
  assert.notEqual(other.mode, back.mode);
  assert.notEqual(other.bpm, back.bpm);
});

Deno.test("竖线和换行必须被剔掉 —— 否则一个曲名就能把协议撕开", () => {
  const nasty: DeviceState = { ...base, clock: "21|04\nSTATE|3|evil" };
  const line = formatState(nasty);
  // 整条记录必须仍然只有一行、且只切出 10 段。
  assert.equal(line.split("\n").length, 2, "换行没被剔掉：一条记录变成了两条");
  const back = parseState(line);
  assert.ok(back, "带竖线的输入把整条记录撑坏了");
  assert.ok(!back.clock.includes("|"), "字段里的竖线漏出来了");
  // 怎么才会红：把 clean() 里的 replace 去掉。
});

Deno.test("结构性错误 ⇒ 整条丢掉", () => {
  // 这三样是**结构**：错了就说明我们和对面说的不是同一门语言，整条都不可信。
  const structural = [
    "",
    "STATE",
    "STATE|3|21:04|NOW|1|0.4|104|88|0",                          // 少一段
    "STATE|3|21:04|NOW|1|0.4|104|88|0|0|extra",                  // 多一段
    `STATE|${PROTOCOL_VERSION + 1}|21:04|NOW|1|0.4|104|88|0|0`,  // 版本对不上
    "HELLO|3|21:04|NOW|1|0.4|104|88|0|0",                        // 类型不对
    "STATE|3|21:04|DANCE|1|0.4|104|88|0|0",                      // 模式不在表里
  ];
  for (const b of structural) {
    assert.equal(parseState(b), null, `结构性坏输入被放行了：${JSON.stringify(b)}`);
  }
  // 怎么才会红：把 parseState 里任何一条校验（段数 / 版本 / 模式）删掉。
  // 「模式不在表里」那条尤其重要：MODES 是个封闭枚举，
  // 放行未知模式会让前端的 setMode 查不到、按钮全灭，而设备日志里一切正常。
});

Deno.test("数值字段坏掉 ⇒ 退回 0，但**整条仍然有效**（这条是故意的）", () => {
  // 这是写这一组测试时才翻出来的一个**没写下来的决定**：
  // `Number("abc") || 0` 让坏数值变成 0，而不是让整条记录作废。
  // 想清楚之后判定这个方向是对的 —— 一个电平字段写坏了，
  // 只是"环不动"；而整条丢掉，是设备从页面上整个消失、
  // 顶栏直接写「设备离线」。**用一个字段的错去惩罚另外八个字段，代价更大。**
  const p = parseState("STATE|3|21:04|NOW|1|abc|104|88|0|0");
  assert.ok(p, "一个坏数值把整条记录废掉了 —— 代价太大");
  assert.equal(p.level, 0, "坏数值应当退回 0");
  assert.equal(p.bpm, 104, "坏的是 level，不该牵连 bpm");
  assert.equal(p.clock, "21:04");
  // 怎么才会红：把 `Number(parts[5]) || 0` 改成对 NaN 直接 return null。
  // ⚠️ 这条断言的价值在于**它是有一个正确方向的**：
  // 换成"必须 null"它也会绿一半（那些结构性用例），但这里的 `p.level === 0`
  // 会在有人"顺手把它改成 return null"的时候立刻红。
});

Deno.test("parseState 会把电平夹进 0..1（设备发来 9.9 也不能穿透到画面）", () => {
  const hi = parseState("STATE|3|21:04|NOW|1|9.9|104|88|0|0");
  const lo = parseState("STATE|3|21:04|NOW|1|-3|104|88|0|0");
  assert.equal(hi?.level, 1);
  assert.equal(lo?.level, 0);
  // 怎么才会红：把 clamp01 去掉。
  // 这条不是洁癖：level 直接乘进环形的长度，9.9 会让整圈画到画布外面。
});

Deno.test("三张模式表必须逐一覆盖枚举里的每个模式", () => {
  // 这是"表不全"那一类 bug 的唯一防线：加了新模式但忘了加色相，
  // 拿到的就是 undefined —— 而 CSS 的 `--accent: undefined` 是**静默无效**的，
  // 页面会退回上一个模式的颜色，看起来只是"这个模式颜色没变"。
  for (const m of MODES) {
    assert.match(MODE_HUE[m], /^#[0-9A-Fa-f]{6}$/, `${m} 没有色相`);
    assert.ok(MODE_LABEL[m]?.length > 0, `${m} 没有中文名`);
    assert.ok(["silver", "lead", "zinc"].includes(MODE_PET[m]), `${m} 没有配矿物`);
  }
  // 怎么才会红：删掉 MODE_HUE 里的任意一项，或往 MODES 里加一个新模式。
});

Deno.test("modeTable() 与 MODES 逐项对齐（顺序、长度、id）", () => {
  const t = modeTable();
  assert.equal(t.length, MODES.length);
  assert.deepEqual(t.map((x) => x.id), [...MODES]);
  // 怎么才会红：把 modeTable 里的 MODES.map 换成 Object.keys(MODE_HUE).map ——
  // 对象的键顺序恰好和数组一样，所以**这条也得盯住顺序**，
  // 否则前端按钮的顺序会跟着"谁先被写进对象"走。
  assert.equal(new Set(t.map((x) => x.id)).size, MODES.length, "有重复的模式 id");
});

Deno.test("stateBrief：离线时说离线，且不许出现任何读数", () => {
  const s = stateBrief(base, false);
  assert.ok(s.includes("离线"));
  assert.ok(!/\d+\s*BPM/.test(s), "离线时还把节拍写出来了");
  assert.ok(!s.includes("88"), "离线时还把电量写出来了");
  // 怎么才会红：把 stateBrief 里的 `if (!online)` 分支删掉。
  // 这条看着像洁癖，其实正是那个实测过的 bug 的防线：
  // 模型拿到"电量 88%"就会说出来，而设备根本没连上。
});

Deno.test("stateBrief：在线但没测到节拍 → 说「还没测到」，不说「0 BPM」", () => {
  const s = stateBrief({ ...base, bpm: 0, stems: 0 }, true);
  assert.ok(s.includes("还没测到"));
  assert.ok(!/节拍 0/.test(s));
  assert.ok(s.includes("拆轨 无"), `stems=0 应当说「无」而不是「0 轨」：${s}`);
  // 怎么才会红：把 `s.bpm > 0 ? … : "还没测到"` 写成 `${s.bpm} BPM`。
  // 「没有数据」和「数据是 0」是两件事 —— 让模型说出"现在的节奏是 0 BPM"
  // 比让它说"不知道"更糟。
});

Deno.test("stateBrief：在线时读数必须真的带上", () => {
  const s = stateBrief(base, true);
  for (const frag of ["BUILD", "21:04", "0.42", "104", "88", "4 轨", "充电中"]) {
    assert.ok(s.includes(frag), `在线简报里缺了 ${frag}：${s}`);
  }
  // 怎么才会红：把 stateBrief 的在线分支改成返回一个常数串。
  // ⚠️ 这条和上面那条是**一对**：只测"离线时不读数"的话，
  // 一个永远返回"设备离线"的实现能全绿通过。
});

Deno.test("stateBrief：agent 那一行真的被接上了（差分）", () => {
  const line = "Mac 上的 AI agent 现状：Cherry Studio 正在做「改 app.js」。";
  const without = stateBrief(base, true);
  const with_ = stateBrief(base, true, line);

  assert.notEqual(without, with_, "传了 agentLine 但简报一个字没变 —— 它没被用上");
  assert.ok(with_.includes("改 app.js"), `agent 那行没进去：${with_}`);
  assert.ok(!without.includes("agent"), "没传 agentLine 却出现了 agent 字样");
  // 离线那一支也要带上 —— 人不在电脑前时，"设备连不上"和"agent 在等你"
  // 是两条都要知道的信息，不能因为前者就丢掉后者。
  assert.ok(stateBrief(base, false, line).includes("改 app.js"), "离线时 agent 那行被吞了");
  // 怎么才会红：把 `const tail = agentLine ? … : ""` 写成 `const tail = ""`。
  // ⚠️ 这条断言是**必要的**：`agentPromptLine` 自己那几条测试只证明"那行拼对了"，
  //    证明不了"它被接进简报里了"。**模块对了、只是没人用它** ——
  //    这个家族在这个项目里已经出现过三次（色温、表面处理、coerceMood）。
});

Deno.test("命令白名单：只放行表里的，且表本身没有重复", () => {
  for (const c of DEVICE_COMMANDS) assert.ok(isValidCommand(c), `${c} 不在自己的表里`);
  assert.ok(!isValidCommand("MODE NOW"), "自由文本命令被放行了");
  assert.ok(!isValidCommand("haptic:tick "), "带尾空格的命令被放行了");
  assert.equal(new Set(DEVICE_COMMANDS).size, DEVICE_COMMANDS.length, "白名单里有重复项");
  // 怎么才会红：把 isValidCommand 改成 `return true`。
  // ⚠️ 注意 index.html 里的模式按钮发的是 `MODE <id>`，**不在**这张表里 ——
  // 那是两个不同的东西（一个是模式切换，一个是设备动作）。见 server_test 里那条。
});
