/**
 * GrooveD Companion —— Mac 侧服务。
 *
 * 为什么是 deno：本机 **没有** node / bun / npm（实测），deno 2.7.11 是唯一装好的 JS/TS 运行时，
 * 而它自带 HTTP / WebSocket / 文件 / UDP，整条链路**零依赖**。
 * 这不是偏好，是在这台机器上能跑起来的唯一选择。
 *
 * 三条通道：
 *   1. 设备 → 主机：UDP 收 `STATE|…` 行（固件侧只要 sendto，比 TCP 少一次握手）
 *   2. 主机 → 手机：WebSocket 广播状态（Fold7 内屏遥控器）
 *   3. 主机 → DeepSeek：HTTP（聊天 / 情绪），key 从环境或本地文件读，**不写进仓库**
 *
 * 启动：`deno task dev`  → http://127.0.0.1:8765
 */

import {
  isValidCommand,
  modeTable,
  parseState,
  PROTOCOL_VERSION,
  stateBrief,
  type DeviceState,
} from "./protocol.ts";
import {
  chatOnce,
  chatStream,
  chatSystemPrompt,
  coerceMood,
  type ChatMessage,
  MOOD_SYSTEM,
  moodRequest,
} from "./ai.ts";
import { agentPromptLine, type AgentSession } from "./features/agents.ts";
import { createFeatures, type Feature } from "./features/index.ts";
import { loadKey } from "./key.ts";

const PORT = Number(Deno.env.get("GROOVED_PORT") ?? 8765);
// 默认只监听回环（手机用 adb reverse）。Wi-Fi 直连时设 GROOVED_HOST=0.0.0.0。
const HOST = Deno.env.get("GROOVED_HOST") ?? "127.0.0.1";
const UDP_PORT = Number(Deno.env.get("GROOVED_UDP_PORT") ?? 41234);

/** Mac 的局域网 IPv4：手表广播 `GROOVED?` 时回给它，省掉手工发地址。 */
function lanIp(): string {
  try {
    for (const a of Deno.networkInterfaces()) {
      const fam = String(a.family);
      if ((fam === "IPv4" || fam === "4") &&
          !a.address.startsWith("127.") && !a.address.startsWith("169.254.")) {
        return a.address;
      }
    }
  } catch { /* 没有网络接口就返回空 */ }
  return "";
}
const PUBLIC_DIR = new URL("./public/", import.meta.url);

/* ────────────────────────── key 装载 ────────────────────────── */

/**
 * 为什么要三级回退：开发时用环境变量最顺手，但**一键启动**（双击脚本）
 * 拿不到 shell 的 env —— 那时得有文件兜底。任一处有 key 就算成功。
 */
/* ────────────────────────── 设备状态 ────────────────────────── */

/**
 * 设备可能**根本没连上**（Mac 只连着 Wi-Fi、或者线拔了）。
 * 那也必须有值可发 —— 手机端显示"设备离线"靠的是 `online` 这个字段，
 * 而不是"收不到消息就不更新"（后者会让画面永远停在最后一帧，看不出掉线）。
 */
let lastState: DeviceState = {
  version: PROTOCOL_VERSION,
  clock: "--:--",
  mode: "NOW",
  focus: false,
  level: 0,
  bpm: 0,
  battery: 0,
  charging: false,
  stems: 0,
};
let lastSeen = 0;
const OFFLINE_MS = 4000;

const sockets = new Set<WebSocket>();

function isOnline(): boolean {
  return Date.now() - lastSeen < OFFLINE_MS;
}

function snapshot(): string {
  // ⚠️ 这里**不再**把离线时的 `level` 清成 0。
  // 从前是清的，理由（别让环形继续跳）是对的，但**客户端已经做了**这件事
  // （index.html 的 `ring.target = live ? level : 0`），服务端再清一次只是
  // 把"最后一次收到的电平"这个信息抹掉 —— 而清掉的只有 level 一项，
  // bpm / 电量 / 轨数原样发出去，于是手机上是
  // 「设备离线 · BPM 104 · 4 轨 STEM」这种**一半活的读数**。
  // 读数是否算数由 `online` 一个字段说清楚，数值一律如实转发（见 apply() 的 stale 处理）。
  return JSON.stringify({
    online: isOnline(),
    state: lastState,
    // 每个功能自己那一份，键就是它的 id —— 前端按同一张表取。
    features: Object.fromEntries(features.map((f) => [f.id, f.snapshot()])),
  });
}

function broadcast(): void {
  const msg = snapshot();
  for (const ws of sockets) {
    if (ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(msg);
      } catch {
        sockets.delete(ws); // 死连接留在集合里会让每次广播都抛一次。
      }
    }
  }
}

/* 响应助手。
   ⚠️ 它必须排在**用到它的地方之前**。第一版排在文件末尾，
   而功能注册表在文件中间就引用了它 ⇒ `TS2448: Block-scoped variable 'json'
   used before its declaration`。**和我刚在手机页面上修的那个 TDZ 是同一个形状** ——
   `const` 不 hoist，而"函数在下面、被上面调用"在 JS 里太自然了，容易漏。 */
/** ⚠️ CORS 全开，是因为 Android 的 WebView 从 `file://` 打开页面时
 *  origin 是 **null**，fetch 到 127.0.0.1 会被拦；而这一层只监听回环，
 *  能访问到它的本来就只有本机进程。 */
const CORS_HEADERS = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "content-type",
  "access-control-allow-methods": "GET,POST,OPTIONS",
};

const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...CORS_HEADERS },
  });

/* ────────────────────────── 功能注册表 ────────────────────────── */

/**
 * 服务端**不认识任何一个具体功能**：它只知道有一串 Feature，
 * 每 2 秒 tick 一次、变了才广播、路由按 `/api/<id><sub>` 挂。
 *
 * ⚠️ 2 秒这个节奏是**所有功能共用的**。单个功能如果需要更快的节奏
 * （比如 MIDI 的 clock），**不要**在这里加第二个定时器 —— 见 features/midi.ts
 * 的注释：那种东西该在它自己的进程里跑，而不是搭在这里的顺风车上。
 */
const features: Feature[] = createFeatures();
const featureCtx = {
  device: () => ({ online: isOnline(), state: lastState }),
  broadcast: () => broadcast(),
  watchers: () => sockets.size + (isOnline() ? 1 : 0),
  json,
};

/** 从注册表里找某个功能的 snapshot（找不到给 null，不抛）。 */
function featureSnap(id: string): unknown {
  return features.find((f) => f.id === id)?.snapshot() ?? null;
}

/**
 * 从注册表里把 agent 会话取出来给提示词用。
 *
 * ⚠️ 这里**是**服务端对某个具体功能的一点了解，我不装作没有。
 * 但它是**只读、可选**的：拿不到就返回 `[]`（= 提示词里不提 agent），
 * 不会因为 agent 功能不在或崩了而影响聊天。为了这点耦合去加一层
 * "通用取数接口"是过度设计 —— 需要的时候再抽。
 */
function agentsOf(list: Feature[]): AgentSession[] {
  const snap = list.find((f) => f.id === "agents")?.snapshot() as { list?: AgentSession[] } | null;
  return snap?.list ?? [];
}

function featureTick(): void {
  let changed = false;
  for (const f of features) {
    const before = f.rev();
    try {
      f.tick?.(featureCtx);
    } catch (e) {
      // ⚠️ 一个功能抛异常**不许**拖死别的功能，也不许拖死整个 tick 循环。
      console.error(`[feature:${f.id}] tick 抛了：${e instanceof Error ? e.message : e}`);
    }
    if (f.rev() !== before) changed = true;
  }
  if (changed) broadcast();
}
setInterval(featureTick, 2000);
featureTick();

/* ────────────────────────── UDP ← 设备 ────────────────────────── */

async function udpLoop(): Promise<void> {
  let sock: Deno.DatagramConn;
  try {
    sock = Deno.listenDatagram({ port: UDP_PORT, transport: "udp", hostname: "0.0.0.0" });
  } catch (e) {
    const why = e instanceof Error ? e.message : String(e);
    // Deno 2.x 把 listenDatagram 挪到了 --unstable-net 后面；报这个错时别去改代码，改启动参数。
    const hint = typeof (Deno as { listenDatagram?: unknown }).listenDatagram !== "function"
      ? "（Deno.listenDatagram 在本版本需要 --unstable-net，检查 deno.json 的 dev 任务）"
      : "";
    console.error(`[udp] 绑定 ${UDP_PORT} 失败：${why}${hint}`);
    return;
  }
  console.log(`[udp] 等设备上报 STATE|…  ← 0.0.0.0:${UDP_PORT}`);
  const buf = new Uint8Array(2048);
  for (;;) {
    try {
      const [data, addr] = await sock.receive(buf);
      // 一包里可能粘了多行 —— 按行切，别假设"一包 = 一行"。
      for (const line of new TextDecoder().decode(data).split("\n")) {
        if (line.trim() === "GROOVED?") {
          const ip = lanIp();
          if (ip) {
            // 手表在 Wi-Fi 下自动找 Mac：广播一句，这边回 IP。
            await sock.send(new TextEncoder().encode(`GROOVED ${ip} ${PORT}\n`), addr);
          }
          continue;
        }
        const st = parseState(line);
        if (st) {
          lastState = st;
          lastSeen = Date.now();
          broadcast();
        }
      }
    } catch (e) {
      console.error(`[udp] ${e instanceof Error ? e.message : e}`);
    }
  }
}

/* ────────────────────────── SSE → 手机 ────────────────────────── */

async function chatRoute(req: Request): Promise<Response> {
  const key = await loadKey();
  if (!key) {
    return json({ error: "no_key", hint: "设 DEEPSEEK_API_KEY，或写 ~/.grooved/llm.key" }, 503);
  }
  const body = await req.json().catch(() => null) as { messages?: ChatMessage[] } | null;
  if (!body?.messages?.length) return json({ error: "empty_messages" }, 400);

  // 把**真实**状态拼进 system —— 少了这一句，模型会照着 PET_SYSTEM 里那句
  // 「你看得到设备状态」自由发挥（实测它会给出一段并不存在的节拍）。
  const msgs: ChatMessage[] = [
    { role: "system", content: chatSystemPrompt(stateBrief(lastState, isOnline(), agentPromptLine(agentsOf(features)))) },
    ...body.messages,
  ];
  const enc = new TextEncoder();

  const stream = new ReadableStream({
    async start(ctrl) {
      try {
        for await (const delta of chatStream(msgs, { apiKey: key })) {
          // 手动包一层 SSE：上游的 data: 行里可能带换行，直接转发会把帧边界弄坏。
          ctrl.enqueue(enc.encode(`data: ${JSON.stringify({ delta })}\n\n`));
        }
        ctrl.enqueue(enc.encode("data: [DONE]\n\n"));
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        ctrl.enqueue(enc.encode(`data: ${JSON.stringify({ error: msg })}\n\n`));
      } finally {
        ctrl.close();
      }
    },
  });
  return new Response(stream, {
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache",
      connection: "keep-alive",
    },
  });
}

/**
 * 矿灵此刻"怎么动" —— 一次独立的调用，只吐严格 JSON。
 *
 * 为什么不复用 /api/chat 的正文：聊天正文要的是像人话（`PET_SYSTEM` 明说了
 * "说话短，像朋友"），而这里要的是**能直接 clamp 的结构**。混在一起时
 * 模型会把 JSON 揉进句子里，前端就得拿正则去捞 —— 那正是这条链路原来的写法，
 * 实测捞不到（见 index.html 的注释）。分开之后两边各自简单。
 */
async function moodRoute(req: Request): Promise<Response> {
  const key = await loadKey();
  if (!key) {
    return json({ error: "no_key", hint: "设 DEEPSEEK_API_KEY，或写 ~/.grooved/llm.key" }, 503);
  }
  const brief = stateBrief(lastState, isOnline(), agentPromptLine(agentsOf(features)));
  try {
    const raw = await chatOnce(
      [{ role: "system", content: MOOD_SYSTEM }, { role: "user", content: moodRequest(brief) }],
      { apiKey: key, temperature: 0.6, maxTokens: 120 },
    );
    // 解析不了就退回中性值（coerceMood 不抛）—— 宠物动得平淡好过整个请求 500。
    return json({ ...coerceMood(raw), online: isOnline() });
  } catch (e) {
    // 上游挂了要说清是哪一层挂了：401/429/超时的处理方式完全不同。
    return json({ error: "llm_failed", detail: e instanceof Error ? e.message : String(e) }, 502);
  }
}

/* ────────────────────────── 静态文件 ────────────────────────── */

const MIME: Record<string, string> = {
  html: "text/html; charset=utf-8",
  js: "text/javascript; charset=utf-8",
  css: "text/css; charset=utf-8",
  png: "image/png",
  // ⚠️ webp 一度漏在这张表里 —— 矿灵球的资产全是 .webp，会以
  // application/octet-stream 发出去。多数浏览器靠嗅探仍然能画，所以**看不出来**，
  // 但这是"能用的运气"，不是契约。
  webp: "image/webp",
  svg: "image/svg+xml",
  json: "application/json; charset=utf-8",
};

/**
 * `index.html` 里的占位符 —— 服务端把模式表注进去。
 *
 * 为什么不是让前端 `fetch('/api/modes')`：那样页面在拿到表之前是空的一栏
 * （多一次往返，且失败时按钮全没了）。注进去则一次到达，而且
 * **前端从此没有机会再抄一份**（这才是这个占位符真正防的东西）。
 */
export const MODES_PLACEHOLDER = "/*__MODES__*/[]";
/** 功能清单也注进去 —— 前端**不许**再抄一份（和模式表同一个理由）。 */
export const FEATURES_PLACEHOLDER = "/*__FEATURES__*/[]";

async function serveStatic(path: string): Promise<Response> {
  const clean = path.replace(/^\/+/, "") || "index.html";
  if (clean.includes("..")) return new Response("bad path", { status: 400 });
  try {
    let file: Uint8Array | string = await Deno.readFile(new URL(clean, PUBLIC_DIR));
    if (clean === "index.html") {
      const html = new TextDecoder().decode(file);
      if (!html.includes(MODES_PLACEHOLDER)) {
        // 占位符没了 = 注入静默失效 = 前端会退回空数组，页面上一个模式按钮都没有。
        // 与其让它悄悄坏，不如当场喊出来。
        console.error(`[static] ⚠️ index.html 里找不到 ${MODES_PLACEHOLDER}，模式表没能注入`);
      }
      file = html.replace(MODES_PLACEHOLDER, JSON.stringify(modeTable()));
      const feat = features.map((f) => ({ id: f.id, title: f.title }));
      file = (file as string).replace(FEATURES_PLACEHOLDER, JSON.stringify(feat));
    }
    const ext = clean.split(".").pop() ?? "";
    return new Response(file as BodyInit, {
      headers: { "content-type": MIME[ext] ?? "application/octet-stream", "cache-control": "no-store" },
    });
  } catch {
    return new Response("not found", { status: 404 });
  }
}


/* ────────────────────────── 路由 ────────────────────────── */

function handler(req: Request): Response | Promise<Response> {
  const url = new URL(req.url);

  // 预检 + 跨域（Android WebView 的 file:// 页面会先发 OPTIONS）
  if (req.method === "OPTIONS" && url.pathname.startsWith("/api/")) {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  if (url.pathname === "/api/state") {
    if (req.headers.get("upgrade") !== "websocket") return json({ error: "need_websocket" }, 426);
    const { socket, response } = Deno.upgradeWebSocket(req);
    socket.onopen = () => {
      sockets.add(socket);
      socket.send(snapshot()); // 立刻补一帧：否则新开的页面要等下一次广播才亮。
    };
    socket.onclose = () => sockets.delete(socket);
    socket.onerror = () => sockets.delete(socket);
    return response;
  }

  if (url.pathname === "/api/chat" && req.method === "POST") return chatRoute(req);
  if (url.pathname === "/api/mood" && req.method === "POST") return moodRoute(req);
  // 模式表也留一个 JSON 口：设备固件那边（ESP32）不需要解析 HTML 就能拿到同一份表。
  if (url.pathname === "/api/modes") return json({ modes: modeTable() });
  // Mac 上正在跑哪些 agent。`rev` 变了就是"有新消息" —— 测试用它做判据，
  // 比"看时间戳"稳（时间戳在两次读之间总会变）。
  // 功能清单：手机/设备从**这一份**建自己的入口，而不是各写一张表。
  if (url.pathname === "/api/features") {
    return json({
      features: features.map((f) => ({
        id: f.id,
        title: f.title,
        routes: Object.keys(f.routes),
        status: f.status?.() ?? "",
      })),
    });
  }

  /* ── 给手表换 Wi-Fi（无需数据线）──
   * 网页 POST /api/device/wifi → 存 pending；
   * 手表 GET /api/device/pending → 取走一行 `WIFICFG ssid|pass`（取走即清空）。 */
  if (url.pathname === "/api/device/wifi" && req.method === "POST") {
    return (async () => {
      const b = await req.json().catch(() => null) as { ssid?: string; password?: string } | null;
      const ssid = (b?.ssid ?? "").trim();
      if (!ssid) return json({ error: "no_ssid" }, 400);
      pendingWifi = { ssid, password: b?.password ?? "" };
      return json({ ok: true, queued: true });
    })();
  }
  if (url.pathname === "/api/device/pending") {
    if (!pendingWifi) {
      return new Response("", {
        status: 200,
        headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" },
      });
    }
    const { ssid, password } = pendingWifi;
    // 诊断用：peek=1 只看不取，免得排障时把命令自己吃掉。
    if (url.searchParams.get("peek") !== "1") pendingWifi = null;
    // 固件按第一个 `|` 切；SSID/密码里真有 `|` 就换成空格（极罕见）。
    const line = `WIFICFG ${ssid.replace(/\|/g, " ")}|${password.replace(/\|/g, " ")}\n`;
    return new Response(line, {
      status: 200,
      headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" },
    });
  }

  /**
   * 功能自己的路由：`/api/<id><sub>`。
   *
   * ⚠️ 这一段**排在 /api/chat、/api/mood、/api/modes 之后**，不是随便放的 ——
   * 它是个通配的 `/api/<一段>`，放前面会把那几个具体的接口一起吃掉，
   * 而症状是"聊天突然 404 了"，看起来和功能拆分毫无关系。
   */
  const fm = url.pathname.match(/^\/api\/([a-z]+)(\/.*)?$/);
  if (fm) {
    const f = features.find((x) => x.id === fm[1]);
    if (f) {
      const sub = fm[2] ?? "";
      const h = f.routes[sub];
      if (!h) return json({ error: "no_route", id: f.id, sub, have: Object.keys(f.routes) }, 404);
      try {
        const out = h(req, featureCtx);
        // ⚠️ 异步处理器抛出来的是 **rejected promise**，不是同步异常 ——
        // try/catch 抓不到它。不接这一手的话，一个功能的 bug 会变成
        // Deno 的默认 500，而**别的一切看起来都正常**，很难定位到是哪个功能。
        if (out instanceof Promise) {
          return out.catch((e) =>
            json({ error: "feature_failed", id: f.id, sub, detail: e instanceof Error ? e.message : String(e) }, 500)
          );
        }
        return out;
      } catch (e) {
        return json({ error: "feature_failed", id: f.id, sub, detail: e instanceof Error ? e.message : String(e) }, 500);
      }
    }
  }

  if (url.pathname === "/api/device" && req.method === "POST") {
    return (async () => {
      const b = await req.json().catch(() => null) as { cmd?: string } | null;
      if (!b?.cmd) return json({ error: "no_cmd" }, 400);
      if (!isValidCommand(b.cmd)) return json({ error: "bad_cmd", cmd: b.cmd }, 400);
      // 真机通道（UDP 下行 / 串口）还没接 —— 现在**必须如实说没送到**，
      // 谎报 ok 会让手机上的按钮看起来能用，而圆屏毫无反应，比报错难查得多。
      return json({ accepted: b.cmd, delivered: false, reason: "device_downlink_not_wired" }, 202);
    })();
  }

  return serveStatic(url.pathname);
}

/* 给手表排队的 Wi-Fi 配置：网页填 SSID/密码 → 存这里 → 手表下次轮询取走。
 * ⚠️ 一次只保留一条，**取走即清空**：手表没收到就再点一次发送（别让它每 2 秒重配一次）。 */
let pendingWifi: { ssid: string; password: string } | null = null;

// /health 要能反映 key 是否就绪（本机排查 90% 的问题都是"没 key"），
// 但 loadKey 是异步的、不能在模块顶层 await 完再起服务 —— 于是缓存成一个布尔。
let keyReady = false;
loadKey().then((k) => {
  keyReady = k !== null;
  console.log(k ? "[llm] key 已装载" : "[llm] ⚠️ 没有 key：/api/chat 会返回 503");
});

Deno.serve({ port: PORT, hostname: HOST }, (req) => {
  const url = new URL(req.url);
  if (url.pathname === "/health") {
    const age = lastSeen ? Date.now() - lastSeen : -1;
    return json({
      ok: true,
      protocol: PROTOCOL_VERSION,
      device_online: age >= 0 && age < OFFLINE_MS,
      last_seen_ms_ago: age,
      sockets: sockets.size,
      key_loaded: keyReady,
    });
  }
  return handler(req);
});

console.log(`[http] http://${HOST}:${PORT}  ← 手机用 adb reverse tcp:${PORT} tcp:${PORT}`);
udpLoop();
