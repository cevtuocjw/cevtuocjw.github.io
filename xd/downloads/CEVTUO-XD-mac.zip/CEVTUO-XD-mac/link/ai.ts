/**
 * DeepSeek（OpenAI 兼容端点）客户端 —— 零依赖，只用 fetch。
 *
 * 为什么不引 SDK：GrooveD 的链路会在「Mac 无网 / 只连设备热点」时工作，
 * 依赖树越薄，掉线和失败原因就越少归因层级。
 *
 * ⚠️ 模型名由**账户**决定路由，不由我们决定：实测 `deepseek-chat` 会回 `deepseek-flash`。
 *    所以别把模型名当作能力声明去用（见 link/ai_test.ts 的实测断言）。
 */

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ChatOpts {
  apiKey: string;
  baseUrl?: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
  signal?: AbortSignal;
}

export const DEFAULT_BASE = "https://api.deepseek.com";
export const DEFAULT_MODEL = "deepseek-chat";

/** 矿灵人格 —— GrooveD 的宠物不是装饰，它得知道自己在看一台正在出声的机器。 */
export const PET_SYSTEM = `你是「矿灵」，住在 GrooveD 里的一只矿物生物：银灰的晶体身体，内部有缓慢流动的冷光。

你陪着用户做音乐、练琴、专注。规则：
1. 说话短，像朋友，不像客服。一次最多两句。
2. 你看得到设备状态（节拍、电平、电量、模式），该用时才用，别报菜名。
3. 不吹捧，不说"太棒了"这种空话；要夸就夸具体的一件事。
4. 不懂就说不懂。不要编造用户没告诉你的信息。
5. 中文回答。`;

/**
 * 拼发给矿灵的 system prompt。
 *
 * 单独抽出来，只为了**能被断言**：之前这段是写在 `chatRoute` 里的字符串拼接，
 * 而 `chatRoute` 要起服务、要真的调一次模型才跑得到 —— 于是"状态到底有没有
 * 进 prompt"这件事只能靠肉眼看代码。现在它是个纯函数，`ai_test.ts` 盯得住。
 *
 * ⚠️ 这条正是本项目踩过的那类坑：`PET_SYSTEM` 里写着「你看得到设备状态」，
 * 而状态从来没被拼进来过。**每一个字都对，接起来是错的。**
 */
export function chatSystemPrompt(brief: string): string {
  return `${PET_SYSTEM}\n\n${brief}`;
}

export async function chatOnce(messages: ChatMessage[], o: ChatOpts): Promise<string> {
  const base = o.baseUrl ?? DEFAULT_BASE;
  const res = await fetch(`${base}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${o.apiKey}`,
    },
    signal: o.signal,
    body: JSON.stringify({
      model: o.model ?? DEFAULT_MODEL,
      messages,
      temperature: o.temperature ?? 0.8,
      max_tokens: o.maxTokens ?? 400,
      stream: false,
    }),
  });
  if (!res.ok) {
    // 把状态码和正文都带出去 —— 401 和 429 的处理方式完全不同，不能都叫"AI 失败"。
    const body = await res.text().catch(() => "");
    throw new Error(`LLM ${res.status}: ${body.slice(0, 300)}`);
  }
  const json = await res.json();
  return json?.choices?.[0]?.message?.content ?? "";
}

/** 流式：设备侧 UI 要的是"字一个个出来"，不是等完整段。 */
export async function* chatStream(
  messages: ChatMessage[],
  o: ChatOpts,
): AsyncGenerator<string> {
  const base = o.baseUrl ?? DEFAULT_BASE;
  const res = await fetch(`${base}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${o.apiKey}`,
    },
    signal: o.signal,
    body: JSON.stringify({
      model: o.model ?? DEFAULT_MODEL,
      messages,
      temperature: o.temperature ?? 0.8,
      max_tokens: o.maxTokens ?? 400,
      stream: true,
    }),
  });
  if (!res.ok || !res.body) {
    const body = await res.text().catch(() => "");
    throw new Error(`LLM ${res.status}: ${body.slice(0, 300)}`);
  }
  const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += value;
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const raw of lines) {
      const line = raw.trim();
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (payload === "[DONE]") return;
      try {
        const delta = JSON.parse(payload)?.choices?.[0]?.delta?.content;
        if (delta) yield delta;
      } catch {
        // 半行是常态（SSE 不保证按 JSON 边界切），丢弃即可 —— 不要在这里报错打断整段回复。
      }
    }
  }
}

/**
 * 让矿灵把"当前状态"翻译成设备能画的东西。
 *
 * 为什么走一次额外调用而不是让主对话顺带吐：主对话的 token 预算花在说话上，
 * 这个要的是**严格可解析**且要能被 clamp。两者混在一起会互相拖累。
 *
 * ⚠️ **这里没有 `hue`。** 设计文档 §1.1/§2.2 定死了「全屏只允许一个强调色，
 * 它的色相由**模式**决定」。曾经这里有一个模型自选的 `hue` 字段，
 * 那等于请模型来挑第二个强调色 —— 正是"看着廉价"的那个失败模式。
 * 色相请走 `protocol.ts` 的 `MODE_HUE`。
 */
export interface Mood {
  mood: "calm" | "focus" | "hype" | "sleepy" | "curious";
  motion: "still" | "breathe" | "pulse" | "spin";
  line: string;
}

export const MOODS = ["calm", "focus", "hype", "sleepy", "curious"] as const;
export const MOTIONS = ["still", "breathe", "pulse", "spin"] as const;
/** 圆屏那一句话的上限：超过这个长度在 466 圆屏上会换行到第三行，压住巨型数字。 */
export const LINE_MAX = 14;

export const MOOD_SYSTEM = `你在给一个圆屏挂件生成"怎么动"的指令。只输出一个 JSON 对象，不要 markdown 代码块，不要解释。

字段：
- mood: ${MOODS.join(" | ")} 之一
- motion: ${MOTIONS.join(" | ")} 之一（still=几乎静止 / breathe=缓慢呼吸 / pulse=随电平或心跳脉动 / spin=缓慢自转）
- line: 一句中文，**最多 ${LINE_MAX} 个字**，是矿灵此刻想说的话。不要标点堆叠，不要引号。

只输出 JSON。`;

export function moodRequest(stateText: string): string {
  return `${stateText}\n\n据此给出 JSON。`;
}

/**
 * 把模型吐的东西夹逼成合法值。
 *
 * ⚠️ 一律**不抛异常**：这里每天都在跑，而模型偶尔会多写一句"好的，这是结果"。
 * 解析不了就退回中性值 —— 让宠物动得平淡，好过让整个请求 500。
 */
export function coerceMood(raw: string): Mood {
  const fallback: Mood = { mood: "curious", motion: "breathe", line: "" };
  const m = raw.match(/\{[\s\S]*\}/);
  if (!m) return fallback;
  let obj: Record<string, unknown>;
  try {
    obj = JSON.parse(m[0]);
  } catch {
    return fallback;
  }
  const mood = MOODS.includes(String(obj.mood) as Mood["mood"])
    ? (obj.mood as Mood["mood"])
    : fallback.mood;
  const motion = MOTIONS.includes(String(obj.motion) as Mood["motion"])
    ? (obj.motion as Mood["motion"])
    : fallback.motion;
  // 长度按**字符**算（[…str] 走码点，中文一个字一个元素），
  // 直接用 slice 会把 emoji 从代理对中间切断，切出半个字符。
  const line = [...String(obj.line ?? "")].slice(0, LINE_MAX).join("").replace(/[\r\n]+/g, " ");
  return { mood, motion, line };
}
