/**
 * GrooveD 设备 ↔ 主机 协议。
 *
 * 为什么沿用「行式 + 竖线分隔」而不是 JSON：设备侧每帧都要跑电平/节拍，
 * ESP32-S3 上 strtok 比 JSON 解析便宜一个数量级，而这条流是 25~60Hz 的常驻流。
 * 上游 ochyai 模拟器 v2 已经证明这套能跑，GrooveD 只**加**音频相关字段。
 *
 * ⚠️ 版本号只在上游真的读不懂时 +1；设备会带版本号上报，主机用它决定怎么解。
 */

export const PROTOCOL_VERSION = 3;
export const FIELD_MAX = 96;

/** 设备屏幕是圆屏 466×466，模式卡的文案必须能塞进这一格。 */
export const MODES = ["NOW", "BUILD", "READ", "MEET", "PRESENT", "REST"] as const;
export type Mode = (typeof MODES)[number];

/**
 * 模式 → 色相 / 中文名 / 矿物，**这里是唯一真源**。
 *
 * 为什么强调"唯一"：这张表曾经在三个地方各写了一份（`index.html` 的 JS 数组、
 * 设计文档 §2.2 的表、以及这里的 MODES）。三份手抄的表不会同时更新 ——
 * 症状是「页面上的色相和文档里写的不一样」，而两边单独看都正常。
 * 现在 `index.html` 不再自己声明，由服务端在返回 HTML 时把这段 JSON 注进去
 * （见 server.ts 的 `MODES_PLACEHOLDER`）。改色相只改这一个文件。
 *
 * 色相为什么按模式定而不是按情绪定：设计文档 §1.1/§2.2 定的规矩是
 * 「全屏只允许一个强调色，它的色相由状态决定」—— 廉价感的来源是
 * 两个饱和度相近的强调色并存，所以不给情绪留第二个色相。
 */
export const MODE_HUE: Record<Mode, string> = {
  NOW: "#35E0D0",
  BUILD: "#FFB020",
  READ: "#A78BFA",
  MEET: "#4C8DFF",
  PRESENT: "#FF4D9D",
  REST: "#6E7BFF",
};

export const MODE_LABEL: Record<Mode, string> = {
  NOW: "专注",
  BUILD: "构建",
  READ: "阅读",
  MEET: "会议",
  PRESENT: "呈现",
  REST: "休息",
};

/** 模式配哪只矿物球 —— 三种真资产（银/铅/锌）在 `link/public/pet/`。 */
export const MODE_PET: Record<Mode, "silver" | "lead" | "zinc"> = {
  NOW: "silver",
  BUILD: "zinc",
  READ: "lead",
  MEET: "silver",
  PRESENT: "zinc",
  REST: "lead",
};

/** 给前端用的那一份形状（客户端的按钮、配色、球都从它读）。 */
export function modeTable(): { id: Mode; label: string; hue: string; pet: string }[] {
  return MODES.map((id) => ({ id, label: MODE_LABEL[id], hue: MODE_HUE[id], pet: MODE_PET[id] }));
}

export interface DeviceState {
  version: number;
  /** 设备本地时钟 HH:MM —— 为什么不是时间戳：设备可能没拿到 RTC/NTP，主机不该假定时区。 */
  clock: string;
  mode: Mode;
  focus: boolean;
  /** 0.0~1.0，麦克风短时能量；宠物和径向环都靠它。 */
  level: number;
  /** 0 表示还没测到；主机不做 BPM 猜测，避免"看起来在工作"。 */
  bpm: number;
  battery: number;
  charging: boolean;
  /** 当前正在拆/播的轨数；0 表示纯设备模式。 */
  stems: number;
}

const clamp01 = (n: number) => (n < 0 ? 0 : n > 1 ? 1 : n);

function clean(v: string): string {
  // 竖线是分隔符，换行是记录分隔符 —— 两者都必须从字段里剔掉，否则一个曲名就能把协议撕开。
  return v.replace(/[|\r\n]/g, " ").slice(0, FIELD_MAX).trim();
}

export function formatState(s: DeviceState): string {
  return (
    [
      `STATE`,
      `${PROTOCOL_VERSION}`,
      clean(s.clock),
      s.mode,
      s.focus ? "1" : "0",
      clamp01(s.level).toFixed(3),
      String(Math.max(0, Math.round(s.bpm))),
      String(Math.round(s.battery)),
      s.charging ? "1" : "0",
      String(Math.max(0, Math.min(8, Math.round(s.stems)))),
    ].join("|") + "\n"
  );
}

/**
 * 解析一行设备上报。
 *
 * ⚠️ **两个失败档位是故意分开的，不是漏写**：
 *
 * | 坏在哪 | 结果 | 为什么 |
 * |---|---|---|
 * | 段数 / 版本 / 模式名 | 整条 `null` | 这三样是**结构**。错了说明我们和对面说的不是同一门语言，后面每一段的位置都不可信。 |
 * | 数值字段（level/bpm/…）| 退回 `0`，记录仍然有效 | 一个电平写坏了只是"环不动"；整条丢掉是设备从页面上**整个消失**、顶栏写「设备离线」。用一个字段的错去惩罚另外八个，代价更大。 |
 *
 * 这条曾经只是"顺手这么写的"，直到 `protocol_test.ts` 把 `STATE|…|abc|…` 喂进来才发现
 * 它是一条**没人写下来的决定**。现在它写在测试里，也写在这里。
 */
export function parseState(line: string): DeviceState | null {
  const parts = line.trim().split("|");
  if (parts.length !== 10 || parts[0] !== "STATE") return null;
  const version = Number(parts[1]);
  if (!Number.isFinite(version) || version !== PROTOCOL_VERSION) return null;
  const mode = parts[3] as Mode;
  if (!MODES.includes(mode)) return null;
  return {
    version,
    clock: parts[2],
    mode,
    focus: parts[4] === "1",
    level: clamp01(Number(parts[5]) || 0),
    bpm: Number(parts[6]) || 0,
    battery: Number(parts[7]) || 0,
    charging: parts[8] === "1",
    stems: Number(parts[9]) || 0,
  };
}

/**
 * 把设备状态写成给模型看的一句话。
 *
 * 为什么必须有这个：`PET_SYSTEM` 里写着「你看得到设备状态」，
 * 而 server.ts 从前**从没把状态传进去** —— 于是模型只能编。
 * 实测（设备离线、bpm=0）它开口就是「节拍器停在 92」，
 * 听起来非常像真的。**告诉模型它有某种能力，却不给它数据，比不告诉它更糟。**
 *
 * ⚠️ 措辞上要挡住"没有数据"和"数据是 0"的混淆：没上报时说的是「还没收到」，
 * 而不是「电平 0.00」—— 后者会让模型一本正经地描述一段并不存在的安静。
 */
export function stateBrief(s: DeviceState, online: boolean, agentLine = ""): string {
  // ⚠️ agentLine 是自己一段，**不并进上面那句"只能依据上面这些"**。
  // 设备读数走 `|` 分隔的行式协议（所以那边是一个字段都不能错），
  // 而 agent 那一行是自由文本、来自另一个进程（CrewTower），
  // 把它塞进同一个句子会让"读数"和"别人的汇报"在提示词里混成一件事。
  const tail = agentLine ? `\n${agentLine}` : "";
  if (!online) {
    return "当前设备状态：**离线**（没收到上报）。不要描述节拍、电平、电量，也不要猜 —— 直接说联系不上设备。" +
      tail;
  }
  return [
    "当前设备状态：",
    `模式 ${s.mode}（${MODE_LABEL[s.mode]}）`,
    `本地时钟 ${s.clock}`,
    `电平 ${s.level.toFixed(2)}`,
    s.bpm > 0 ? `节拍 ${s.bpm} BPM` : "节拍 还没测到",
    `电量 ${Math.round(s.battery)}%${s.charging ? "（充电中）" : ""}`,
    `拆轨 ${s.stems > 0 ? `${s.stems} 轨` : "无"}`,
    "只能依据上面这些说话；上面没写的，就说不知道。",
  ].join("；") + tail;
}

/** 主机 → 设备。运行时才发现拼错的命令在设备上只会静默丢弃，所以要在这里挡住。 */
export const DEVICE_COMMANDS = [
  "haptic:tick",
  "haptic:metronome:on",
  "haptic:metronome:off",
  "pet:mood:calm",
  "pet:mood:focus",
  "pet:mood:hype",
  "stems:all",
  "stems:solo:0",
  "stems:solo:1",
  "stems:solo:2",
  "stems:solo:3",
  "midi:panic",
] as const;
export type DeviceCommand = (typeof DEVICE_COMMANDS)[number];

export function isValidCommand(cmd: string): cmd is DeviceCommand {
  return (DEVICE_COMMANDS as readonly string[]).includes(cmd);
}
