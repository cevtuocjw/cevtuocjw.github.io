/**
 * 模型输出的夹逼测试。
 *
 * 这一层全部的难度在于：**模型会给出合法的 JSON、合法的字段名、合法的值域之外的值**。
 * coerceMood 的契约是"永远不抛"—— 它每天都在跑，一次 500 会让整页的宠物卡死，
 * 而卡死的表现和"这句话没有语气"一模一样。
 */
import assert from "node:assert/strict";
import {
  chatSystemPrompt,
  coerceMood,
  LINE_MAX,
  MOOD_SYSTEM,
  MOODS,
  MOTIONS,
  moodRequest,
  PET_SYSTEM,
} from "./ai.ts";
import { stateBrief, type DeviceState, PROTOCOL_VERSION } from "./protocol.ts";

Deno.test("system prompt 里**真的**带上了设备状态（这就是那个幻觉 bug 的防线）", () => {
  const dev: DeviceState = {
    version: PROTOCOL_VERSION, clock: "21:04", mode: "BUILD", focus: true,
    level: 0.42, bpm: 104, battery: 88, charging: false, stems: 4,
  };
  const online = chatSystemPrompt(stateBrief(dev, true));
  assert.ok(online.includes(PET_SYSTEM), "人格被拼丢了");
  assert.ok(online.includes("104"), `在线的读数没进 prompt：\n${online}`);
  assert.ok(online.includes("BUILD"));

  const offline = chatSystemPrompt(stateBrief(dev, false));
  assert.ok(offline.includes("离线"));
  assert.ok(!offline.includes("104"), "离线时读数还是漏进去了");

  // 差分：只把 online 一个输入翻转，输出必须跟着变。
  // 怎么才会红：把 chatSystemPrompt 改成 `return PET_SYSTEM;`（= 从前那个 bug 的样子）。
  // ⚠️ 只断言 `includes(PET_SYSTEM)` 是**测不出来**的 —— PET_SYSTEM 本来就总在里面。
  assert.notEqual(online, offline, "换了状态但 prompt 一个字没变 —— 状态多半没拼进去");
  assert.notEqual(chatSystemPrompt(stateBrief({ ...dev, bpm: 90 }, true)), online);
});


Deno.test("正常 JSON 被解析", () => {
  const m = coerceMood('{"mood":"hype","motion":"pulse","line":"来了"}');
  assert.equal(m.mood, "hype");
  assert.equal(m.motion, "pulse");
  assert.equal(m.line, "来了");
  // 怎么才会红：把 coerceMood 改成直接返回 fallback。
  // ⚠️ 光靠"不抛异常"是测不出这个的 —— 一个永远返回 fallback 的实现同样不抛。
});

Deno.test("模型把 JSON 包在话里也能捞出来", () => {
  const m = coerceMood('好的，这是结果：\n```json\n{"mood":"calm","motion":"still","line":"安静"}\n```\n希望有用！');
  assert.equal(m.mood, "calm");
  assert.equal(m.motion, "still");
  // 怎么才会红：把 `raw.match(/\{[\s\S]*\}/)` 换成 `JSON.parse(raw)`。
  // 这不是假想：MOOD_SYSTEM 里写了"不要 markdown 代码块"，而模型**经常还是给**。
});

Deno.test("彻底的垃圾输入 → 中性值，且一个字都不抛", () => {
  for (const junk of ["", "   ", "抱歉，我不能", "{不是 JSON}", "[]", "null"]) {
    const m = coerceMood(junk);
    assert.ok(MOODS.includes(m.mood), `${JSON.stringify(junk)} 给出了非法 mood`);
    assert.ok(MOTIONS.includes(m.motion), `${JSON.stringify(junk)} 给出了非法 motion`);
    assert.equal(typeof m.line, "string");
  }
  // 怎么才会红：把 coerceMood 里的 try/catch 去掉 ⇒ `{不是 JSON}` 会抛。
  // 断言里要求"不抛"的方式就是**直接调用它**：抛了整条测试就红。
});

Deno.test("枚举外的值被夹回默认，而不是原样透传", () => {
  const m = coerceMood('{"mood":"angry","motion":"explode","line":"x"}');
  assert.ok(MOODS.includes(m.mood), `"angry" 穿透了：${m.mood}`);
  assert.ok(MOTIONS.includes(m.motion), `"explode" 穿透了：${m.motion}`);
  // 怎么才会红：把 `MOODS.includes(...)` 的判断换成 `String(obj.mood)`。
  // 为什么必须夹：前端是 `MOTION_CLASS[m.motion] || MOTION_CLASS.breathe`，
  // 一个没见过的 motion 会 **静默退回 breathe** —— 看起来只是"这个动作没生效"。
});

Deno.test("line 按字符截断，不切碎代理对", () => {
  const long = "一二三四五六七八九十甲乙丙丁戊己庚辛";
  const m = coerceMood(JSON.stringify({ mood: "calm", motion: "still", line: long }));
  assert.equal([...m.line].length, LINE_MAX, `截断长度不对：${m.line}`);

  // 全是 emoji：每个字是两个 UTF-16 码元。用 slice 切会切出半个字符（乱码方块）。
  const emoji = "🌑🌒🌓🌔🌕🌖🌗🌘🌑🌒🌓🌔🌕🌖🌗🌘🌑🌒";
  const me = coerceMood(JSON.stringify({ mood: "calm", motion: "still", line: emoji }));
  assert.equal([...me.line].length, LINE_MAX);
  assert.ok(!me.line.includes("�"), "截出了半个字符");
  assert.equal(me.line, [...emoji].slice(0, LINE_MAX).join(""), "emoji 被切碎了");
  // 怎么才会红：把 `[...String(...)].slice(...)` 写成 `String(...).slice(...)`。
});

Deno.test("line 里的换行被压成空格（它要显示在一行上）", () => {
  const m = coerceMood(JSON.stringify({ mood: "calm", motion: "still", line: "上\n下" }));
  assert.ok(!m.line.includes("\n"), "换行漏出来了");
  // 怎么才会红：去掉 `.replace(/[\r\n]+/g, " ")`。
  // 圆屏那一行是固定高度的，一个换行会把巨型数字顶下去。
});

Deno.test("MOOD_SYSTEM 里点名的枚举和代码里的枚举是同一份", () => {
  for (const m of MOODS) assert.ok(MOOD_SYSTEM.includes(m), `提示词里没告诉模型可以用 ${m}`);
  for (const m of MOTIONS) assert.ok(MOOD_SYSTEM.includes(m), `提示词里没告诉模型可以用 ${m}`);
  assert.ok(MOOD_SYSTEM.includes(String(LINE_MAX)), `提示词里没写"最多 ${LINE_MAX} 个字"`);
  // 怎么才会红：往 MOODS 里加一个值而不动提示词。
  // 这是"枚举和提示词两份、迟早漂移"的唯一防线 ——
  // 漂移的症状是模型永远不给那个新值，而**没有任何东西会报错**。
});

Deno.test("moodRequest 真的带上了状态（不然这一步等于白问）", () => {
  const brief = "当前设备状态：模式 NOW（专注）；电平 0.42";
  const q = moodRequest(brief);
  assert.ok(q.includes(brief), "状态没进请求");
  // 怎么才会红：把 moodRequest 改成返回一个常数串。
  // ⚠️ 这一条和 coerceMood 那些是同一个家族：'模块对了、只是没人把输入接上'。
});
