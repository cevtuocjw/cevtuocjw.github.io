/**
 * LLM key 的唯一装载点。
 *
 * 以前这段在 server.ts 里，studio 功能也要用 ⇒ 只能再抄一份。
 * 抄一份的症状是「一处能聊、一处 401」，而且两边都在回 200 —— 所以抽到这里。
 *
 * 三级回退：设置页写进来的 key → 环境变量 → 文件兜底。
 * ⚠️ 从手机设置页写进来的 key 会尝试落到 `~/.grooved/llm.key`；
 *    server 没给 --allow-write 时只留内存（不假装持久化）。
 */
let userKey: string | null = null;
let cached: string | null = null;

export async function loadKey(): Promise<string | null> {
  if (userKey?.startsWith("sk-")) return userKey;
  if (cached?.startsWith("sk-")) return cached;
  const fromEnv = Deno.env.get("DEEPSEEK_API_KEY") ?? Deno.env.get("C4EMEM_LLM_API_KEY");
  if (fromEnv?.startsWith("sk-")) { cached = fromEnv; return cached; }
  const home = Deno.env.get("HOME") ?? "";
  const candidates = [
    `${home}/.grooved/llm.key`,
    `${home}/Documents/Cevtuo-C4emem/.env`,
  ];
  for (const p of candidates) {
    try {
      const txt = await Deno.readTextFile(p);
      const m = txt.match(/(?:DEEPSEEK_API_KEY|C4EMEM_LLM_API_KEY)\s*=\s*"?([^"\s]+)"?/);
      if (m?.[1]?.startsWith("sk-")) { cached = m[1]; return cached; }
    } catch {
      // 文件不存在是正常路径，继续试下一个。
    }
  }
  return null;
}

/** 设置页写进来的 key。空字符串/null = 清除。 */
export function setUserKey(k: string | null): { ok: boolean; persisted: boolean } {
  const clean = (k ?? "").trim();
  userKey = clean.startsWith("sk-") ? clean : null;
  cached = userKey;
  if (!userKey) return { ok: true, persisted: false };
  try {
    const home = Deno.env.get("HOME") ?? "";
    Deno.mkdirSync(`${home}/.grooved`, { recursive: true });
    Deno.writeTextFileSync(`${home}/.grooved/llm.key`, userKey + "\n");
    return { ok: true, persisted: true };
  } catch {
    return { ok: true, persisted: false };
  }
}

export async function keyStatus(): Promise<{ set: boolean; hint: string; source: string }> {
  const k = await loadKey();
  const source = userKey ? "settings" : (Deno.env.get("DEEPSEEK_API_KEY") ? "env" : (k ? "file" : "none"));
  return { set: !!k, hint: k ? "…" + k.slice(-4) : "", source };
}
