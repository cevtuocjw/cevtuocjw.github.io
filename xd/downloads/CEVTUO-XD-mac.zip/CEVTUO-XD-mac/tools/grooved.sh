#!/usr/bin/env bash
# GrooveD Mac 端管理：Mac 服务 + 手表串口桥
#   tools/grooved.sh status
#   tools/grooved.sh start | stop | restart
#   tools/grooved.sh install     # 写 LaunchAgents（登录自启）
#   tools/grooved.sh uninstall
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
UID_N="$(id -u)"
LA="$HOME/Library/LaunchAgents"
LABELS=(com.cevtuo.grooved-link com.cevtuo.grooved-bridge)

status(){
  echo "── GrooveD ──"
  for l in "${LABELS[@]}"; do
    if launchctl print "gui/$UID_N/$l" >/dev/null 2>&1; then
      echo "  $l: loaded"
    else
      echo "  $l: NOT loaded"
    fi
  done
  echo -n "  server: "; pgrep -f "link/server.ts" | head -1 | awk '{print "pid "$1}' || true
  echo -n "  bridge: "; pgrep -f "grooved-serial-midi" | head -1 | awk '{print "pid "$1}' || true
  echo -n "  agents: "
  curl -s --max-time 3 http://127.0.0.1:8765/api/agents/list \
    | python3 -c 'import sys,json; d=json.load(sys.stdin); print("%d sessions / pending %d / err %s" % (len(d.get("list",[])), d.get("pending",0), d.get("err","")))' 2>/dev/null \
    || echo "server not reachable"
}
install(){
  mkdir -p "$LA" "$HOME/Library/Logs"
  # ⚠️ launchd 读 ~/Documents 会被 TCC 卡在 open()（进程活着、端口不 bind）。
  # 把服务复制到 Application Support，launchd 只读这里。
  mkdir -p "$HOME/Library/Application Support/grooved-link"
  rsync -a --delete "$ROOT/link/" "$HOME/Library/Application Support/grooved-link/"
  cp "$ROOT/tools/launchd/com.cevtuo.grooved-link.plist" "$LA/"
  cp "$ROOT/tools/launchd/com.cevtuo.grooved-bridge.plist" "$LA/"
  for l in "${LABELS[@]}"; do
    launchctl bootout "gui/$UID_N/$l" >/dev/null 2>&1 || true
    launchctl bootstrap "gui/$UID_N" "$LA/$l.plist"
  done
  echo "installed; logs: ~/Library/Logs/grooved-*.log"
}
uninstall(){
  for l in "${LABELS[@]}"; do
    launchctl bootout "gui/$UID_N/$l" >/dev/null 2>&1 || true
    rm -f "$LA/$l.plist"
  done
  echo "uninstalled"
}
loaded(){ launchctl print "gui/$UID_N/$1" >/dev/null 2>&1; }
start(){
  mkdir -p "$HOME/Library/Application Support/grooved-link"
  rsync -a --delete "$ROOT/link/" "$HOME/Library/Application Support/grooved-link/"
  for l in "${LABELS[@]}"; do
    if loaded "$l"; then
      launchctl kickstart -k "gui/$UID_N/$l" 2>/dev/null || true
    else
      launchctl bootstrap "gui/$UID_N" "$LA/$l.plist"
    fi
  done
}
stop(){
  for l in "${LABELS[@]}"; do
    launchctl bootout "gui/$UID_N/$l" 2>/dev/null || true
  done
}
case "${1:-status}" in
  status) status ;;
  install) install ;;
  uninstall) uninstall ;;
  start) start ;;
  stop) stop ;;
  restart) stop; sleep 1; start ;;
  *) echo "usage: $0 status|start|stop|restart|install|uninstall"; exit 2 ;;
esac
