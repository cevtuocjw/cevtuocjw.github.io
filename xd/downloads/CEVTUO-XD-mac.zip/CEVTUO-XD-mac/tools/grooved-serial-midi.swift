// GrooveD · USB 串口 → CoreMIDI
//
// 设备上的 Groove D 通过 USB 串口发 `G1 ...` 行；这个工具把它们变成
// 真正的 MIDI 消息，并挂在一个叫 "GrooveD" 的虚拟端口上。
//
// 编译：swiftc -O tools/grooved-serial-midi.swift -o tools/grooved-serial-midi
// 运行：tools/grooved-serial-midi                 # 自动找 /dev/cu.usbmodem*
//       GROOVED_PORT=/dev/cu.usbmodem1101 tools/grooved-serial-midi
//
// ⚠️ 只认行首 `G1 `：设备的日志也走同一条串口，混在一起时必须能分开。
// ⚠️ UMP 的坑见 grooved-midi.swift 里 `umps()` 的注释：裸字节会被静默丢掉。

import Foundation
import CoreMIDI
import Network

let PPQN = 24.0

/* ───────────────────────── CoreMIDI ───────────────────────── */

var client = MIDIClientRef()
var source = MIDIEndpointRef()

func midiInit() -> Bool {
    let cs = MIDIClientCreateWithBlock("GrooveD-Serial" as CFString, &client, nil)
    guard cs == noErr else {
        FileHandle.standardError.write("MIDIClientCreate 失败：\(cs)\n".data(using: .utf8)!)
        return false
    }
    let ss = MIDISourceCreateWithProtocol(client, "GrooveD" as CFString, ._1_0, &source)
    guard ss == noErr else {
        FileHandle.standardError.write("MIDISourceCreateWithProtocol 失败：\(ss)\n".data(using: .utf8)!)
        return false
    }
    return true
}

func umps(_ bytes: [UInt8]) -> [UInt32] {
    var out: [UInt32] = []
    var i = 0
    while i < bytes.count {
        let status = bytes[i]
        if status >= 0xF8 {
            out.append((0x1 << 28) | (UInt32(status) << 16))
            i += 1
        } else if status >= 0xF0 {
            out.append((0x1 << 28) | (UInt32(status) << 16))
            i += 1
        } else {
            let d1 = i + 1 < bytes.count ? bytes[i + 1] : 0
            let d2 = i + 2 < bytes.count ? bytes[i + 2] : 0
            out.append((0x2 << 28) | (UInt32(status) << 16) | (UInt32(d1) << 8) | UInt32(d2))
            i += 3
        }
    }
    return out
}

let sendQueue = DispatchQueue(label: "grooved.midi.send")
let clockQueue = DispatchQueue(label: "grooved.midi.clock")
var clockTimer: DispatchSourceTimer?
var clockBpm = 120
var sendFailures = 0
var sendCount = 0

func send(_ bytes: [UInt8]) {
    let words = umps(bytes)
    sendQueue.sync {
        let stride = MemoryLayout<MIDIEventPacket>.stride
        let cap = MemoryLayout<MIDIEventList>.size + stride * (words.count + 1)
        let raw = UnsafeMutableRawPointer.allocate(byteCount: cap, alignment: 8)
        defer { raw.deallocate() }
        let listPtr = raw.assumingMemoryBound(to: MIDIEventList.self)
        var p = MIDIEventListInit(listPtr, ._1_0)
        for w in words {
            var one = w
            p = MIDIEventListAdd(listPtr, cap, p, 0, 1, &one)
        }
        let rc = MIDIReceivedEventList(source, listPtr)
        if rc == noErr { sendCount += 1 } else {
            sendFailures += 1
            if sendFailures <= 3 {
                FileHandle.standardError.write("MIDIReceivedEventList 失败 \(rc)\n".data(using: .utf8)!)
            }
        }
    }
}

/* ───────────────────────── 串口 ───────────────────────── */

func findPort() -> String? {
    if let p = ProcessInfo.processInfo.environment["GROOVED_PORT"], !p.isEmpty { return p }
    let dir = "/dev"
    let names = (try? FileManager.default.contentsOfDirectory(atPath: dir)) ?? []
    let ports = names.filter { $0.hasPrefix("cu.usbmodem") }.sorted().map { dir + "/" + $0 }
    return ports.first
}

guard midiInit() else { exit(1) }
FileHandle.standardError.write("[grooved-serial] 虚拟端口 \"GrooveD\" 已建立。\n".data(using: .utf8)!)

var lastPort = ""
var handle: FileHandle?

func openPort(_ path: String) -> FileHandle? {
    guard let h = FileHandle(forUpdatingAtPath: path) else { return nil }
    return h
}

func pump(_ h: FileHandle) {
    var buf = Data()
    while true {
        let chunk = h.availableData
        if chunk.isEmpty { break }
        buf.append(chunk)
        while let nl = buf.firstIndex(of: 0x0A) {
            let lineData = buf.subdata(in: 0..<nl)
            buf.removeSubrange(0...nl)
            guard let line = String(data: lineData, encoding: .utf8) else { continue }
            handleLine(line.trimmingCharacters(in: .whitespacesAndNewlines))
        }
    }
}

func stopClock() {
    clockTimer?.cancel()
    clockTimer = nil
}

func startClock() {
    stopClock()
    let t = DispatchSource.makeTimerSource(queue: clockQueue)
    let interval = 60.0 / (Double(clockBpm) * PPQN)
    // 1ms leeway：再小只会让系统更忙，不会让节拍更准。
    t.schedule(deadline: .now(), repeating: interval, leeway: .milliseconds(1))
    t.setEventHandler { send([0xF8]) }
    clockTimer = t
    t.resume()
    FileHandle.standardError.write("[grooved-serial] clock \(clockBpm) BPM（本机生成）\n".data(using: .utf8)!)
}

/* ── 设备 → 服务端（手机显示用）──────────────────────────────────
 * 串口上的 G1 行每隔 150ms 批量 POST 到 /api/groove/ingest。
 * ⚠️ 只在**从串口读到**时转发；TCP 进来的不要再转发一次，否则会绕回自己。
 */
let fwdQueue = DispatchQueue(label: "grooved.fwd")
var fwdBuf: [String] = []

func startForwarder() {
    let t = DispatchSource.makeTimerSource(queue: fwdQueue)
    t.schedule(deadline: .now() + 0.15, repeating: 0.15)
    t.setEventHandler {
        guard !fwdBuf.isEmpty else { return }
        let lines = fwdBuf; fwdBuf.removeAll(keepingCapacity: true)
        guard let url = URL(string: "http://127.0.0.1:8765/api/groove/ingest") else { return }
        var r = URLRequest(url: url)
        r.httpMethod = "POST"
        r.setValue("application/json", forHTTPHeaderField: "content-type")
        r.httpBody = try? JSONSerialization.data(withJSONObject: ["lines": lines])
        r.timeoutInterval = 1.5
        URLSession.shared.dataTask(with: r).resume()
    }
    t.resume()
}

/* ── 写给设备（Cospon D 的数据）────────────────────────────────
 * 用同一根 USB 串口反向写。设备那侧只认 `AG `/`AGENT ` 前缀。
 */
let serialWriteQueue = DispatchQueue(label: "grooved.serial.write")
var currentPort: FileHandle?

func writeSerial(_ text: String) {
    guard let data = text.data(using: .utf8) else { return }
    serialWriteQueue.async {
        guard let h = currentPort else { return }
        do {
            try h.write(contentsOf: data)
            // 只给"手机 → 手表"的这几类留痕：它们没有回执，不写日志就完全看不见。
            if text.hasPrefix("NP ") || text.hasPrefix("SESS ") || text.hasPrefix("AG ") ||
               text.hasPrefix("MSG ") || text.hasPrefix("PERM ") || text.hasPrefix("NET ") {
                FileHandle.standardError.write(("[to-device] " + text).data(using: .utf8)!)
            }
        } catch { /* 设备不在就丢掉，下一次 2 秒后再来 */ }
    }
}

func sanitize(_ s: String) -> String {
    // 手表字体只覆盖 ASCII / 中文 / 中文标点。emoji、零宽、数学符号没有字形，
    // 会变成一个个长方形 —— 在桥这一层就丢掉，别指望设备装全套字体。
    func ok(_ v: UInt32) -> Bool {
        (0x20...0x7E).contains(v) || (0x3000...0x303F).contains(v) ||
        (0xFF00...0xFFEF).contains(v) || (0x4E00...0x9FFF).contains(v) ||
        (0x2000...0x206F).contains(v)
    }
    let scalars = s.unicodeScalars.map { ok($0.value) ? Character($0) : " " }
    return String(scalars)
        .replacingOccurrences(of: "|", with: "/")
        .replacingOccurrences(of: "\n", with: " ")
        .replacingOccurrences(of: "\r", with: " ")
}

func pollAgents() {
    guard let url = URL(string: "http://127.0.0.1:8765/api/agents/list") else { return }
    var r = URLRequest(url: url); r.timeoutInterval = 1.5
    URLSession.shared.dataTask(with: r) { data, _, _ in
        var out = ""
        if let data,
           let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            let list = (obj["list"] as? [[String: Any]]) ?? []
            lastAgents = list
            let pending = (obj["pending"] as? Int) ?? 0
            out += "AG \(pending) \(list.count)\n"
            // SESS：CrewTower 那种卡片要的字段（agent/应用/状态/活动/上下文/项目/年龄）
            for (idx, item) in list.prefix(3).enumerated() {
                let agent = sanitize((item["agent"] as? String) ?? "")
                let app = sanitize((item["app"] as? String) ?? "")
                let state = sanitize((item["state"] as? String) ?? "unknown")
                let act = sanitize((item["activity"] as? String) ?? "")
                let tokens = (item["tokens"] as? Int) ?? 0
                let limit = (item["limit"] as? Int) ?? 0
                let cwd = (item["cwd"] as? String) ?? ""
                let project = sanitize(cwd.split(separator: "/").last.map(String.init) ?? "")
                let age = (item["ageSec"] as? Int) ?? -1
                let turn = (item["turnSec"] as? Int) ?? 0
                let session = (item["sessionSec"] as? Int) ?? 0
                out += "SESS \(agent)|\(app)|\(state)|\(act)|\(tokens)|\(limit)|\(project)|\(age)|\(turn)|\(session)\n"
                // 最近 6 次工具调用：手表上的 STEPS 视图
                if let steps = item["steps"] as? [String] {
                    for t in steps.prefix(6) {
                        out += "STEP \(idx)|\(sanitize(t))\n"
                    }
                }
                // 最近 8 条消息（手表详情里滚动看）
                if let msgs = item["messages"] as? [[String: Any]] {
                    for m in msgs.prefix(8) {
                        let role = sanitize((m["role"] as? String) ?? "")
                        let txt = sanitize((m["text"] as? String) ?? "")
                        out += "MSG \(idx)|\(role)|\(txt)\n"
                    }
                }
            }
            // 快照结束：手表在这之前只写 staging，收到 END 才一次性重画。
            out += "END\n"
        }
        // 手机正在播放（Stem-D 白色标签 / AUDIO 指示）
        guard let mediaURL = URL(string: "http://127.0.0.1:8765/api/media") else {
            writeSerial(out)
            return
        }
        var mr = URLRequest(url: mediaURL); mr.timeoutInterval = 1.5
        URLSession.shared.dataTask(with: mr) { mdata, _, _ in
            var mout = out
            if let mdata,
               let mobj = try? JSONSerialization.jsonObject(with: mdata) as? [String: Any],
               let np = mobj["now"] as? [String: Any] {
                let title = sanitize((np["title"] as? String) ?? "")
                let artist = sanitize((np["artist"] as? String) ?? "")
                let playing = (np["playing"] as? Bool ?? false) ? 1 : 0
                mout += "NP \(title)|\(artist)|\(playing)\n"
            } else {
                mout += "NP ||0\n"
            }
            if ProcessInfo.processInfo.environment["GROOVED_DEBUG_SERIAL"] == "1" {
                FileHandle.standardError.write(("[write] " + mout).data(using: .utf8)!)
            }
            writeSerial(mout)
        }.resume()
    }.resume()
}

/* 待批请求：手表上显示 ALLOW / DENY 两个键 */
func pollPending() {
    guard let url = URL(string: "http://127.0.0.1:8765/api/agents/pending") else { return }
    var r = URLRequest(url: url); r.timeoutInterval = 1.5
    URLSession.shared.dataTask(with: r) { data, _, _ in
        var out = "PERM -\n"
        if let data,
           let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let pending = obj["pending"] as? [[String: Any]],
           let first = pending.first {
            let id = sanitize((first["id"] as? String) ?? "")
            let tool = sanitize((first["tool"] as? String) ?? "")
            let detail = sanitize((first["detail"] as? String) ?? "")
            if !id.isEmpty { out = "PERM \(id)|\(tool)|\(detail)\n" }
        }
        writeSerial(out)
    }.resume()
}

func forward(_ line: String) {
    guard line.hasPrefix("G1 ") else { return }
    fwdQueue.async {
        fwdBuf.append(line)
        if fwdBuf.count > 64 { fwdBuf.removeFirst(fwdBuf.count - 64) }
    }
}

/* ── 转发给 DSP（tcp 9002，实时改音）────────────────────────────── */
let dspQueue = DispatchQueue(label: "grooved.dsp.client")
var dspConn: NWConnection?
var lastAgents: [[String: Any]] = []

func forwardToDSP(_ line: String) {
    guard line.hasPrefix("G1 ") else { return }
    dspQueue.async {
        if dspConn == nil {
            let c = NWConnection(host: "127.0.0.1", port: 9002, using: .tcp)
            c.stateUpdateHandler = { st in
                if case .failed = st { dspConn = nil }
                if case .cancelled = st { dspConn = nil }
            }
            c.start(queue: dspQueue)
            dspConn = c
        }
        let data = (line + "\n").data(using: .utf8)!
        dspConn?.send(content: data, completion: .contentProcessed { _ in })
    }
}

func handleLine(_ line: String) {
    // Cospon D 的蓝键：立刻刷新 agent 列表（不是 MIDI，不走下面的解析）
    if line.hasPrefix("C1 REFRESH") { pollAgents(); return }
    guard line.hasPrefix("G1 ") else { return }
    let parts = line.dropFirst(3).split(separator: " ").map(String.init)
    guard let cmd = parts.first else { return }

    func num(_ i: Int, _ d: Int) -> Int { i < parts.count ? (Int(parts[i]) ?? d) : d }

    switch cmd {
    // 手机 → 手表：这些是设备端 App 自己的命令，原样写回串口（去掉 G1 前缀）。
    case "NP", "SESS", "AG", "DETAIL", "NET":
        writeSerial(String(line.dropFirst(3)) + "\n")
    case "PERM":
        // 手表上的 ALLOW / DENY：转发到审批队列
        guard parts.count >= 3 else { return }
        let id = parts[1]
        let behavior = parts[2]
        guard behavior == "allow" || behavior == "deny" else { return }
        guard let url = URL(string: "http://127.0.0.1:8765/api/agents/decide") else { return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "content-type")
        req.httpBody = try? JSONSerialization.data(withJSONObject:
            ["id": id, "behavior": behavior, "by": "device"])
        req.timeoutInterval = 2.0
        URLSession.shared.dataTask(with: req).resume()
        writeSerial("PERM -\n")
    case "ACTION":
        // 手表：CONTINUE / HANDOFF。slot → session id（用最近一次 /api/agents/list 的顺序）。
        guard parts.count >= 3, let slot = Int(parts[1]) else { return }
        let action = parts[2]
        guard action == "continue" || action == "handoff" else { return }
        guard slot >= 0, slot < lastAgents.count,
              let id = lastAgents[slot]["id"] as? String else {
            writeSerial("ACT \(slot) NO SESSION\n")
            return
        }
        guard let url = URL(string: "http://127.0.0.1:8765/api/agents/action") else { return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "content-type")
        req.httpBody = try? JSONSerialization.data(withJSONObject: ["id": id, "action": action])
        req.timeoutInterval = 12.0
        URLSession.shared.dataTask(with: req) { data, _, _ in
            var ok = false
            var mode = ""
            var err = ""
            if let data, let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                ok = (obj["ok"] as? Bool) ?? false
                mode = (obj["mode"] as? String) ?? ""
                err = (obj["error"] as? String) ?? ""
            }
            let label = action == "handoff" ? "HANDOFF" : "CONTINUE"
            // 把失败原因一起送回手表：只写 FAIL 的话，用户分不清是没授权、有草稿、
            // 还是 Cherry 没开。错误码很短（DRAFT / NOT_TRUSTED / NO_CHERRY）。
            let detail = ok ? mode : err
            let tail = ok ? "READY" : "FAIL"
            let line = "ACT \(slot) \(label) \(tail)\(detail.isEmpty ? "" : " " + detail)\n"
            FileHandle.standardError.write(("[action] " + line).data(using: .utf8)!)
            writeSerial(line)
        }.resume()
    case "CC":
        let ch = num(1, 1), cc = num(2, 0), v = num(3, 0)
        send([UInt8(0xB0 | ((ch - 1) & 0x0F)), UInt8(cc & 0x7F), UInt8(v & 0x7F)])
    case "NOTEON":
        let ch = num(1, 1), n = num(2, 60), v = num(3, 100)
        send([UInt8(0x90 | ((ch - 1) & 0x0F)), UInt8(n & 0x7F), UInt8(v & 0x7F)])
    case "NOTEOFF":
        let ch = num(1, 1), n = num(2, 60), v = num(3, 0)
        send([UInt8(0x80 | ((ch - 1) & 0x0F)), UInt8(n & 0x7F), UInt8(v & 0x7F)])
    case "START": send([0xFA]); startClock()
    case "STOP":  send([0xFC]); stopClock()
    case "CONT":  send([0xFB]); startClock()
    case "CLOCK":
        // ⚠️ 故意忽略：时钟由**本机**生成。手机/手表的定时器抖动实测
        // p10 1.5ms / p90 27ms（期望 20.83ms），而 MIDI 时钟必须是本地的。
        break
    case "PANIC":
        for ch in 0..<16 { send([UInt8(0xB0 | ch), 123, 0]); send([UInt8(0xB0 | ch), 120, 0]) }
    case "STEM":
        let i = num(1, 0), v = num(2, 0)
        if i >= 0 && i < 4 { send([UInt8(0xB0), UInt8(20 + i), UInt8(v & 0x7F)]) }
    case "MUTE":
        let i = num(1, 0), on = num(2, 0)
        if i >= 0 && i < 4 { send([UInt8(0xB0), UInt8(30 + i), UInt8(on != 0 ? 127 : 0)]) }
    case "SOLO":
        let i = num(1, 0), on = num(2, 0)
        if i >= 0 && i < 4 { send([UInt8(0xB0), UInt8(40 + i), UInt8(on != 0 ? 127 : 0)]) }
    case "MASTER":
        send([UInt8(0xB0), 7, UInt8(num(1, 100) & 0x7F)])
    case "LOOP":
        send([UInt8(0xB0), 80, UInt8(num(1, 0) != 0 ? 127 : 0)])
    case "FX":
        send([UInt8(0xB0), 74, UInt8(num(1, 0) & 0x7F)])
    case "BPM":
        clockBpm = max(40, min(240, num(1, 120)))
        if clockTimer != nil { startClock() }   // 正在走 ⇒ 立刻换成新速度
        FileHandle.standardError.write("[grooved-serial] BPM \(clockBpm)\n".data(using: .utf8)!)
    case "HELLO":
        FileHandle.standardError.write("[grooved-serial] 设备上线：\(line)\n".data(using: .utf8)!)
    default:
        break
    }
    forwardToDSP(line)
}

/* 自测：不接设备，直接把几条样本行喂进解析器，用来验证
 * "协议 → UMP → CoreMIDI" 这一段。配 tools/midi-probe 当接收端。
 *   GROOVED_SELFTEST=1 tools/grooved-serial-midi
 */
if ProcessInfo.processInfo.environment["GROOVED_SELFTEST"] == "1" {
    Thread.sleep(forTimeInterval: 2.0)   // 给探针时间先连上
    handleLine("G1 CC 1 7 100")
    handleLine("G1 NOTEON 1 36 110")
    handleLine("G1 NOTEOFF 1 36 0")
    handleLine("G1 START")
    for _ in 0..<4 { handleLine("G1 CLOCK") }
    Thread.sleep(forTimeInterval: 0.8)
    exit(0)
}

/* ── 手机 / 其它进程 → 这里 → CoreMIDI ───────────────────────────
 * 监听 127.0.0.1:9001 的 **TCP**，一行一条 `G1 ...`（和串口同一套协议）。
 * ⚠️ 用 TCP 不用 UDP：控制消息丢一条就是一个推子不动，
 *    而 UDP 在"每条一个连接"的写法下实测丢过第 4 条。
 */
if let listener = try? NWListener(using: .tcp, on: 9001) {
    listener.newConnectionHandler = { conn in
        conn.start(queue: .global())
        func recv(_ c: NWConnection, _ carry: Data) {
            c.receive(minimumIncompleteLength: 1, maximumLength: 8192) { data, _, done, _ in
                var buf = carry
                if let d = data { buf.append(d) }
                while let nl = buf.firstIndex(of: 0x0A) {
                    let lineData = buf.subdata(in: 0..<nl)
                    buf.removeSubrange(0...nl)
                    if let line = String(data: lineData, encoding: .utf8) {
                        handleLine(line.trimmingCharacters(in: .whitespaces))
                    }
                }
                if done { c.cancel() } else { recv(c, buf) }
            }
        }
        recv(conn, Data())
    }
    listener.start(queue: .global())
    FileHandle.standardError.write("[grooved-serial] TCP 127.0.0.1:9001 已监听（手机控制入口）\n".data(using: .utf8)!)
} else {
    FileHandle.standardError.write("[grooved-serial] ⚠️ TCP 9001 监听失败（手机控制不可用）\n".data(using: .utf8)!)
}

startForwarder()
// Cospon D：每 2 秒把 Mac 上的 agent 列表写进串口
let agentTimer = DispatchSource.makeTimerSource(queue: .global())
agentTimer.schedule(deadline: .now() + 1, repeating: 2.0)
agentTimer.setEventHandler { pollAgents(); pollPending() }
agentTimer.resume()

/* 主循环：端口掉线就重连（USB 重插/设备重启都很常见） */
while true {
    guard let path = findPort() else {
        if lastPort != "" { FileHandle.standardError.write("串口不在了，等待…\n".data(using: .utf8)!) }
        lastPort = ""
        Thread.sleep(forTimeInterval: 1.0)
        continue
    }
    if path != lastPort {
        handle = openPort(path)
        currentPort = handle
        lastPort = path
        if handle != nil {
            FileHandle.standardError.write("[grooved-serial] 已连接 \(path)\n".data(using: .utf8)!)
        }
    }
    guard let h = handle else { Thread.sleep(forTimeInterval: 1.0); continue }

    // 阻塞读一帧；设备重启会返回空，跳出重连
    let chunk = h.availableData
    if chunk.isEmpty {
        handle = nil
        currentPort = nil
        Thread.sleep(forTimeInterval: 0.5)
        continue
    }
    var buf = chunk
    while let nl = buf.firstIndex(of: 0x0A) {
        let lineData = buf.subdata(in: 0..<nl)
        buf.removeSubrange(0...nl)
        if let line = String(data: lineData, encoding: .utf8) {
            let text = line.trimmingCharacters(in: .whitespacesAndNewlines)
            // 手表那侧的诊断行（只用来确认数据真的到了，不影响 MIDI）
            if text.hasPrefix("C_SESS ") || text.hasPrefix("S_NP ") {
                FileHandle.standardError.write(("[device] " + text + "\n").data(using: .utf8)!)
            }
            handleLine(text)
            forward(text)          // 只转发串口来的（TCP 那条路不经过这里）
        }
    }
}
