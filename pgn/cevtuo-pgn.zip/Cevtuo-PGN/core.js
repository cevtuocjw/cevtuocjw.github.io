/*
 * Shared rules for Cevtuo-PGN.
 *
 * Loaded in the popup/viewer (<script>) and injected into the page before
 * extractor.js, so both sides agree on what a "clean article URL" is and on
 * how duplicates are removed. Keep this file dependency-free: it must run in
 * a page's isolated world as well as in an extension page.
 */
(() => {
  'use strict';

  const CORE_KEY = '__CEVTUO_PGN_CORE_V2__';

  /* ---------------- hosts ---------------- */

  // Multi-tenant hosts must keep their subdomain: every Substack publication
  // is a different news source, not one giant "substack.com" list.
  const MULTI_TENANT = /(?:^|\.)(?:substack\.com|medium\.com|wordpress\.com|blogspot\.com|github\.io|netlify\.app|vercel\.app|wixsite\.com|ghost\.io)$/i;

  // Approximate public-suffix stripping. Good enough for grouping a site's
  // www/edition/m subdomains into one list without a 200 KB PSL dependency.
  const TWO_LEVEL_SUFFIX = /\.(?:co|com|org|net|gov|edu|ac)\.[a-z]{2,3}$/i;

  function stripWww(host) {
    return (host || '').toLowerCase().replace(/^www\./, '');
  }

  function registrableDomain(host) {
    const clean = stripWww(host);
    if (!clean || /^[\d.]+$/.test(clean)) return clean;
    const parts = clean.split('.');
    if (parts.length <= 2) return clean;
    if (TWO_LEVEL_SUFFIX.test(clean)) return parts.slice(-3).join('.');
    return parts.slice(-2).join('.');
  }

  function siteKey(host) {
    const clean = stripWww(host);
    if (!clean) return '';
    if (MULTI_TENANT.test(clean)) return clean;
    return registrableDomain(clean);
  }

  function sameSiteHost(a, b) {
    return Boolean(a && b) && siteKey(a) === siteKey(b);
  }

  function isGoogleNewsHost(host) {
    return /^news\.google\.[a-z.]{2,}$/i.test(stripWww(host || ''));
  }

  // Share buttons, ad networks and login/app hosts: never article links, even
  // when they sit inside a story card.
  const BLOCKED_HOST = /(?:^|\.)(?:facebook\.com|fb\.com|fb\.me|twitter\.com|x\.com|t\.co|linkedin\.com|instagram\.com|threads\.net|tiktok\.com|pinterest\.com|reddit\.com|whatsapp\.com|wa\.me|t\.me|telegram\.me|youtube\.com|youtu\.be|vimeo\.com|twitch\.tv|spotify\.com|podcasts\.apple\.com|music\.apple\.com|apple\.com|play\.google\.com|accounts\.google\.com|google\.com|googleapis\.com|gstatic\.com|doubleclick\.net|googlesyndication\.com|googletagmanager\.com|outbrain\.com|taboola\.com|amazon\.com|paypal\.com|patreon\.com|stripe\.com|mailchimp\.com|list-manage\.com)$/i;

  const KNOWN_NEWS_HOST = /(?:^|\.)(?:nytimes\.com|ft\.com|wsj\.com|bloomberg\.com|reuters\.com|apnews\.com|theguardian\.com|bbc\.com|bbc\.co\.uk|washingtonpost\.com|cnn\.com|nbcnews\.com|cbsnews\.com|cnbc\.com|politico\.com|thehill\.com|axios\.com|semafor\.com|fortune\.com|forbes\.com|businessinsider\.com|economist\.com|aljazeera\.com|scmp\.com|nikkei\.com|japantimes\.co\.jp|asahi\.com|yomiuri\.co\.jp|mainichi\.jp|straitstimes\.com|channelnewsasia\.com|smh\.com\.au|theage\.com\.au|nzherald\.co\.nz|lemonde\.fr|spiegel\.de|dw\.com|elpais\.com|corriere\.it|thepaper\.cn|caixin\.com|36kr\.com|techcrunch\.com|theverge\.com|wired\.com|arstechnica\.com|engadget\.com|thetimes\.co\.uk|telegraph\.co\.uk|independent\.co\.uk|standard\.co\.uk|mirror\.co\.uk|dailymail\.co\.uk|huffpost\.com|vox\.com|slate\.com|salon\.com|theatlantic\.com|newyorker\.com|vanityfair\.com|time\.com|newsweek\.com|usatoday\.com|latimes\.com|sfchronicle\.com|bostonglobe\.com|chicagotribune\.com|seattletimes\.com|denverpost\.com|staradvertiser\.com|mercurynews\.com|ocregister\.com|nydailynews\.com|nypost\.com)$/i;

  function isBlockedHost(host) {
    return BLOCKED_HOST.test(stripWww(host));
  }

  function isKnownNewsHost(host) {
    return KNOWN_NEWS_HOST.test(stripWww(host));
  }

  /* ---------------- site profiles ---------------- */

  // The regexes are confidence boosts, not hard filters: a site redesign that
  // changes its URL shape still falls back to the generic heuristics.
  const SITE_PROFILES = [
    { host: /(?:^|\.)nytimes\.com$/i, label: 'NYTimes', article: /\/(?:19|20)\d{2}\/\d{2}\/\d{2}\// },
    { host: /(?:^|\.)ft\.com$/i, label: 'Financial Times', article: /\/content\/[0-9a-f][0-9a-f-]{7,}/i },
    { host: /(?:^|\.)wsj\.com$/i, label: 'WSJ', article: /\/articles\/[a-z0-9-]+/i },
    { host: /(?:^|\.)bloomberg\.com$/i, label: 'Bloomberg', article: /\/news\/articles\/\d{4}-\d{2}-\d{2}\//i },
    { host: /(?:^|\.)reuters\.com$/i, label: 'Reuters', article: /\/[a-z0-9-]+-\d{4}-\d{2}-\d{2}\/?$/i },
    { host: /(?:^|\.)apnews\.com$/i, label: 'AP', article: /\/article\/[a-z0-9-]+/i },
    { host: /(?:^|\.)theguardian\.com$/i, label: 'Guardian', article: /\/(?:19|20)\d{2}\/(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\/\d{1,2}\//i },
    { host: /(?:^|\.)bbc\.(?:com|co\.uk)$/i, label: 'BBC', article: /\/(?:news|sport)\/articles\/[a-z0-9]+$|\/(?:news|sport|business|culture|travel|future)\/[a-z0-9-]+-\d+$/i },
    { host: /(?:^|\.)washingtonpost\.com$/i, label: 'Washington Post', article: /\/(?:[a-z-]+)\/(?:19|20)\d{2}\/\d{2}\/\d{2}\//i },
    { host: /(?:^|\.)cnn\.com$/i, label: 'CNN', article: /\/(?:19|20)\d{2}\/\d{2}\/\d{2}\// },
    { host: /(?:^|\.)nbcnews\.com$/i, label: 'NBC News', article: /\/news\/[a-z0-9-]+/i },
    { host: /(?:^|\.)cbsnews\.com$/i, label: 'CBS News', article: /\/news\/[a-z0-9-]+/i },
    { host: /(?:^|\.)cnbc\.com$/i, label: 'CNBC', article: /\/(?:19|20)\d{2}\/\d{2}\/\d{2}\// },
    { host: /(?:^|\.)politico\.com$/i, label: 'Politico', article: /\/news\/\d{4}\/\d{2}\/\d{2}\//i },
    { host: /(?:^|\.)thehill\.com$/i, label: 'The Hill', article: /\/[a-z-]+\/[a-z0-9-]+\/\d+/i },
    { host: /(?:^|\.)axios\.com$/i, label: 'Axios', article: /\/(?:19|20)\d{2}\/\d{2}\/\d{2}\// },
    { host: /(?:^|\.)semafor\.com$/i, label: 'Semafor', article: /\/(?:19|20)\d{2}\/\d{2}\/\d{2}\// },
    { host: /(?:^|\.)economist\.com$/i, label: 'Economist', article: /\/(?:19|20)\d{2}\/\d{2}\/\d{2}\// },
    { host: /(?:^|\.)aljazeera\.com$/i, label: 'Al Jazeera', article: /\/news\/\d{4}\/\d{1,2}\/\d{1,2}\//i },
    { host: /(?:^|\.)scmp\.com$/i, label: 'SCMP', article: /\/news\/[a-z-]+\/[a-z-]+\/article\/\d+/i },
    { host: /(?:^|\.)nikkei\.com$/i, label: 'Nikkei', article: /\/article\/[A-Z0-9]+/i },
    { host: /(?:^|\.)japantimes\.co\.jp$/i, label: 'Japan Times', article: /\/news\/\d{4}\/\d{2}\/\d{2}\//i },
    { host: /(?:^|\.)asahi\.com$/i, label: 'Asahi', article: /\/articles\/[A-Z0-9]+/i },
    { host: /(?:^|\.)straitstimes\.com$/i, label: 'Straits Times', article: /\/[a-z-]+\/story\/[a-z0-9-]+/i },
    { host: /(?:^|\.)channelnewsasia\.com$/i, label: 'CNA', article: /\/news\/[a-z-]+\/[a-z0-9-]+-\d+/i },
    { host: /(?:^|\.)smh\.com\.au$/i, label: 'SMH', article: /\/(?:[a-z-]+)\/[a-z0-9-]+-\d{4}-\d{1,2}/i },
    { host: /(?:^|\.)theage\.com\.au$/i, label: 'The Age', article: /\/(?:[a-z-]+)\/[a-z0-9-]+-\d{4}-\d{1,2}/i },
    { host: /(?:^|\.)nzherald\.co\.nz$/i, label: 'NZ Herald', article: /\/[a-z-]+\/[a-z0-9-]+\/[a-z0-9-]+/i },
    { host: /(?:^|\.)lemonde\.fr$/i, label: 'Le Monde', article: /\/[a-z-]+\/article\/\d{4}\/\d{2}\/\d{2}\//i },
    { host: /(?:^|\.)spiegel\.de$/i, label: 'Spiegel', article: /\/[a-z-]+\/a-\d+/i },
    { host: /(?:^|\.)dw\.com$/i, label: 'DW', article: /\/[a-z]+\/[a-z0-9-]+\/a-\d+/i },
    { host: /(?:^|\.)elpais\.com$/i, label: 'El País', article: /\/[a-z-]+\/\d{4}-\d{2}-\d{2}\//i },
    { host: /(?:^|\.)thepaper\.cn$/i, label: '澎湃新闻', article: /\/newsDetail_forward_\d+/i },
    { host: /(?:^|\.)caixin\.com$/i, label: '财新', article: /\/\d{4}-\d{2}-\d{2}\/\d+\.html/i },
    { host: /(?:^|\.)36kr\.com$/i, label: '36Kr', article: /\/p\/\d+/i },
    { host: /(?:^|\.)techcrunch\.com$/i, label: 'TechCrunch', article: /\/(?:19|20)\d{2}\/\d{2}\/\d{2}\// },
    { host: /(?:^|\.)theverge\.com$/i, label: 'The Verge', article: /\/[a-z0-9-]+\/\d{5,}$/i },
    { host: /(?:^|\.)wired\.com$/i, label: 'Wired', article: /\/story\/[a-z0-9-]+/i },
    { host: /(?:^|\.)arstechnica\.com$/i, label: 'Ars Technica', article: /\/[a-z-]+\/(?:19|20)\d{2}\/\d{2}\//i },
    { host: /(?:^|\.)engadget\.com$/i, label: 'Engadget', article: /\/(?:19|20)\d{2}-\d{2}-\d{2}\// },
    { host: /(?:^|\.)thetimes\.co\.uk$/i, label: 'The Times', article: /\/article\/[a-z0-9-]+/i },
    { host: /(?:^|\.)telegraph\.co\.uk$/i, label: 'Telegraph', article: /\/[a-z-]+\/\d{4}\/\d{2}\/\d{2}\//i },
    { host: /(?:^|\.)independent\.co\.uk$/i, label: 'Independent', article: /\/[a-z-]+\/[a-z0-9-]+-\d{6,}/i },
    { host: /(?:^|\.)huffpost\.com$/i, label: 'HuffPost', article: /\/entry\/[a-z0-9-]+_\d+/i },
    { host: /(?:^|\.)vox\.com$/i, label: 'Vox', article: /\/[a-z0-9-]+\/\d{5,}/i },
    { host: /(?:^|\.)theatlantic\.com$/i, label: 'The Atlantic', article: /\/[a-z-]+\/(?:19|20)\d{2}\/\d{2}\//i },
    { host: /(?:^|\.)newyorker\.com$/i, label: 'The New Yorker', article: /\/[a-z-]+\/[a-z0-9-]+/i },
    { host: /(?:^|\.)time\.com$/i, label: 'TIME', article: /\/\d{5,}\/[a-z0-9-]+/i },
    { host: /(?:^|\.)usatoday\.com$/i, label: 'USA Today', article: /\/story\/[a-z-]+\/[a-z0-9-]+\/\d{7,}/i },
    { host: /(?:^|\.)latimes\.com$/i, label: 'LA Times', article: /\/(?:19|20)\d{2}\/\d{2}\/\d{2}\// },
    { host: /(?:^|\.)nypost\.com$/i, label: 'NY Post', article: /\/(?:19|20)\d{2}\/\d{2}\/\d{2}\// },
  ];

  function profileFor(host) {
    const clean = stripWww(host);
    for (const profile of SITE_PROFILES) {
      if (profile.host.test(clean)) return profile;
    }
    return null;
  }

  /* ---------------- URLs ---------------- */

  // Only parameters that never change which article is being read. Unknown
  // parameters stay in the URL: many CMSs put the article id in the query.
  const TRACKING_PARAM = /^(?:utm_.+|fbclid|gclid|dclid|msclkid|yclid|twclid|igshid|mc_cid|mc_eid|_hsenc|_hsmi|mkt_tok|vero_conv|vero_id|wickedid|oly_anon_id|oly_enc_id|sc_cid|smid|smtyp|referrer|ref|referer|source|src|cmpid|cmp|sref|ito|at_medium|at_campaign|at_custom1|at_custom2|at_custom3|at_custom4|spm|from|share|shared|update|amp|output|trk|trk_contact|trk_msg|trk_module|trk_sid|ns_source|ns_mchannel|ns_campaign|ns_linkname|ns_fee|guccounter|CMP)$/i;

  function canonicalize(href, base) {
    let u;
    try {
      u = new URL(href, base || (typeof location !== 'undefined' ? location.href : undefined));
    } catch {
      return null;
    }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    if (!u.hostname) return null;

    u.hostname = u.hostname.toLowerCase();
    u.hash = '';

    const kept = [];
    for (const [key, value] of u.searchParams) {
      if (!TRACKING_PARAM.test(key)) kept.push([key, value]);
    }
    u.search = '';
    for (const [key, value] of kept) u.searchParams.append(key, value);

    let path = u.pathname.replace(/\/+/g, '/');
    path = path.replace(/\/amp(?:\/|$)/i, '/');
    if (path.length > 1) path = path.replace(/\/+$/, '');
    u.pathname = path || '/';

    return u.href;
  }

  function normTitle(value) {
    return (value || '')
      .normalize('NFKC')
      .toLowerCase()
      .replace(/[‘’]/g, "'")
      .replace(/[“”]/g, '"')
      .replace(/[^\p{L}\p{N}]+/gu, ' ')
      .trim();
  }

  /* ---------------- merging ---------------- */

  /**
   * Append items that are new by URL, normalized title, or story cluster id.
   * Mutates `target` and returns it, so callers can append while scrolling.
   */
  function mergeItems(target, incoming) {
    const urls = new Set(target.map((item) => item.url));
    const titles = new Set(target.map((item) => normTitle(item.title)).filter(Boolean));
    const stories = new Set(target.map((item) => item.storyId).filter(Boolean));

    for (const item of incoming || []) {
      if (!item || !item.url) continue;
      if (urls.has(item.url)) continue;

      const titleKey = normTitle(item.title);
      if (titleKey && titles.has(titleKey)) continue;
      if (item.storyId && stories.has(item.storyId)) continue;

      target.push(item);
      urls.add(item.url);
      if (titleKey) titles.add(titleKey);
      if (item.storyId) stories.add(item.storyId);
    }
    return target;
  }

  function dedupeItems(items) {
    return mergeItems([], items);
  }

  const api = {
    CORE_KEY,
    SITE_PROFILES,
    canonicalize,
    dedupeItems,
    isBlockedHost,
    isGoogleNewsHost,
    isKnownNewsHost,
    mergeItems,
    normTitle,
    profileFor,
    registrableDomain,
    sameSiteHost,
    siteKey,
    stripWww,
  };

  if (typeof globalThis !== 'undefined') globalThis[CORE_KEY] = api;
})();
