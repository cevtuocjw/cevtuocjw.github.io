'use strict';

const STORE_KEY = 'gnStore';
const NEWS_URL = 'https://news.google.com/foryou?hl=en-GB&gl=GB&ceid=GB:en';
const KIND_ORDER = ['home', 'foryou', 'following', 'other'];

const IS_VIEWER = document.body.dataset.mode === 'viewer';
const $ = (id) => document.getElementById(id);

const emptyPage = (kind = '') => ({
  pageKind: kind,
  pageLabel: '',
  pageUrl: '',
  capturedAt: 0,
  items: [],
  removed: [],
  unchecked: [],
});

const FORYOU_LIMITS = [20, 30, 50];
const RESOLVED_KEY = 'gnResolved';

let store = {
  pages: {},
  lastKind: '',
  foryouLimit: 30,
  settings: { resolveLinks: true },
};
let currentKind = '';
let filterText = '';
let busy = false;
let toastTimer = 0;
// token -> publisher URL, so a link is resolved at most once.
let resolveCache = {};

/* ---------------- data ---------------- */

function pageKey(url) {
  try {
    return new URL(url).pathname.replace(/\/+$/, '') || '/';
  } catch {
    return '';
  }
}

function isNewsUrl(url) {
  return /^https?:\/\/news\.google\.com\//.test(url || '');
}

function pageFor(kind) {
  return (kind && store.pages[kind]) || null;
}

function currentPage() {
  return pageFor(currentKind);
}

function kindLabel(kind, page) {
  if (kind === 'home') return '首页';
  if (kind === 'foryou') return 'For you';
  if (kind === 'following') return 'Following';
  return (page && page.pageLabel) || '其他页面';
}

function availableKinds() {
  const kinds = KIND_ORDER.filter(
    (kind) => store.pages[kind] && store.pages[kind].items.length
  );
  if (currentKind && !kinds.includes(currentKind)) kinds.push(currentKind);
  return kinds;
}

function visibleItems(page = currentPage()) {
  if (!page) return [];
  const removed = new Set(page.removed);
  let items = page.items.filter((item) => !removed.has(item.url));
  // For you is a long feed; the user picks the first 20/30/50 stories.
  // Deleted items drop out first, so the list backfills to the chosen size.
  if (page.pageKind === 'foryou') {
    items = items.slice(0, store.foryouLimit || 30);
  }
  return items;
}

function selectedItems(page = currentPage()) {
  if (!page) return [];
  const unchecked = new Set(page.unchecked);
  return visibleItems(page).filter((item) => !unchecked.has(item.url));
}

async function loadStore() {
  try {
    const data = await chrome.storage.local.get(STORE_KEY);
    const saved = data && data[STORE_KEY];
    if (!saved || !saved.pages || typeof saved.pages !== 'object') return;
    store = {
      pages: {},
      lastKind: saved.lastKind || '',
      foryouLimit: FORYOU_LIMITS.includes(saved.foryouLimit) ? saved.foryouLimit : 30,
      settings: {
        resolveLinks: !saved.settings || saved.settings.resolveLinks !== false,
      },
    };
    for (const [kind, savedPage] of Object.entries(saved.pages)) {
      if (!savedPage || !Array.isArray(savedPage.items)) continue;
      store.pages[kind] = {
        ...emptyPage(kind),
        ...savedPage,
        removed: Array.isArray(savedPage.removed) ? savedPage.removed : [],
        unchecked: Array.isArray(savedPage.unchecked) ? savedPage.unchecked : [],
      };
    }
  } catch (err) {
    console.error('读取缓存失败', err);
  }
}

function saveStore() {
  chrome.storage.local.set({ [STORE_KEY]: store }).catch((err) => {
    console.error('保存失败', err);
  });
}

/* ---------------- publisher URLs ----------------
 * Google News /read/<token> is an opaque redirect. The token alone is not
 * enough: the page carries a per-article signature that must be sent to
 * Google's own batchexecute endpoint to get the publisher URL. So resolving
 * costs one page fetch (~570 KB) per new article, then the POST. Results are
 * cached by token, so each article is resolved at most once.
 */

function articleToken(url) {
  const m = (url || '').match(/\/(?:read|rss\/articles|articles)\/([^/?#]+)/);
  return m ? m[1] : '';
}

function finalUrlFor(item) {
  const token = articleToken(item.url);
  return (token && resolveCache[token]) || '';
}

// Runs inside the Google News tab: same-origin requests, so Google sees an
// ordinary page request instead of a chrome-extension:// origin (which its
// batchexecute endpoint rejects with HTTP 400).
async function pageResolveTokens(tokens) {
  const out = {};
  const queue = (tokens || []).slice();

  const worker = async () => {
    while (queue.length) {
      const token = queue.shift();
      if (!token) continue;
      try {
        const page = await fetch(
          '/rss/articles/' + token + '?hl=en-GB&gl=GB&ceid=GB:en',
          { credentials: 'include' }
        );
        if (!page.ok) continue;
        const html = await page.text();

        const sg = (html.match(/data-n-a-sg="([^"]+)"/) || [])[1];
        const ts = (html.match(/data-n-a-ts="([^"]+)"/) || [])[1];
        if (!sg || !ts) continue;

        const inner =
          '["garturlreq",[["X","X",["X","X"],null,null,1,1,"GB:en",null,1,null,null,null,null,null,0,1],' +
          '"X","X",1,[1,1,1],1,1,null,0,0,null,0],"' +
          token +
          '",' +
          ts +
          ',"' +
          sg +
          '"]';
        const body =
          'f.req=' + encodeURIComponent(JSON.stringify([[['Fbv4je', inner]]]));

        const res = await fetch(
          '/_/DotsSplashUi/data/batchexecute?rpcids=Fbv4je',
          {
            method: 'POST',
            headers: {
              'content-type': 'application/x-www-form-urlencoded;charset=UTF-8',
            },
            body,
            credentials: 'include',
          }
        );
        if (!res.ok) continue;
        const text = await res.text();
        const hit = text.match(/https?:\/\/[^"\\\s]+/);
        if (hit) out[token] = hit[0].replace(/\\\//g, '/');
      } catch (err) {
        // One bad article must not stop the rest.
      }
    }
  };

  await Promise.all(
    Array.from({ length: Math.min(4, queue.length) }, worker)
  );
  return out;
}

async function resolveAll(items, onProgress) {
  const out = items.map((item) => finalUrlFor(item) || item.url);
  const pending = [];

  items.forEach((item, index) => {
    if (out[index] && out[index] !== item.url) return;
    const token = articleToken(item.url);
    if (!token) return;
    if (resolveCache[token]) {
      out[index] = resolveCache[token];
      return;
    }
    pending.push({ token, index });
  });

  if (!pending.length) return { urls: out, error: '' };

  const tab = (await findTabForKind(currentKind)) || (await findNewsTab());
  if (!tab) {
    return { urls: out, error: '需要先打开一个 Google News 页面' };
  }

  let done = 0;
  let error = '';
  const chunk = 4;

  for (let i = 0; i < pending.length; i += chunk) {
    const group = pending.slice(i, i + chunk);
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: pageResolveTokens,
        args: [group.map((entry) => entry.token)],
      });
      const map = (results && results[0] && results[0].result) || {};
      for (const entry of group) {
        if (map[entry.token]) {
          out[entry.index] = map[entry.token];
          resolveCache[entry.token] = map[entry.token];
        }
      }
    } catch (err) {
      if (!error) error = String((err && err.message) || err).slice(0, 80);
    }
    done += group.length;
    if (onProgress) onProgress(done, pending.length);
  }

  return { urls: out, error };
}

async function loadResolved() {
  try {
    const data = await chrome.storage.local.get(RESOLVED_KEY);
    const saved = data && data[RESOLVED_KEY];
    if (saved && typeof saved === 'object') resolveCache = saved;
  } catch (err) {
    console.error('读取链接缓存失败', err);
  }
}

function saveResolved() {
  const tokens = Object.keys(resolveCache);
  if (tokens.length > 600) {
    for (const token of tokens.slice(0, tokens.length - 600)) {
      delete resolveCache[token];
    }
  }
  chrome.storage.local.set({ [RESOLVED_KEY]: resolveCache }).catch(() => {});
}

/* ---------------- capture ---------------- */

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function extract(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    files: ['extractor.js'],
  });
  return results && results[0] ? results[0].result : null;
}

/* ---------------- deep loading (both feeds) ----------------
 * Google News only renders a screenful at a time. "Pull" here means: scroll the
 * feed a little, read what appeared, repeat - and merge every round, because
 * the feed can recycle cards that scrolled far out of view.
 */

function normTitle(s) {
  return (s || '')
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
}

// Same rules as the extractor, applied across rounds instead of one snapshot.
function mergeItems(target, incoming) {
  const urls = new Set(target.map((i) => i.url));
  const titles = new Set(target.map((i) => normTitle(i.title)).filter(Boolean));
  const stories = new Set(target.map((i) => i.storyId).filter(Boolean));

  for (const item of incoming || []) {
    if (!item || !item.url || urls.has(item.url)) continue;
    const titleKey = normTitle(item.title);
    if (titleKey && titles.has(titleKey)) continue;
    if (item.storyId && stories.has(item.storyId)) continue;

    target.push(item);
    urls.add(item.url);
    if (titleKey) titles.add(titleKey);
    if (item.storyId) stories.add(item.storyId);
  }
  return target;
}

// Runs in the page. Google News' feed advances with the document itself
// (PageDown works), so scroll the window - picking a nested "tallest" element
// proved unreliable because some wrappers are taller than the viewport but do
// not move the feed.
function scrollFeedStep(factor) {
  const dy = Math.round((window.innerHeight || 800) * factor);
  const before = window.scrollY;
  window.scrollBy(0, dy);

  return {
    moved: Math.round(window.scrollY - before),
    height: Math.round(document.documentElement.scrollHeight),
    top: Math.round(window.scrollY),
  };
}

async function deepLoad(tabId, { target = 0, onProgress, maxRounds: roundCap } = {}) {
  const run = (func, args) =>
    chrome.scripting.executeScript({ target: { tabId }, func, args });

  const [{ result: startTop } = { result: 0 }] = await run(() => {
    const root = document.scrollingElement || document.documentElement;
    return root.scrollTop;
  });

  let merged = [];
  let payload = null;
  let lastHeight = 0;
  let quiet = 0;
  // A target needs enough screens to reach it; a plain "more" pull stays short.
  const maxRounds = roundCap || (target ? 45 : 15);
  const deadline = Date.now() + 90000;

  try {
    for (let round = 0; round < maxRounds; round++) {
      if (Date.now() > deadline) break;

      const snapshot = await extract(tabId);
      if (!snapshot || !Array.isArray(snapshot.items)) break;

      payload = snapshot;
      const before = merged.length;
      mergeItems(merged, snapshot.items);
      if (onProgress) onProgress(merged.length);

      const height = snapshot.pageHeight || 0;
      // Only a screen with no new story AND no new page height means the end.
      if (round > 0 && merged.length === before && height <= lastHeight + 40) {
        quiet += 1;
      } else {
        quiet = 0;
      }
      lastHeight = Math.max(lastHeight, height);

      if (quiet >= 3) break;
      if (target && merged.length >= target) break;

      await run(scrollFeedStep, [0.9]);
      await sleep(1050);
    }
  } finally {
    // Leave the user's page where they were reading.
    await run((y) => {
      const root = document.scrollingElement || document.documentElement;
      root.scrollTo(0, y);
    }, [startTop]).catch(() => {});
  }

  return { items: merged, payload };
}

async function activeTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs[0];
}

async function findNewsTab() {
  const tabs = await chrome.tabs.query({ url: 'https://news.google.com/*' });
  if (!tabs || !tabs.length) return null;
  return (
    tabs.find((tab) => pageKey(tab.url) === '/foryou') ||
    tabs.find((tab) => pageKey(tab.url) === '/home') ||
    tabs[tabs.length - 1]
  );
}

// Keep the user's removals/ticks for this feed across recaptures; a story
// that is gone from the feed no longer needs to be remembered.
function carriedOver(kind, items) {
  const previous = pageFor(kind);
  if (!previous) return { removed: [], unchecked: [] };
  const present = new Set(items.map((item) => item.url));
  return {
    removed: previous.removed.filter((url) => present.has(url)),
    unchecked: previous.unchecked.filter((url) => present.has(url)),
  };
}

async function capture(tabId, { deep = false, target = 0, maxRounds } = {}) {
  if (busy) return false;
  busy = true;
  updatePullButton();
  setStatus(deep ? '正在自动下拉加载…' : '正在抓取当前页面…');

  try {
    let payload;

    if (deep) {
      const loaded = await deepLoad(tabId, {
        target,
        maxRounds,
        onProgress: (n) =>
          setStatus(
            target
              ? `正在自动下拉… 已取 ${n}/${target} 条`
              : `正在自动下拉… 已取 ${n} 条`
          ),
      });
      payload = loaded.payload;
      if (payload && Array.isArray(payload.items)) {
        payload.items = loaded.items;
      }
    } else {
      payload = await extract(tabId);

      // The feed is lazy; one quiet retry usually picks up the rest.
      if (!payload || !payload.items || !payload.items.length) {
        await sleep(900);
        payload = await extract(tabId);
      }
    }

    if (!payload || !Array.isArray(payload.items)) {
      throw new Error('页面没有返回结果');
    }

    const kind = payload.pageKind || 'other';
    const previous = pageFor(kind);

    // A loaded-but-empty feed should not wipe what we already have.
    if (!payload.items.length && previous && previous.items.length) {
      currentKind = kind;
      store.lastKind = kind;
      saveStore();
      setStatus('这次没有抓到新内容，仍然显示上次抓取的结果。');
      render();
      return true;
    }

    const carry = carriedOver(kind, payload.items);
    store.pages[kind] = {
      pageKind: kind,
      pageLabel: payload.pageLabel || '',
      pageUrl: payload.pageUrl || '',
      capturedAt: Date.now(),
      items: payload.items,
      removed: carry.removed,
      unchecked: carry.unchecked,
    };
    store.lastKind = kind;
    currentKind = kind;

    filterText = '';
    if ($('search')) $('search').value = '';

    saveStore();
    setStatus('');
    render();
    return true;
  } catch (err) {
    console.error(err);
    setStatus('');

    const fallbackKind =
      store.lastKind && store.pages[store.lastKind]
        ? store.lastKind
        : Object.keys(store.pages)[0];

    if (fallbackKind) {
      currentKind = fallbackKind;
      setStatus('抓取失败，显示上次抓取的结果。');
      render();
      return false;
    }

    showMessage(
      '抓取失败',
      '请确认当前标签页是 news.google.com 且页面已经加载完成，然后再点一次 ↻。\n' +
        (err && err.message ? err.message : String(err))
    );
    return false;
  } finally {
    busy = false;
    updatePullButton();
  }
}

function tabKindFromUrl(url) {
  const path = pageKey(url);
  if (/^\/foryou(\/|$)/.test(path)) return 'foryou';
  if (path === '/' || path === '/home') return 'home';
  if (/^\/following(\/|$)/.test(path)) return 'following';
  return 'other';
}

async function findTabForKind(kind) {
  const tabs = await chrome.tabs.query({ url: 'https://news.google.com/*' });
  if (!tabs || !tabs.length) return null;

  const matches = tabs.filter((tab) => tabKindFromUrl(tab.url) === kind);
  matches.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return matches[0] || null;
}

async function refresh(deep, opts = {}) {
  const wantKind = opts.kind || currentKind || store.lastKind || '';
  const target =
    opts.target != null
      ? opts.target
      : wantKind === 'foryou'
        ? store.foryouLimit || 30
        : 0;

  if (IS_VIEWER) {
    const tab =
      (wantKind && (await findTabForKind(wantKind))) || (await findNewsTab());
    if (!tab) {
      showMessage(
        '没有找到 Google News 标签页',
        '请先在浏览器里打开 Google News 的 For you 页面，再回来抓取。',
        { label: '打开 For you 页面', href: NEWS_URL }
      );
      return;
    }
    await capture(tab.id, { deep, target });
    return;
  }

  const tab = await activeTab();
  if (!tab || !isNewsUrl(tab.url)) {
    // Deep-pull can still work on the list's own tab while another tab is active.
    if (deep && wantKind) {
      const other = await findTabForKind(wantKind);
      if (other) {
        await capture(other.id, { deep, target });
        return;
      }
    }
    showNotNews();
    return;
  }
  await capture(tab.id, { deep, target });
}

// The per-list "pull" button: always acts on that list's own page, not on
// whatever tab happens to be in front.
async function pullFor(kind) {
  if (busy) return;
  const target = kind === 'foryou' ? store.foryouLimit || 30 : 0;
  const tab = await findTabForKind(kind);

  if (!tab) {
    const active = await activeTab();
    const activeKind =
      active && isNewsUrl(active.url) ? tabKindFromUrl(active.url) : '';

    // Never let the Home pull overwrite the For you list (or vice versa).
    if (!activeKind || activeKind !== kind) {
      showMessage(
        `「${kindLabel(kind)}」页面没有打开`,
        `下拉抓取只会操作这一份清单自己的 Google News 页面。请先打开${kindLabel(kind)}页面，再点一次。`,
        {
          label: kind === 'home' ? '打开首页' : '打开 For you 页面',
          href:
            kind === 'home'
              ? 'https://news.google.com/home?hl=en-GB&gl=GB&ceid=GB:en'
              : NEWS_URL,
        }
      );
      return;
    }
    await capture(active.id, { deep: true, target });
    return;
  }

  await capture(tab.id, { deep: true, target });
}

/* ---------------- rendering ---------------- */

function setStatus(text) {
  const node = $('status');
  if (!node) return;
  node.textContent = text || '';
  node.hidden = !text;
}

function renderTabs() {
  const bar = $('pageTabs');
  if (!bar) return;

  const kinds = availableKinds();
  bar.textContent = '';
  bar.hidden = kinds.length < 2;

  for (const kind of kinds) {
    const page = pageFor(kind);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'page-tab' + (kind === currentKind ? ' active' : '');
    button.dataset.kind = kind;

    const label = document.createElement('span');
    label.textContent = kindLabel(kind, page);
    button.append(label);

    const count = document.createElement('span');
    count.className = 'n';
    count.textContent = String(visibleItems(page).length);
    button.append(count);

    if (kind === currentKind) button.setAttribute('aria-current', 'true');
    button.addEventListener('click', () => {
      if (kind === currentKind) return;
      currentKind = kind;
      store.lastKind = kind;
      filterText = '';
      if ($('search')) $('search').value = '';
      saveStore();
      render();
    });

    bar.append(button);
  }
}

function renderFeedBar() {
  const bar = $('limitBar');
  if (!bar) return;

  const page = currentPage();
  const show = Boolean(page && page.items.length);
  bar.hidden = !show;
  if (!show) return;

  bar.classList.toggle('no-limit', page.pageKind !== 'foryou');

  for (const button of bar.querySelectorAll('button[data-limit]')) {
    const value = Number(button.dataset.limit);
    const active = value === store.foryouLimit;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', active ? 'true' : 'false');
  }

  updatePullButton();
}

function updatePullButton() {
  const button = $('pull');
  if (!button) return;
  const page = currentPage();
  if (!page) {
    button.hidden = true;
    return;
  }
  button.hidden = false;
  button.disabled = busy;
  if (page.pageKind === 'foryou') {
    button.textContent = busy ? '下拉中…' : `⇣ 下拉抓取到 ${store.foryouLimit || 30} 条`;
  } else {
    button.textContent = busy ? '下拉中…' : '⇣ 下拉抓取更多';
  }
}

function renderRow(item, page) {
  const row = document.createElement('div');
  row.className = 'row';

  const checked = !page.unchecked.includes(item.url);
  if (!checked) row.classList.add('off');

  const check = document.createElement('input');
  check.type = 'checkbox';
  check.className = 'check';
  check.checked = checked;
  check.setAttribute('aria-label', '是否复制这条链接');

  const finishToggle = () => {
    const set = new Set(page.unchecked);
    if (check.checked) set.delete(item.url);
    else set.add(item.url);
    page.unchecked = [...set];
    row.classList.toggle('off', !check.checked);
    saveStore();
    updateChrome();
  };
  check.addEventListener('change', finishToggle);

  const main = document.createElement('div');
  main.className = 'row-main';

  const title = document.createElement('div');
  title.className = 'row-title';
  title.textContent = item.title;
  title.title = item.title;
  main.append(title);

  const finalUrl = finalUrlFor(item);
  const link = document.createElement('a');
  link.className = 'row-url';
  link.href = finalUrl || item.url;
  link.target = '_blank';
  link.rel = 'noreferrer';
  link.textContent = finalUrl || item.url;
  link.title = finalUrl ? '媒体原始链接 · ' + finalUrl : item.url;
  main.append(link);

  const metaText = [item.source, item.time].filter(Boolean).join(' · ');
  if (metaText) {
    const meta = document.createElement('div');
    meta.className = 'row-meta';
    meta.textContent = metaText;
    main.append(meta);
  }

  const del = document.createElement('button');
  del.type = 'button';
  del.className = 'row-del';
  del.title = '删除这条';
  del.setAttribute('aria-label', '删除这条');
  del.textContent = '×';
  del.addEventListener('click', (event) => {
    event.stopPropagation();
    removeItem(item, page);
  });

  row.append(check, main, del);

  row.addEventListener('click', (event) => {
    if (event.target.closest('a, button, input')) return;
    check.checked = !check.checked;
    finishToggle();
  });

  return row;
}

function messageBox(title, body, action) {
  const box = document.createElement('div');
  box.className = 'empty';

  const heading = document.createElement('strong');
  heading.textContent = title;
  box.append(heading);

  if (body) {
    const text = document.createElement('div');
    text.textContent = body;
    box.append(text);
  }

  if (action) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn';
    button.style.marginTop = '14px';
    button.textContent = action.label;
    button.addEventListener('click', () => {
      if (action.href) chrome.tabs.create({ url: action.href });
      else if (action.onClick) action.onClick();
    });
    box.append(button);
  }

  return box;
}

function showMessage(title, body, action) {
  const list = $('list');
  if (!list) return;
  list.textContent = '';
  list.append(messageBox(title, body, action));
  renderTabs();
  updateChrome();
}

function showNotNews() {
  showMessage(
    '请先打开 Google News',
    '在 Google News 的 For you 页面点击工具栏里的插件图标，就能抓取当前页面。',
    { label: '打开 For you 页面', href: NEWS_URL }
  );
}

function render() {
  const list = $('list');
  if (!list) return;
  list.textContent = '';

  const page = currentPage();
  const visible = visibleItems(page);
  const query = filterText.trim().toLowerCase();
  const shown = query
    ? visible.filter((item) =>
        (item.title + ' ' + item.url + ' ' + (item.source || ''))
          .toLowerCase()
          .includes(query)
      )
    : visible;

  if (!page || !page.items.length) {
    list.append(
      messageBox(
        '没有抓到文章链接',
        '页面可能还没加载完，稍等片刻后点右上角 ↻ 重新抓取。',
        { label: '重新抓取', onClick: () => refresh(false) }
      )
    );
    renderTabs();
    updateChrome();
    return;
  }

  if (!shown.length) {
    if (query) {
      list.append(messageBox('没有匹配的条目', '换个关键词试试，或清空筛选框。'));
    } else {
      list.append(
        messageBox('这一页的条目都被删除了', '点底部“恢复删除”可以把它们找回来。')
      );
    }
    renderTabs();
    updateChrome();
    return;
  }

  const fragment = document.createDocumentFragment();
  for (const item of shown) fragment.append(renderRow(item, page));
  list.append(fragment);

  renderTabs();
  updateChrome();
}

function updateChrome() {
  const page = currentPage();
  const visible = visibleItems(page);
  const selected = selectedItems(page);

  const badge = $('count');
  if (badge) badge.textContent = String(selected.length);

  const copy = $('copy');
  if (copy) {
    const label = page ? kindLabel(page.pageKind, page) : '';
    copy.textContent = selected.length
      ? `复制「${label}」链接 (${selected.length})`
      : '复制已选链接';
    copy.disabled = selected.length === 0;
  }

  const selectAll = $('selectAll');
  if (selectAll) {
    const allSelected =
      visible.length > 0 &&
      visible.every((item) => !page.unchecked.includes(item.url));
    selectAll.textContent = allSelected ? '取消全选' : '全选';
    selectAll.disabled = visible.length === 0;
  }

  const restore = $('restore');
  if (restore) {
    const removed = page ? page.removed.length : 0;
    restore.hidden = removed === 0;
    restore.textContent = `恢复删除 (${removed})`;
  }

  const info = $('selectionInfo');
  if (info) {
    info.textContent =
      page && visible.length
        ? `${kindLabel(page.pageKind, page)} · 共 ${visible.length} 条 · 已选 ${selected.length} 条`
        : '';
  }

  const resolveToggle = $('resolveLink');
  if (resolveToggle) resolveToggle.checked = store.settings.resolveLinks;

  renderFeedBar();

  const meta = $('meta');
  if (meta) {
    if (!page) {
      meta.textContent = '';
    } else {
      const parts = [kindLabel(page.pageKind, page)];
      const path = pageKey(page.pageUrl);
      if (path && path !== '/foryou' && path !== '/home') parts.push(path);
      if (page.capturedAt) {
        parts.push(
          '抓取于 ' +
            new Date(page.capturedAt).toLocaleTimeString('zh-CN', {
              hour: '2-digit',
              minute: '2-digit',
            })
        );
      }
      if (visible.length) parts.push(`${visible.length} 条`);
      if (page.removed.length) parts.push(`已删除 ${page.removed.length}`);
      meta.textContent = parts.join(' · ');
    }
  }
}

/* ---------------- actions ---------------- */

function removeItem(item, page) {
  if (!page.removed.includes(item.url)) {
    page.removed.push(item.url);
    saveStore();
  }
  render();
}

function restoreRemoved() {
  const page = currentPage();
  if (!page) return;
  page.removed = [];
  saveStore();
  render();
}

function toggleSelectAll() {
  const page = currentPage();
  if (!page) return;
  const visible = visibleItems(page);
  const allSelected =
    visible.length > 0 &&
    visible.every((item) => !page.unchecked.includes(item.url));
  page.unchecked = allSelected ? visible.map((item) => item.url) : [];
  saveStore();
  render();
}

function fallbackCopy(text) {
  const area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0;';
  document.body.append(area);
  area.select();
  document.execCommand('copy');
  area.remove();
}

async function copySelected() {
  const items = selectedItems();
  if (!items.length) {
    toast('没有可复制的链接');
    return;
  }

  let urls = items.map((item) => item.url);

  if (store.settings.resolveLinks) {
    busy = true;
    updatePullButton();
    let resolveError = '';
    try {
      const result = await resolveAll(items, (done, total) =>
        setStatus(`正在解析媒体原始链接… ${done}/${total}`)
      );
      urls = result.urls;
      resolveError = result.error;
      saveResolved();
      render();
    } finally {
      busy = false;
      updatePullButton();
      setStatus(resolveError ? `解析失败：${resolveError}` : '');
    }
  }

  const text = urls.join('\n');
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    fallbackCopy(text);
  }

  const resolved = urls.filter((url) => !isNewsUrl(url)).length;
  toast(
    store.settings.resolveLinks
      ? `已复制 ${urls.length} 条（其中 ${resolved} 条为媒体原始链接）`
      : `已复制 ${urls.length} 条链接`
  );
}

function toast(message) {
  const node = $('toast');
  if (!node) return;
  node.textContent = message;
  node.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    node.hidden = true;
  }, 2200);
}

function openViewer() {
  chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html') });
  if (!IS_VIEWER) window.close();
}

/* ---------------- init ---------------- */

function pickInitialKind() {
  if (store.lastKind && store.pages[store.lastKind]) return store.lastKind;
  const kinds = availableKinds();
  return kinds[0] || '';
}

async function initPopup() {
  await loadResolved();
  const tab = await activeTab();
  if (!tab || !isNewsUrl(tab.url)) {
    await loadStore();
    currentKind = pickInitialKind();
    if (currentKind) {
      render();
      setStatus('当前标签页不是 Google News，显示上次抓取的结果。');
    } else {
      showNotNews();
    }
    return;
  }

  await loadStore();
  currentKind = pickInitialKind();
  const ok = await capture(tab.id, { deep: false });

  // For you is a short window onto a long feed: fill it up to the chosen size
  // without making the user scroll the page themselves.
  const page = currentPage();
  if (ok && page && page.pageKind === 'foryou') {
    const have = page.items.length;
    const want = store.foryouLimit || 30;
    // Short automatic top-up on open; the pull button can go further.
    if (have < want) {
      await capture(tab.id, { deep: true, target: want, maxRounds: 12 });
    }
  }
}

async function initViewer() {
  await loadStore();
  await loadResolved();
  currentKind = pickInitialKind();
  if (currentKind) {
    render();
  } else {
    showMessage(
      '还没有抓取数据',
      '先打开 Google News 的 For you 页面，或直接点下面的按钮抓取已打开的 Google News 标签页。',
      {
        label: '抓取已打开的 Google News 标签页',
        onClick: () => refresh(false),
      }
    );
  }
}

function bindEvents() {
  $('refresh')?.addEventListener('click', () => refresh(false));
  $('deep')?.addEventListener('click', () => refresh(true));
  $('pull')?.addEventListener('click', () => pullFor(currentKind));
  $('copy')?.addEventListener('click', copySelected);
  $('resolveLink')?.addEventListener('change', (event) => {
    store.settings.resolveLinks = Boolean(event.target.checked);
    saveStore();
  });
  $('selectAll')?.addEventListener('click', toggleSelectAll);
  $('restore')?.addEventListener('click', restoreRemoved);
  $('openViewer')?.addEventListener('click', openViewer);
  $('search')?.addEventListener('input', (event) => {
    filterText = event.target.value;
    render();
  });
  $('limitBar')?.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-limit]');
    if (!button) return;
    const value = Number(button.dataset.limit);
    if (!FORYOU_LIMITS.includes(value) || value === store.foryouLimit) return;
    store.foryouLimit = value;
    saveStore();
    render();

    // Ask for 50 but only 30 are loaded? Pull the rest in.
    const page = currentPage();
    if (page && page.items.length < value) pullFor('foryou');
  });
}

function init() {
  bindEvents();
  const start = IS_VIEWER ? initViewer : initPopup;
  start().catch((err) => {
    console.error(err);
    showMessage('初始化失败', err && err.message ? err.message : String(err));
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
