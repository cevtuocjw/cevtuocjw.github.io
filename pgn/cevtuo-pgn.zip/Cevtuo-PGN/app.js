'use strict';

const core = globalThis.__CEVTUO_PGN_CORE_V2__;
if (!core) throw new Error('Cevtuo-PGN 初始化失败：core.js 未加载');

const STORE_KEY = 'pgnStore';
const LEGACY_STORE_KEY = 'gnStore';
const RESOLVED_KEY = 'pgnResolved';
const LEGACY_RESOLVED_KEY = 'gnResolved';
const NEWS_URL = 'https://news.google.com/foryou?hl=en-GB&gl=GB&ceid=GB:en';
const KIND_ORDER = ['home', 'foryou', 'following', 'other'];
const GOOGLE_KINDS = new Set(KIND_ORDER);
const LIMITS = [20, 30, 50, 100, 'all'];

const IS_VIEWER = document.body.dataset.mode === 'viewer';
const $ = (id) => document.getElementById(id);

const emptyPage = (kind = '') => ({
  pageKind: kind,
  pageLabel: '',
  pageUrl: '',
  capturedAt: 0,
  items: [],
  removed: [],
  unchecked: [],
});

const defaultStore = () => ({
  pages: {},
  lastKind: '',
  grabLimit: 30,
  tabOrder: [],
  settings: { resolveLinks: true },
});

let store = defaultStore();
let currentKind = '';
let filterText = '';
let busy = false;
let toastTimer = 0;
// token -> publisher URL, so a link is resolved at most once.
let resolveCache = {};

/* ---------------- data ---------------- */

function normalizeLimit(value) {
  if (value === 'all' || value === -1) return 'all';
  const number = Number(value);
  return LIMITS.includes(number) ? number : 30;
}

function pageFor(kind) {
  return (kind && store.pages[kind]) || null;
}

function currentPage() {
  return pageFor(currentKind);
}

function isGoogleNewsUrl(url) {
  try {
    return core.isGoogleNewsHost(new URL(url).hostname);
  } catch {
    return false;
  }
}

function pageLocation(url) {
  try {
    const u = new URL(url);
    const path = u.pathname.replace(/\/+$/, '');
    return core.stripWww(u.hostname) + (path && path !== '/' ? path : '');
  } catch {
    return '';
  }
}

function kindLabel(kind, page) {
  if (kind === 'home') return 'GNews 首页';
  if (kind === 'foryou') return 'GNews For you';
  if (kind === 'following') return 'GNews Following';
  if (kind === 'other') return (page && page.pageLabel) || 'GNews';
  return (page && page.pageLabel) || kind.replace(/^site:/, '') || '其他页面';
}

function rememberKind(kind) {
  if (!kind) return;
  if (!store.tabOrder.includes(kind)) store.tabOrder.push(kind);
}

function availableKinds() {
  const hasPage = (kind) => Boolean(store.pages[kind]);
  const ordered = [];

  for (const kind of store.tabOrder) {
    if (hasPage(kind) && !ordered.includes(kind)) ordered.push(kind);
  }
  for (const kind of KIND_ORDER) {
    if (hasPage(kind) && !ordered.includes(kind)) ordered.push(kind);
  }
  for (const kind of Object.keys(store.pages)) {
    if (hasPage(kind) && !ordered.includes(kind)) ordered.push(kind);
  }
  if (currentKind && hasPage(currentKind) && !ordered.includes(currentKind)) {
    ordered.push(currentKind);
  }

  return ordered;
}

function visibleItems(page = currentPage()) {
  if (!page) return [];
  const removed = new Set(page.removed);
  let items = page.items.filter((item) => !removed.has(item.url));
  // For you is a window onto a long feed, so the chosen number is also the
  // display cap. A generic site page keeps everything it has collected: the
  // number there means "pull until at least this many", and the extra items
  // would otherwise disappear after an overshooting scroll round.
  if (page.pageKind === 'foryou' && store.grabLimit !== 'all') {
    items = items.slice(0, store.grabLimit);
  }
  return items;
}

function selectedItems(page = currentPage()) {
  if (!page) return [];
  const unchecked = new Set(page.unchecked);
  return visibleItems(page).filter((item) => !unchecked.has(item.url));
}

async function loadStore() {
  try {
    const data = await chrome.storage.local.get([STORE_KEY, LEGACY_STORE_KEY]);
    const saved = data && (data[STORE_KEY] || data[LEGACY_STORE_KEY]);
    store = defaultStore();
    if (!saved || !saved.pages || typeof saved.pages !== 'object') return;

    store.lastKind = saved.lastKind || '';
    store.grabLimit = normalizeLimit(
      saved.grabLimit != null ? saved.grabLimit : saved.foryouLimit
    );
    store.tabOrder = Array.isArray(saved.tabOrder)
      ? saved.tabOrder.filter((kind) => typeof kind === 'string')
      : [];
    store.settings = {
      resolveLinks: !saved.settings || saved.settings.resolveLinks !== false,
    };

    for (const [kind, savedPage] of Object.entries(saved.pages)) {
      if (!savedPage || !Array.isArray(savedPage.items)) continue;
      store.pages[kind] = {
        ...emptyPage(kind),
        ...savedPage,
        pageKind: savedPage.pageKind || kind,
        removed: Array.isArray(savedPage.removed) ? savedPage.removed : [],
        unchecked: Array.isArray(savedPage.unchecked) ? savedPage.unchecked : [],
      };
      if (!store.tabOrder.includes(kind)) store.tabOrder.push(kind);
    }
  } catch (err) {
    console.error('读取缓存失败', err);
  }
}

function saveStore() {
  chrome.storage.local.set({ [STORE_KEY]: store }).catch((err) => {
    console.error('保存失败', err);
  });
}

/* ---------------- publisher URLs ----------------
 * Google News /read/<token> is an opaque redirect. The token alone is not
 * enough: the page carries a per-article signature that must be sent to
 * Google's own batchexecute endpoint to get the publisher URL. So resolving
 * costs one page fetch (~570 KB) per new article, then the POST. Results are
 * cached by token, so each article is resolved at most once.
 */

function articleToken(url) {
  const m = (url || '').match(/\/(?:read|rss\/articles|articles)\/([^/?#]+)/);
  return m ? m[1] : '';
}

function finalUrlFor(item) {
  const token = articleToken(item.url);
  return (token && resolveCache[token]) || '';
}

// Runs inside the Google News tab: same-origin requests, so Google sees an
// ordinary page request instead of a chrome-extension:// origin (which its
// batchexecute endpoint rejects with HTTP 400).
async function pageResolveTokens(tokens) {
  const out = {};
  const queue = (tokens || []).slice();

  const worker = async () => {
    while (queue.length) {
      const token = queue.shift();
      if (!token) continue;
      try {
        const page = await fetch(
          '/rss/articles/' + token + '?hl=en-GB&gl=GB&ceid=GB:en',
          { credentials: 'include' }
        );
        if (!page.ok) continue;
        const html = await page.text();

        const sg = (html.match(/data-n-a-sg="([^"]+)"/) || [])[1];
        const ts = (html.match(/data-n-a-ts="([^"]+)"/) || [])[1];
        if (!sg || !ts) continue;

        const inner =
          '["garturlreq",[["X","X",["X","X"],null,null,1,1,"GB:en",null,1,null,null,null,null,null,0,1],' +
          '"X","X",1,[1,1,1],1,1,null,0,0,null,0],"' +
          token +
          '",' +
          ts +
          ',"' +
          sg +
          '"]';
        const body =
          'f.req=' + encodeURIComponent(JSON.stringify([[['Fbv4je', inner]]]));

        const res = await fetch(
          '/_/DotsSplashUi/data/batchexecute?rpcids=Fbv4je',
          {
            method: 'POST',
            headers: {
              'content-type': 'application/x-www-form-urlencoded;charset=UTF-8',
            },
            body,
            credentials: 'include',
          }
        );
        if (!res.ok) continue;
        const text = await res.text();
        const hit = text.match(/https?:\/\/[^"\\\s]+/);
        if (hit) out[token] = hit[0].replace(/\\\//g, '/');
      } catch (err) {
        // One bad article must not stop the rest.
      }
    }
  };

  await Promise.all(
    Array.from({ length: Math.min(4, queue.length) }, worker)
  );
  return out;
}

// The resolver must run inside a Google News tab: Google's batchexecute
// endpoint rejects a chrome-extension:// origin. Prefer the list's own tab,
// then any Google News tab, then the active tab (the popup's activeTab grant
// still covers it while the popup is open).
async function resolverTab() {
  let tab = GOOGLE_KINDS.has(currentKind)
    ? await findTabForKind(currentKind)
    : null;
  if (!tab) tab = await findNewsTab();
  if (!tab) {
    const active = await activeTab();
    if (active && isGoogleNewsUrl(active.url)) tab = active;
  }
  if (tab && tab.discarded) {
    const tabs = await chrome.tabs.query({});
    const live = (tabs || []).find(
      (candidate) => isGoogleNewsUrl(candidate.url) && !candidate.discarded
    );
    if (live) tab = live;
  }
  return tab;
}

async function resolveAll(items, onProgress) {
  const out = items.map((item) => finalUrlFor(item) || item.url);
  const pending = [];

  items.forEach((item, index) => {
    if (out[index] && out[index] !== item.url) return;
    const token = articleToken(item.url);
    if (!token) return;
    if (resolveCache[token]) {
      out[index] = resolveCache[token];
      return;
    }
    pending.push({ token, index });
  });

  if (!pending.length) return { urls: out, error: '' };

  const tab = await resolverTab();
  if (!tab) {
    return {
      urls: out,
      error: '需要先打开一个 Google News 页面（并保持标签页未休眠）',
    };
  }

  let done = 0;
  let error = '';
  const chunk = 4;

  for (let i = 0; i < pending.length; i += chunk) {
    const group = pending.slice(i, i + chunk);
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: pageResolveTokens,
        args: [group.map((entry) => entry.token)],
      });
      const map = (results && results[0] && results[0].result) || {};
      let resolvedHere = 0;
      for (const entry of group) {
        if (map[entry.token]) {
          out[entry.index] = map[entry.token];
          resolveCache[entry.token] = map[entry.token];
          resolvedHere += 1;
        }
      }
      if (!resolvedHere && !error) {
        error = 'Google News 没有返回原文地址，请刷新 Google News 标签页后重试';
      }
    } catch (err) {
      if (!error) error = String((err && err.message) || err).slice(0, 80);
    }
    done += group.length;
    if (onProgress) onProgress(done, pending.length);
  }

  return { urls: out, error };
}

async function loadResolved() {
  try {
    const data = await chrome.storage.local.get([
      RESOLVED_KEY,
      LEGACY_RESOLVED_KEY,
    ]);
    const saved = data && (data[RESOLVED_KEY] || data[LEGACY_RESOLVED_KEY]);
    if (saved && typeof saved === 'object') resolveCache = saved;
  } catch (err) {
    console.error('读取链接缓存失败', err);
  }
}

function saveResolved() {
  const tokens = Object.keys(resolveCache);
  if (tokens.length > 600) {
    for (const token of tokens.slice(0, tokens.length - 600)) {
      delete resolveCache[token];
    }
  }
  chrome.storage.local.set({ [RESOLVED_KEY]: resolveCache }).catch(() => {});
}

/* ---------------- capture ---------------- */

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function extract(tabId) {
  // Two injections, in order: core.js must finish before extractor.js reads
  // globalThis.__CEVTUO_PGN_CORE_V2__. Keeping them as separate calls also
  // avoids depending on which file's completion value a multi-file injection
  // returns.
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['core.js'],
  });
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    files: ['extractor.js'],
  });
  return results && results[0] ? results[0].result : null;
}

/* ---------------- deep loading ----------------
 * "Pull" means: read the page, scroll a screen, read again, merge. Google News
 * advances with the document itself. Generic sites usually lazy-load at the
 * bottom, so scrolling all the way down is the trigger; a few also hide the
 * rest behind a "Load more" button.
 */

// Runs in the page. Google News' feed advances with the document itself
// (PageDown works), so scroll the window - picking a nested "tallest" element
// proved unreliable because some wrappers are taller than the viewport but do
// not move the feed.
function scrollFeedStep(factor) {
  const dy = Math.round((window.innerHeight || 800) * factor);
  const before = window.scrollY;
  window.scrollBy(0, dy);

  // At the bottom, scrollBy is a no-op and Google News may never see a scroll
  // event - which is its signal to append the next feed screen. Nudge up and
  // back down to generate real scroll events without moving the view for long.
  if (window.scrollY === before) {
    const nudge = Math.round((window.innerHeight || 800) * 0.25);
    window.scrollBy(0, -nudge);
    window.scrollBy(0, nudge);
    window.dispatchEvent(new Event('scroll', { bubbles: true }));
  }

  return {
    moved: Math.round(window.scrollY - before),
    height: Math.round(document.documentElement.scrollHeight),
    top: Math.round(window.scrollY),
  };
}

// Runs in the page. Most news sites scroll the document; if it does not move,
// fall back to the tallest element that actually overflows the viewport.
function scrollPageStep() {
  const root = document.scrollingElement || document.documentElement;
  let target = root;

  if (root.scrollHeight <= window.innerHeight + 40) {
    let best = 0;
    const candidates = document.querySelectorAll('main, [role="main"], div');
    for (const el of candidates) {
      if (el.clientHeight < window.innerHeight * 0.5) continue;
      if (el.scrollHeight <= el.clientHeight + 200) continue;
      if (el.scrollHeight > best) {
        best = el.scrollHeight;
        target = el;
      }
    }
  }

  const before = target.scrollTop;
  target.scrollTop = target.scrollHeight;

  return {
    moved: Math.round(target.scrollTop - before),
    height: Math.round(target.scrollHeight),
    top: Math.round(target.scrollTop),
  };
}

// Runs in the page. Only buttons, never links: clicking a link could navigate
// away from the list we are reading.
function clickLoadMore() {
  const pattern =
    /^(?:load|show|view|see|display|reveal)\s+more\b|^more\s+(?:stories|articles|news|headlines|results)\b|加载更多|显示更多|查看更多|点击加载/i;
  const buttons = document.querySelectorAll('button, [role="button"]');

  for (const button of buttons) {
    const text = (button.innerText || button.getAttribute('aria-label') || '')
      .replace(/\s+/g, ' ')
      .trim();
    if (!text || text.length > 40 || !pattern.test(text)) continue;
    if (button.disabled || button.getAttribute('aria-disabled') === 'true') continue;
    // "Show more" inside a single article usually expands its summary; only
    // allow it when the label clearly means more stories.
    if (
      button.closest('article') &&
      !/load more|more (?:stories|articles|news|headlines|results)|加载更多|查看更多/i.test(text)
    ) {
      continue;
    }
    const rect = button.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) continue;
    button.click();
    return text;
  }
  return '';
}

async function deepLoad(
  tabId,
  { target = 0, seed = [], generic = false, onProgress, maxRounds: roundCap } = {}
) {
  const run = (func, args) =>
    chrome.scripting.executeScript({ target: { tabId }, func, args });

  const [{ result: startTop } = { result: 0 }] = await run(() => {
    const root = document.scrollingElement || document.documentElement;
    return root.scrollTop;
  });

  // Start from the top even if the user was reading halfway down, otherwise
  // the first screens of the page would never be read. The original position
  // is restored in the finally block.
  await run(() => {
    const root = document.scrollingElement || document.documentElement;
    root.scrollTo(0, 0);
  }).catch(() => {});
  await sleep(250);

  const merged = seed.slice();
  const additions = [];
  let payload = null;
  let lastHeight = 0;
  let quiet = 0;
  const allMode = !target;
  const maxRounds =
    roundCap ||
    (generic ? (allMode ? 120 : 80) : allMode ? 45 : 15);
  const deadline =
    Date.now() + (generic ? (allMode ? 180000 : 120000) : allMode ? 120000 : 90000);
  // Google News lazy-loads the next feed screen a few seconds after reaching
  // the bottom; on a slower connection the public Home feed has taken ~11s.
  // Three quiet rounds (the old rule) stopped before that batch appeared,
  // leaving the user at the initial ~22 items. Give Google News eight.
  const quietLimit = generic ? 3 : 8;

  try {
    for (let round = 0; round < maxRounds; round++) {
      if (Date.now() > deadline) break;

      const snapshot = await extract(tabId);
      if (!snapshot || !Array.isArray(snapshot.items)) break;

      payload = snapshot;
      const before = merged.length;
      core.mergeItems(merged, snapshot.items);
      for (let i = before; i < merged.length; i++) additions.push(merged[i]);
      if (onProgress) onProgress(merged.length);

      const height = snapshot.pageHeight || 0;
      // Only a screen with no new story AND no new page height means the end.
      // Several quiet rounds are required because lazy loading can lag behind
      // the scroll event by a second or two.
      const grew = merged.length > before || height > lastHeight + 40;
      if (!grew) quiet += 1;
      else quiet = 0;
      lastHeight = Math.max(lastHeight, height);

      if (round > 0 && quiet >= quietLimit) break;
      if (target && merged.length >= target) break;

      if (generic) {
        await run(scrollPageStep).catch(() => {});
        await run(clickLoadMore).catch(() => {});
      } else {
        await run(scrollFeedStep, [0.9]).catch(() => {});
      }
      await sleep(generic ? 1300 : 1400);
    }
  } finally {
    // Leave the user's page where they were reading.
    await run((y) => {
      const root = document.scrollingElement || document.documentElement;
      root.scrollTo(0, y);
    }, [startTop]).catch(() => {});
  }

  return { items: merged, additions, payload };
}

async function activeTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs[0];
}

function tabKindFromUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return '';
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return '';

  if (core.isGoogleNewsHost(parsed.hostname)) {
    const path = parsed.pathname.replace(/\/+$/, '');
    if (/^\/foryou(\/|$)/.test(path)) return 'foryou';
    if (path === '' || path === '/home') return 'home';
    if (/^\/following(\/|$)/.test(path)) return 'following';
    return 'other';
  }

  return 'site:' + core.siteKey(parsed.hostname);
}

function isSupportedUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

async function findTabForKind(kind) {
  const tabs = await chrome.tabs.query({});
  const matches = (tabs || []).filter((tab) => tabKindFromUrl(tab.url) === kind);
  matches.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return matches[0] || null;
}

async function findNewsTab() {
  const tabs = await chrome.tabs.query({});
  const news = (tabs || []).filter((tab) => isGoogleNewsUrl(tab.url));
  if (!news.length) return null;
  return (
    news.find((tab) => pageLocation(tab.url) === 'news.google.com/foryou') ||
    news.find((tab) => pageLocation(tab.url) === 'news.google.com/home') ||
    news[news.length - 1]
  );
}

// Keep the user's removals/ticks for this list across recaptures; an item
// that is gone from the list no longer needs to be remembered.
function carriedOver(kind, items) {
  const previous = pageFor(kind);
  if (!previous) return { removed: [], unchecked: [] };
  const present = new Set(items.map((item) => item.url));
  return {
    removed: previous.removed.filter((url) => present.has(url)),
    unchecked: previous.unchecked.filter((url) => present.has(url)),
  };
}

async function capture(
  tabId,
  { deep = false, target = 0, maxRounds, tabUrl = '' } = {}
) {
  if (busy) return false;
  busy = true;
  updatePullButton();
  setStatus(deep ? '正在自动下拉加载…' : '正在抓取当前页面…');

  try {
    const kindHint = tabUrl ? tabKindFromUrl(tabUrl) : '';
    const isGeneric = kindHint.startsWith('site:');
    const previous = kindHint ? pageFor(kindHint) : null;
    let payload;

    if (deep) {
      const seed = isGeneric && previous ? previous.items : [];
      const want = target || (store.grabLimit === 'all' ? 0 : store.grabLimit);
      const loaded = await deepLoad(tabId, {
        seed,
        target: want,
        generic: isGeneric,
        maxRounds,
        onProgress: (n) =>
          setStatus(
            want
              ? `正在自动下拉… 已取 ${n}/${want} 条`
              : `正在拉到底… 已取 ${n} 条（最多 3 分钟）`
          ),
      });

      if (loaded.payload && Array.isArray(loaded.payload.items)) {
        if (isGeneric) {
          // Current page first, then the older collection. core.mergeItems
          // drops URL/title duplicates, so re-reading a page never doubles it.
          loaded.payload.items = core.mergeItems(
            loaded.additions.slice(),
            previous ? previous.items : []
          );
        } else {
          loaded.payload.items = loaded.items;
        }
        payload = loaded.payload;
      } else if (isGeneric && loaded.additions.length) {
        payload = {
          pageKind: kindHint,
          pageLabel: previous ? previous.pageLabel : '',
          pageUrl: tabUrl,
          pageTitle: '',
          pageHeight: 0,
          mode: 'generic',
          items: core.mergeItems(
            loaded.additions.slice(),
            previous ? previous.items : []
          ),
        };
      }
    } else {
      payload = await extract(tabId);

      // The page may still be lazy-rendering. One quiet retry usually helps.
      if (!payload || !payload.items || !payload.items.length) {
        await sleep(900);
        payload = await extract(tabId);
      }

      if (isGeneric && payload && Array.isArray(payload.items) && previous) {
        payload.items = core.mergeItems(payload.items.slice(), previous.items);
      }
    }

    if (!payload || !Array.isArray(payload.items)) {
      throw new Error('页面没有返回结果');
    }

    const kind = payload.pageKind || kindHint || 'other';
    const previousPage = pageFor(kind);

    // A loaded-but-empty capture should not wipe what we already have.
    if (!payload.items.length && previousPage && previousPage.items.length) {
      currentKind = kind;
      store.lastKind = kind;
      rememberKind(kind);
      saveStore();
      setStatus('这次没有抓到新内容，仍然显示上次抓取的结果。');
      render();
      return true;
    }

    const carry = carriedOver(kind, payload.items);
    store.pages[kind] = {
      pageKind: kind,
      pageLabel:
        payload.pageLabel || (previousPage && previousPage.pageLabel) || '',
      pageUrl: payload.pageUrl || (previousPage && previousPage.pageUrl) || '',
      capturedAt: Date.now(),
      items: payload.items,
      removed: carry.removed,
      unchecked: carry.unchecked,
    };
    store.lastKind = kind;
    rememberKind(kind);
    currentKind = kind;

    filterText = '';
    if ($('search')) $('search').value = '';

    saveStore();
    setStatus('');
    render();
    return true;
  } catch (err) {
    console.error(err);
    setStatus('');

    const fallbackKind =
      store.lastKind && store.pages[store.lastKind]
        ? store.lastKind
        : Object.keys(store.pages)[0];

    if (fallbackKind) {
      currentKind = fallbackKind;
      setStatus('抓取失败，显示上次抓取的结果。');
      render();
      return false;
    }

    showMessage(
      '抓取失败',
      '请确认页面已经加载完成，然后再点一次 ↻。\n' +
        (err && err.message ? err.message : String(err))
    );
    return false;
  } finally {
    busy = false;
    updatePullButton();
  }
}

/* ---------------- actions ---------------- */

function showNoTab(kind) {
  const page = pageFor(kind);
  const action = page && page.pageUrl
    ? { label: '打开上次的页面', href: page.pageUrl }
    : GOOGLE_KINDS.has(kind)
      ? { label: '打开 Google News', href: NEWS_URL }
      : null;

  showMessage(
    `「${kindLabel(kind, page)}」没有打开的标签页`,
    '请先在浏览器里打开这个页面，再回来抓取。',
    action
  );
}

async function refresh(deep, opts = {}) {
  const wantKind = opts.kind || currentKind || store.lastKind || '';
  const target =
    deep && opts.target != null
      ? opts.target
      : deep
        ? store.grabLimit === 'all'
          ? 0
          : store.grabLimit
        : 0;

  if (IS_VIEWER) {
    // With no list selected yet, "抓取当前标签页" must work on any news site,
    // not only on Google News.
    let tab = wantKind ? await findTabForKind(wantKind) : await activeTab();
    if (tab && !isSupportedUrl(tab.url)) tab = null;
    if (!tab && (!wantKind || GOOGLE_KINDS.has(wantKind))) {
      tab = await findNewsTab();
    }
    if (!tab) {
      if (!wantKind) showUnsupported();
      else showNoTab(wantKind);
      return;
    }
    await capture(tab.id, { deep, target, tabUrl: tab.url });
    return;
  }

  const tab = await activeTab();
  if (!tab || !isSupportedUrl(tab.url)) {
    showUnsupported();
    return;
  }
  await capture(tab.id, { deep, target, tabUrl: tab.url });
}

// The per-list "pull" button: always acts on that list's own page, not on
// whatever tab happens to be in front.
async function pullFor(kind) {
  if (busy) return;

  const all = store.grabLimit === 'all';
  const target = all ? 0 : store.grabLimit;
  const page = pageFor(kind);

  if (!all && page && page.items.length >= target) {
    showMessage(
      `已经有 ${page.items.length} 条`,
      `当前清单已经不少于所选的 ${target} 条。要看更多，把「抓取数量」改成 100 或「全部（拉到底）」，再点一次。`,
      {
        label: '拉到底并全选',
        onClick: () => {
          store.grabLimit = 'all';
          saveStore();
          render();
          pullFor(kind);
        },
      }
    );
    return;
  }

  let tab = await findTabForKind(kind);
  if (!tab) {
    const active = await activeTab();
    if (active && tabKindFromUrl(active.url) === kind) tab = active;
  }
  if (!tab) {
    showNoTab(kind);
    return;
  }

  const ok = await capture(tab.id, { deep: true, target, tabUrl: tab.url });
  if (!ok) return;

  const current = pageFor(kind) || currentPage();
  if (all) {
    if (current) {
      current.unchecked = [];
      saveStore();
      render();
      toast(`已拉到底并全选 ${visibleItems(current).length} 条`);
    }
    return;
  }

  // Target not reached usually means the feed ended. Say so instead of
  // leaving the user staring at the same list.
  if (current && current.items.length < target) {
    toast(`已到页面底部，共 ${current.items.length} 条`);
  }
}

/* ---------------- rendering ---------------- */

function setStatus(text) {
  const node = $('status');
  if (!node) return;
  node.textContent = text || '';
  node.hidden = !text;
}

function renderTabs() {
  const bar = $('pageTabs');
  if (!bar) return;

  const kinds = availableKinds();
  bar.textContent = '';
  bar.hidden = kinds.length < 2;

  for (const kind of kinds) {
    const page = pageFor(kind);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'page-tab' + (kind === currentKind ? ' active' : '');
    button.dataset.kind = kind;

    const label = document.createElement('span');
    label.textContent = kindLabel(kind, page);
    button.append(label);

    const count = document.createElement('span');
    count.className = 'n';
    count.textContent = String(visibleItems(page).length);
    button.append(count);

    if (kind === currentKind) button.setAttribute('aria-current', 'true');
    button.addEventListener('click', () => {
      if (kind === currentKind) return;
      currentKind = kind;
      store.lastKind = kind;
      filterText = '';
      if ($('search')) $('search').value = '';
      saveStore();
      render();
    });

    bar.append(button);
  }
}

function renderFeedBar() {
  const bar = $('limitBar');
  if (!bar) return;

  const page = currentPage();
  const show = Boolean(page && page.items.length);
  bar.hidden = !show;
  if (!show) return;

  const select = $('grabLimit');
  if (select) select.value = String(store.grabLimit);
  updatePullButton();
}

function updatePullButton() {
  const button = $('pull');
  if (!button) return;
  const page = currentPage();
  if (!page) {
    button.hidden = true;
    return;
  }
  button.hidden = false;
  button.disabled = busy;
  if (store.grabLimit === 'all') {
    button.textContent = busy ? '拉到底中…' : '⇣ 拉到底并全选';
  } else {
    button.textContent = busy
      ? '抓取中…'
      : `⇣ 抓取到 ${store.grabLimit} 条`;
  }
}

function renderRow(item, page) {
  const row = document.createElement('div');
  row.className = 'row';

  const checked = !page.unchecked.includes(item.url);
  if (!checked) row.classList.add('off');

  const check = document.createElement('input');
  check.type = 'checkbox';
  check.className = 'check';
  check.checked = checked;
  check.setAttribute('aria-label', '是否复制这条链接');

  const finishToggle = () => {
    const set = new Set(page.unchecked);
    if (check.checked) set.delete(item.url);
    else set.add(item.url);
    page.unchecked = [...set];
    row.classList.toggle('off', !check.checked);
    saveStore();
    updateChrome();
  };
  check.addEventListener('change', finishToggle);

  const main = document.createElement('div');
  main.className = 'row-main';

  const title = document.createElement('div');
  title.className = 'row-title';
  title.textContent = item.title;
  title.title = item.title;
  main.append(title);

  const finalUrl = finalUrlFor(item);
  const link = document.createElement('a');
  link.className = 'row-url';
  link.href = finalUrl || item.url;
  link.target = '_blank';
  link.rel = 'noreferrer';
  link.textContent = finalUrl || item.url;
  link.title = finalUrl ? '媒体原始链接 · ' + finalUrl : item.url;
  main.append(link);

  const metaText = [item.source, item.time].filter(Boolean).join(' · ');
  if (metaText) {
    const meta = document.createElement('div');
    meta.className = 'row-meta';
    meta.textContent = metaText;
    main.append(meta);
  }

  const del = document.createElement('button');
  del.type = 'button';
  del.className = 'row-del';
  del.title = '删除这条';
  del.setAttribute('aria-label', '删除这条');
  del.textContent = '×';
  del.addEventListener('click', (event) => {
    event.stopPropagation();
    removeItem(item, page);
  });

  row.append(check, main, del);

  row.addEventListener('click', (event) => {
    if (event.target.closest('a, button, input')) return;
    check.checked = !check.checked;
    finishToggle();
  });

  return row;
}

function messageBox(title, body, action) {
  const box = document.createElement('div');
  box.className = 'empty';

  const heading = document.createElement('strong');
  heading.textContent = title;
  box.append(heading);

  if (body) {
    const text = document.createElement('div');
    text.textContent = body;
    box.append(text);
  }

  if (action) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn';
    button.style.marginTop = '14px';
    button.textContent = action.label;
    button.addEventListener('click', () => {
      if (action.href) chrome.tabs.create({ url: action.href });
      else if (action.onClick) action.onClick();
    });
    box.append(button);
  }

  return box;
}

function showMessage(title, body, action) {
  const list = $('list');
  if (!list) return;
  list.textContent = '';
  list.append(messageBox(title, body, action));
  renderTabs();
  updateChrome();
}

function showUnsupported() {
  showMessage(
    '请先打开一个新闻页面',
    '在任意新闻网站（Google News、nytimes.com、ft.com、bbc.com…）打开页面后，再点插件图标，就能一键抓取当前页的链接。',
    { label: '打开 Google News', href: NEWS_URL }
  );
}

function render() {
  const list = $('list');
  if (!list) return;
  list.textContent = '';

  const page = currentPage();
  const visible = visibleItems(page);
  const query = filterText.trim().toLowerCase();
  const shown = query
    ? visible.filter((item) =>
        (item.title + ' ' + item.url + ' ' + (item.source || ''))
          .toLowerCase()
          .includes(query)
      )
    : visible;

  if (!page || !page.items.length) {
    list.append(
      messageBox(
        '没有抓到文章链接',
        '页面可能还没加载完，或这个页面本身没有文章列表。点 ↻ 重试；有「抓取到 N 条」按钮的页面，也可以先下拉抓取一轮。',
        { label: '重新抓取', onClick: () => refresh(false) }
      )
    );
    renderTabs();
    updateChrome();
    return;
  }

  if (!shown.length) {
    if (query) {
      list.append(messageBox('没有匹配的条目', '换个关键词试试，或清空筛选框。'));
    } else {
      list.append(
        messageBox('这一页的条目都被删除了', '点底部“恢复删除”可以把它们找回来。')
      );
    }
    renderTabs();
    updateChrome();
    return;
  }

  const fragment = document.createDocumentFragment();
  for (const item of shown) fragment.append(renderRow(item, page));
  list.append(fragment);

  renderTabs();
  updateChrome();
}

function updateChrome() {
  const page = currentPage();
  const visible = visibleItems(page);
  const selected = selectedItems(page);

  const badge = $('count');
  if (badge) badge.textContent = String(selected.length);

  const copy = $('copy');
  if (copy) {
    const label = page ? kindLabel(page.pageKind, page) : '';
    copy.textContent = selected.length
      ? `复制「${label}」链接 (${selected.length})`
      : '复制已选链接';
    copy.disabled = selected.length === 0;
  }

  const selectAll = $('selectAll');
  if (selectAll) {
    const allSelected =
      visible.length > 0 &&
      visible.every((item) => !page.unchecked.includes(item.url));
    selectAll.textContent = allSelected ? '取消全选' : '全选';
    selectAll.disabled = visible.length === 0;
  }

  const restore = $('restore');
  if (restore) {
    const removed = page ? page.removed.length : 0;
    restore.hidden = removed === 0;
    restore.textContent = `恢复删除 (${removed})`;
  }

  const clear = $('clear');
  if (clear) {
    const total = page ? page.items.length : 0;
    clear.hidden = total === 0;
    clear.disabled = total === 0;
    clear.textContent = `清空 (${total})`;
  }

  const info = $('selectionInfo');
  if (info) {
    info.textContent =
      page && visible.length
        ? `${kindLabel(page.pageKind, page)} · 共 ${visible.length} 条 · 已选 ${selected.length} 条`
        : '';
  }

  const resolveToggle = $('resolveLink');
  if (resolveToggle) {
    resolveToggle.checked = store.settings.resolveLinks;
    const label = resolveToggle.closest('label');
    const hasGoogleLinks = Boolean(
      page && page.items.some((item) => isGoogleNewsUrl(item.url))
    );
    if (label) label.hidden = !hasGoogleLinks;
  }

  renderFeedBar();

  const meta = $('meta');
  if (meta) {
    if (!page) {
      meta.textContent = '';
    } else {
      const parts = [kindLabel(page.pageKind, page)];
      const location = pageLocation(page.pageUrl);
      if (location) parts.push(location);
      if (page.capturedAt) {
        parts.push(
          '抓取于 ' +
            new Date(page.capturedAt).toLocaleTimeString('zh-CN', {
              hour: '2-digit',
              minute: '2-digit',
            })
        );
      }
      if (visible.length) parts.push(`${visible.length} 条`);
      if (page.removed.length) parts.push(`已删除 ${page.removed.length}`);
      meta.textContent = parts.join(' · ');
    }
  }
}

/* ---------------- actions ---------------- */

function removeItem(item, page) {
  if (!page.removed.includes(item.url)) {
    page.removed.push(item.url);
    saveStore();
  }
  render();
}

function restoreRemoved() {
  const page = currentPage();
  if (!page) return;
  page.removed = [];
  saveStore();
  render();
}

function toggleSelectAll() {
  const page = currentPage();
  if (!page) return;
  const visible = visibleItems(page);
  const allSelected =
    visible.length > 0 &&
    visible.every((item) => !page.unchecked.includes(item.url));
  page.unchecked = allSelected ? visible.map((item) => item.url) : [];
  saveStore();
  render();
}

function clearCurrent() {
  const page = currentPage();
  if (!page || !page.items.length) return;
  const urls = page.items.map((item) => item.url);
  page.removed = [...new Set([...page.removed, ...urls])];
  page.unchecked = [];
  saveStore();
  render();
  toast(`已清空 ${urls.length} 条，可点「恢复删除」找回`);
}

function fallbackCopy(text) {
  const area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0;';
  document.body.append(area);
  area.select();
  document.execCommand('copy');
  area.remove();
}

async function copySelected() {
  const items = selectedItems();
  if (!items.length) {
    toast('没有可复制的链接');
    return;
  }

  let urls = items.map((item) => item.url);
  const needsResolve =
    store.settings.resolveLinks && items.some((item) => isGoogleNewsUrl(item.url));
  let resolveError = '';

  if (needsResolve) {
    busy = true;
    const copyButton = $('copy');
    if (copyButton) copyButton.disabled = true;
    updatePullButton();
    try {
      const result = await resolveAll(items, (done, total) =>
        setStatus(`正在解析媒体原始链接… ${done}/${total}`)
      );
      urls = result.urls;
      resolveError = result.error;
      saveResolved();
      render();
    } finally {
      busy = false;
      updatePullButton();
      updateChrome();
      setStatus(resolveError ? `解析失败：${resolveError}` : '');
    }
  }

  const text = urls.join('\n');
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    fallbackCopy(text);
  }

  const resolved = urls.filter((url) => !isGoogleNewsUrl(url)).length;
  if (!needsResolve) {
    toast(`已复制 ${urls.length} 条链接`);
  } else if (resolved === 0) {
    toast(
      `已复制 ${urls.length} 条 Google News 链接；原文解析失败` +
        (resolveError ? `：${resolveError}` : '')
    );
  } else if (resolved < urls.length) {
    toast(
      `已复制 ${urls.length} 条（${resolved} 条原文，${urls.length - resolved} 条仍是 Google News 链接` +
        (resolveError ? `；${resolveError}` : '') +
        '）'
    );
  } else {
    toast(`已复制 ${urls.length} 条媒体原始链接`);
  }
}

function toast(message) {
  const node = $('toast');
  if (!node) return;
  node.textContent = message;
  node.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    node.hidden = true;
  }, 2200);
}

function openViewer() {
  chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html') });
  if (!IS_VIEWER) window.close();
}

/* ---------------- init ---------------- */

function pickInitialKind() {
  if (store.lastKind && store.pages[store.lastKind]) return store.lastKind;
  const kinds = availableKinds();
  return kinds[0] || '';
}

async function initPopup() {
  await loadResolved();
  await loadStore();

  const tab = await activeTab();
  if (!tab || !isSupportedUrl(tab.url)) {
    currentKind = pickInitialKind();
    if (currentKind) {
      render();
      setStatus('当前标签页不是网页，显示上次抓取的结果。');
    } else {
      showUnsupported();
    }
    return;
  }

  currentKind = pickInitialKind();
  const ok = await capture(tab.id, { deep: false, tabUrl: tab.url });

  // For you is a short window onto a long feed: fill it up to the chosen size
  // without making the user scroll the page themselves. Generic sites are not
  // auto-scrolled on open - opening the popup should never start a 3-minute
  // scroll on its own.
  const page = currentPage();
  if (
    ok &&
    page &&
    page.pageKind === 'foryou' &&
    store.grabLimit !== 'all' &&
    page.items.length < store.grabLimit
  ) {
    await capture(tab.id, {
      deep: true,
      target: store.grabLimit,
      maxRounds: 12,
      tabUrl: tab.url,
    });
  }
}

async function initViewer() {
  await loadStore();
  await loadResolved();
  currentKind = pickInitialKind();
  if (currentKind) {
    render();
  } else {
    showMessage(
      '还没有抓取数据',
      '先打开任意新闻页面，或直接点下面的按钮抓取已打开的新标签页。',
      {
        label: '抓取当前标签页',
        onClick: () => refresh(false),
      }
    );
  }
}

function bindEvents() {
  $('refresh')?.addEventListener('click', () => refresh(false));
  $('pull')?.addEventListener('click', () => pullFor(currentKind));
  $('copy')?.addEventListener('click', copySelected);
  $('resolveLink')?.addEventListener('change', (event) => {
    store.settings.resolveLinks = Boolean(event.target.checked);
    saveStore();
  });
  $('selectAll')?.addEventListener('click', toggleSelectAll);
  $('restore')?.addEventListener('click', restoreRemoved);
  $('clear')?.addEventListener('click', clearCurrent);
  $('openViewer')?.addEventListener('click', openViewer);
  $('search')?.addEventListener('input', (event) => {
    filterText = event.target.value;
    render();
  });
  $('grabLimit')?.addEventListener('change', (event) => {
    const value = normalizeLimit(event.target.value);
    if (value === store.grabLimit) return;
    store.grabLimit = value;
    saveStore();
    render();

    // Asking for a number that is not loaded yet? Pull it in. "All" is always
    // explicit: it can take up to three minutes, so a dropdown change must
    // never start it on its own.
    const page = currentPage();
    if (
      value !== 'all' &&
      page &&
      (page.pageKind === 'foryou' || page.pageKind.startsWith('site:')) &&
      page.items.length < value
    ) {
      pullFor(page.pageKind);
    }
  });
}

function init() {
  bindEvents();
  const start = IS_VIEWER ? initViewer : initPopup;
  start().catch((err) => {
    console.error(err);
    showMessage('初始化失败', err && err.message ? err.message : String(err));
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
