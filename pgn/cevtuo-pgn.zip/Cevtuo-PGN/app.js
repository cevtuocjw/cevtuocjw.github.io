'use strict';

const STORE_KEY = 'gnStore';
const NEWS_URL = 'https://news.google.com/foryou?hl=en-GB&gl=GB&ceid=GB:en';
const KIND_ORDER = ['home', 'foryou', 'following', 'other'];

const IS_VIEWER = document.body.dataset.mode === 'viewer';
const $ = (id) => document.getElementById(id);

const emptyPage = (kind = '') => ({
  pageKind: kind,
  pageLabel: '',
  pageUrl: '',
  capturedAt: 0,
  items: [],
  removed: [],
  unchecked: [],
});

const FORYOU_LIMITS = [20, 30, 50];

let store = { pages: {}, lastKind: '', foryouLimit: 30 };
let currentKind = '';
let filterText = '';
let busy = false;
let toastTimer = 0;

/* ---------------- data ---------------- */

function pageKey(url) {
  try {
    return new URL(url).pathname.replace(/\/+$/, '') || '/';
  } catch {
    return '';
  }
}

function isNewsUrl(url) {
  return /^https?:\/\/news\.google\.com\//.test(url || '');
}

function pageFor(kind) {
  return (kind && store.pages[kind]) || null;
}

function currentPage() {
  return pageFor(currentKind);
}

function kindLabel(kind, page) {
  if (kind === 'home') return '首页';
  if (kind === 'foryou') return 'For you';
  if (kind === 'following') return 'Following';
  return (page && page.pageLabel) || '其他页面';
}

function availableKinds() {
  const kinds = KIND_ORDER.filter(
    (kind) => store.pages[kind] && store.pages[kind].items.length
  );
  if (currentKind && !kinds.includes(currentKind)) kinds.push(currentKind);
  return kinds;
}

function visibleItems(page = currentPage()) {
  if (!page) return [];
  const removed = new Set(page.removed);
  let items = page.items.filter((item) => !removed.has(item.url));
  // For you is a long feed; the user picks the first 20/30/50 stories.
  // Deleted items drop out first, so the list backfills to the chosen size.
  if (page.pageKind === 'foryou') {
    items = items.slice(0, store.foryouLimit || 30);
  }
  return items;
}

function selectedItems(page = currentPage()) {
  if (!page) return [];
  const unchecked = new Set(page.unchecked);
  return visibleItems(page).filter((item) => !unchecked.has(item.url));
}

async function loadStore() {
  try {
    const data = await chrome.storage.local.get(STORE_KEY);
    const saved = data && data[STORE_KEY];
    if (!saved || !saved.pages || typeof saved.pages !== 'object') return;
    store = {
      pages: {},
      lastKind: saved.lastKind || '',
      foryouLimit: FORYOU_LIMITS.includes(saved.foryouLimit) ? saved.foryouLimit : 30,
    };
    for (const [kind, savedPage] of Object.entries(saved.pages)) {
      if (!savedPage || !Array.isArray(savedPage.items)) continue;
      store.pages[kind] = {
        ...emptyPage(kind),
        ...savedPage,
        removed: Array.isArray(savedPage.removed) ? savedPage.removed : [],
        unchecked: Array.isArray(savedPage.unchecked) ? savedPage.unchecked : [],
      };
    }
  } catch (err) {
    console.error('读取缓存失败', err);
  }
}

function saveStore() {
  chrome.storage.local.set({ [STORE_KEY]: store }).catch((err) => {
    console.error('保存失败', err);
  });
}

/* ---------------- capture ---------------- */

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function extract(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    files: ['extractor.js'],
  });
  return results && results[0] ? results[0].result : null;
}

async function autoScroll(tabId) {
  const run = (func, args) =>
    chrome.scripting.executeScript({ target: { tabId }, func, args });

  const [{ result: startY }] = await run(() => window.scrollY);
  let stagnant = 0;

  for (let i = 0; i < 8; i++) {
    const [{ result: before }] = await run(() => ({
      height: document.documentElement.scrollHeight,
      y: window.scrollY,
    }));

    await run(() => window.scrollBy(0, Math.round(window.innerHeight * 1.2)));
    await sleep(900);

    const [{ result: after }] = await run(() => ({
      height: document.documentElement.scrollHeight,
      y: window.scrollY,
    }));

    if (after.height <= before.height + 40 && Math.abs(after.y - before.y) < 40) {
      stagnant += 1;
      if (stagnant >= 2) break;
    } else {
      stagnant = 0;
    }
  }

  await run((y) => window.scrollTo(0, y), [startY]);
}

async function activeTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs[0];
}

async function findNewsTab() {
  const tabs = await chrome.tabs.query({ url: 'https://news.google.com/*' });
  if (!tabs || !tabs.length) return null;
  return (
    tabs.find((tab) => pageKey(tab.url) === '/foryou') ||
    tabs.find((tab) => pageKey(tab.url) === '/home') ||
    tabs[tabs.length - 1]
  );
}

// Keep the user's removals/ticks for this feed across recaptures; a story
// that is gone from the feed no longer needs to be remembered.
function carriedOver(kind, items) {
  const previous = pageFor(kind);
  if (!previous) return { removed: [], unchecked: [] };
  const present = new Set(items.map((item) => item.url));
  return {
    removed: previous.removed.filter((url) => present.has(url)),
    unchecked: previous.unchecked.filter((url) => present.has(url)),
  };
}

async function capture(tabId, { deep = false } = {}) {
  if (busy) return false;
  busy = true;
  setStatus(deep ? '正在滚动加载更多内容…' : '正在抓取当前页面…');

  try {
    if (deep) await autoScroll(tabId);

    let payload = await extract(tabId);

    // The feed is lazy; one quiet retry usually picks up the rest.
    if (!deep && (!payload || !payload.items || !payload.items.length)) {
      await sleep(900);
      payload = await extract(tabId);
    }

    if (!payload || !Array.isArray(payload.items)) {
      throw new Error('页面没有返回结果');
    }

    const kind = payload.pageKind || 'other';
    const previous = pageFor(kind);

    // A loaded-but-empty feed should not wipe what we already have.
    if (!payload.items.length && previous && previous.items.length) {
      currentKind = kind;
      store.lastKind = kind;
      saveStore();
      setStatus('这次没有抓到新内容，仍然显示上次抓取的结果。');
      render();
      return true;
    }

    const carry = carriedOver(kind, payload.items);
    store.pages[kind] = {
      pageKind: kind,
      pageLabel: payload.pageLabel || '',
      pageUrl: payload.pageUrl || '',
      capturedAt: Date.now(),
      items: payload.items,
      removed: carry.removed,
      unchecked: carry.unchecked,
    };
    store.lastKind = kind;
    currentKind = kind;

    filterText = '';
    if ($('search')) $('search').value = '';

    saveStore();
    setStatus('');
    render();
    return true;
  } catch (err) {
    console.error(err);
    setStatus('');

    const fallbackKind =
      store.lastKind && store.pages[store.lastKind]
        ? store.lastKind
        : Object.keys(store.pages)[0];

    if (fallbackKind) {
      currentKind = fallbackKind;
      setStatus('抓取失败，显示上次抓取的结果。');
      render();
      return false;
    }

    showMessage(
      '抓取失败',
      '请确认当前标签页是 news.google.com 且页面已经加载完成，然后再点一次 ↻。\n' +
        (err && err.message ? err.message : String(err))
    );
    return false;
  } finally {
    busy = false;
  }
}

async function refresh(deep) {
  if (IS_VIEWER) {
    const tab = await findNewsTab();
    if (!tab) {
      showMessage(
        '没有找到 Google News 标签页',
        '请先在浏览器里打开 Google News 的 For you 页面，再回来抓取。',
        { label: '打开 For you 页面', href: NEWS_URL }
      );
      return;
    }
    await capture(tab.id, { deep });
    return;
  }

  const tab = await activeTab();
  if (!tab || !isNewsUrl(tab.url)) {
    showNotNews();
    return;
  }
  await capture(tab.id, { deep });
}

/* ---------------- rendering ---------------- */

function setStatus(text) {
  const node = $('status');
  if (!node) return;
  node.textContent = text || '';
  node.hidden = !text;
}

function renderTabs() {
  const bar = $('pageTabs');
  if (!bar) return;

  const kinds = availableKinds();
  bar.textContent = '';
  bar.hidden = kinds.length < 2;

  for (const kind of kinds) {
    const page = pageFor(kind);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'page-tab' + (kind === currentKind ? ' active' : '');
    button.dataset.kind = kind;

    const label = document.createElement('span');
    label.textContent = kindLabel(kind, page);
    button.append(label);

    const count = document.createElement('span');
    count.className = 'n';
    count.textContent = String(visibleItems(page).length);
    button.append(count);

    if (kind === currentKind) button.setAttribute('aria-current', 'true');
    button.addEventListener('click', () => {
      if (kind === currentKind) return;
      currentKind = kind;
      store.lastKind = kind;
      filterText = '';
      if ($('search')) $('search').value = '';
      saveStore();
      render();
    });

    bar.append(button);
  }
}

function renderLimitBar() {
  const bar = $('limitBar');
  if (!bar) return;

  const page = currentPage();
  const show = Boolean(page && page.pageKind === 'foryou');
  bar.hidden = !show;
  if (!show) return;

  for (const button of bar.querySelectorAll('button[data-limit]')) {
    const value = Number(button.dataset.limit);
    const active = value === store.foryouLimit;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', active ? 'true' : 'false');
  }
}

function renderRow(item, page) {
  const row = document.createElement('div');
  row.className = 'row';

  const checked = !page.unchecked.includes(item.url);
  if (!checked) row.classList.add('off');

  const check = document.createElement('input');
  check.type = 'checkbox';
  check.className = 'check';
  check.checked = checked;
  check.setAttribute('aria-label', '是否复制这条链接');

  const finishToggle = () => {
    const set = new Set(page.unchecked);
    if (check.checked) set.delete(item.url);
    else set.add(item.url);
    page.unchecked = [...set];
    row.classList.toggle('off', !check.checked);
    saveStore();
    updateChrome();
  };
  check.addEventListener('change', finishToggle);

  const main = document.createElement('div');
  main.className = 'row-main';

  const title = document.createElement('div');
  title.className = 'row-title';
  title.textContent = item.title;
  title.title = item.title;
  main.append(title);

  const link = document.createElement('a');
  link.className = 'row-url';
  link.href = item.url;
  link.target = '_blank';
  link.rel = 'noreferrer';
  link.textContent = item.url;
  link.title = item.url;
  main.append(link);

  const metaText = [item.source, item.time].filter(Boolean).join(' · ');
  if (metaText) {
    const meta = document.createElement('div');
    meta.className = 'row-meta';
    meta.textContent = metaText;
    main.append(meta);
  }

  const del = document.createElement('button');
  del.type = 'button';
  del.className = 'row-del';
  del.title = '删除这条';
  del.setAttribute('aria-label', '删除这条');
  del.textContent = '×';
  del.addEventListener('click', (event) => {
    event.stopPropagation();
    removeItem(item, page);
  });

  row.append(check, main, del);

  row.addEventListener('click', (event) => {
    if (event.target.closest('a, button, input')) return;
    check.checked = !check.checked;
    finishToggle();
  });

  return row;
}

function messageBox(title, body, action) {
  const box = document.createElement('div');
  box.className = 'empty';

  const heading = document.createElement('strong');
  heading.textContent = title;
  box.append(heading);

  if (body) {
    const text = document.createElement('div');
    text.textContent = body;
    box.append(text);
  }

  if (action) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn';
    button.style.marginTop = '14px';
    button.textContent = action.label;
    button.addEventListener('click', () => {
      if (action.href) chrome.tabs.create({ url: action.href });
      else if (action.onClick) action.onClick();
    });
    box.append(button);
  }

  return box;
}

function showMessage(title, body, action) {
  const list = $('list');
  if (!list) return;
  list.textContent = '';
  list.append(messageBox(title, body, action));
  renderTabs();
  updateChrome();
}

function showNotNews() {
  showMessage(
    '请先打开 Google News',
    '在 Google News 的 For you 页面点击工具栏里的插件图标，就能抓取当前页面。',
    { label: '打开 For you 页面', href: NEWS_URL }
  );
}

function render() {
  const list = $('list');
  if (!list) return;
  list.textContent = '';

  const page = currentPage();
  const visible = visibleItems(page);
  const query = filterText.trim().toLowerCase();
  const shown = query
    ? visible.filter((item) =>
        (item.title + ' ' + item.url + ' ' + (item.source || ''))
          .toLowerCase()
          .includes(query)
      )
    : visible;

  if (!page || !page.items.length) {
    list.append(
      messageBox(
        '没有抓到文章链接',
        '页面可能还没加载完，稍等片刻后点右上角 ↻ 重新抓取。',
        { label: '重新抓取', onClick: () => refresh(false) }
      )
    );
    renderTabs();
    updateChrome();
    return;
  }

  if (!shown.length) {
    if (query) {
      list.append(messageBox('没有匹配的条目', '换个关键词试试，或清空筛选框。'));
    } else {
      list.append(
        messageBox('这一页的条目都被删除了', '点底部“恢复删除”可以把它们找回来。')
      );
    }
    renderTabs();
    updateChrome();
    return;
  }

  const fragment = document.createDocumentFragment();
  for (const item of shown) fragment.append(renderRow(item, page));
  list.append(fragment);

  renderTabs();
  updateChrome();
}

function updateChrome() {
  const page = currentPage();
  const visible = visibleItems(page);
  const selected = selectedItems(page);

  const badge = $('count');
  if (badge) badge.textContent = String(selected.length);

  const copy = $('copy');
  if (copy) {
    const label = page ? kindLabel(page.pageKind, page) : '';
    copy.textContent = selected.length
      ? `复制「${label}」链接 (${selected.length})`
      : '复制已选链接';
    copy.disabled = selected.length === 0;
  }

  const selectAll = $('selectAll');
  if (selectAll) {
    const allSelected =
      visible.length > 0 &&
      visible.every((item) => !page.unchecked.includes(item.url));
    selectAll.textContent = allSelected ? '取消全选' : '全选';
    selectAll.disabled = visible.length === 0;
  }

  const restore = $('restore');
  if (restore) {
    const removed = page ? page.removed.length : 0;
    restore.hidden = removed === 0;
    restore.textContent = `恢复删除 (${removed})`;
  }

  const info = $('selectionInfo');
  if (info) {
    info.textContent =
      page && visible.length
        ? `${kindLabel(page.pageKind, page)} · 共 ${visible.length} 条 · 已选 ${selected.length} 条`
        : '';
  }

  renderLimitBar();

  const meta = $('meta');
  if (meta) {
    if (!page) {
      meta.textContent = '';
    } else {
      const parts = [kindLabel(page.pageKind, page)];
      const path = pageKey(page.pageUrl);
      if (path && path !== '/foryou' && path !== '/home') parts.push(path);
      if (page.capturedAt) {
        parts.push(
          '抓取于 ' +
            new Date(page.capturedAt).toLocaleTimeString('zh-CN', {
              hour: '2-digit',
              minute: '2-digit',
            })
        );
      }
      if (visible.length) parts.push(`${visible.length} 条`);
      if (page.removed.length) parts.push(`已删除 ${page.removed.length}`);
      meta.textContent = parts.join(' · ');
    }
  }
}

/* ---------------- actions ---------------- */

function removeItem(item, page) {
  if (!page.removed.includes(item.url)) {
    page.removed.push(item.url);
    saveStore();
  }
  render();
}

function restoreRemoved() {
  const page = currentPage();
  if (!page) return;
  page.removed = [];
  saveStore();
  render();
}

function toggleSelectAll() {
  const page = currentPage();
  if (!page) return;
  const visible = visibleItems(page);
  const allSelected =
    visible.length > 0 &&
    visible.every((item) => !page.unchecked.includes(item.url));
  page.unchecked = allSelected ? visible.map((item) => item.url) : [];
  saveStore();
  render();
}

function fallbackCopy(text) {
  const area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0;';
  document.body.append(area);
  area.select();
  document.execCommand('copy');
  area.remove();
}

async function copySelected() {
  const items = selectedItems();
  if (!items.length) {
    toast('没有可复制的链接');
    return;
  }

  const text = items.map((item) => item.url).join('\n');
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    fallbackCopy(text);
  }
  toast(`已复制 ${items.length} 条链接`);
}

function toast(message) {
  const node = $('toast');
  if (!node) return;
  node.textContent = message;
  node.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    node.hidden = true;
  }, 2200);
}

function openViewer() {
  chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html') });
  if (!IS_VIEWER) window.close();
}

/* ---------------- init ---------------- */

function pickInitialKind() {
  if (store.lastKind && store.pages[store.lastKind]) return store.lastKind;
  const kinds = availableKinds();
  return kinds[0] || '';
}

async function initPopup() {
  const tab = await activeTab();
  if (!tab || !isNewsUrl(tab.url)) {
    await loadStore();
    currentKind = pickInitialKind();
    if (currentKind) {
      render();
      setStatus('当前标签页不是 Google News，显示上次抓取的结果。');
    } else {
      showNotNews();
    }
    return;
  }

  await loadStore();
  currentKind = pickInitialKind();
  await capture(tab.id, { deep: false });
}

async function initViewer() {
  await loadStore();
  currentKind = pickInitialKind();
  if (currentKind) {
    render();
  } else {
    showMessage(
      '还没有抓取数据',
      '先打开 Google News 的 For you 页面，或直接点下面的按钮抓取已打开的 Google News 标签页。',
      {
        label: '抓取已打开的 Google News 标签页',
        onClick: () => refresh(false),
      }
    );
  }
}

function bindEvents() {
  $('refresh')?.addEventListener('click', () => refresh(false));
  $('deep')?.addEventListener('click', () => refresh(true));
  $('copy')?.addEventListener('click', copySelected);
  $('selectAll')?.addEventListener('click', toggleSelectAll);
  $('restore')?.addEventListener('click', restoreRemoved);
  $('openViewer')?.addEventListener('click', openViewer);
  $('search')?.addEventListener('input', (event) => {
    filterText = event.target.value;
    render();
  });
  $('limitBar')?.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-limit]');
    if (!button) return;
    const value = Number(button.dataset.limit);
    if (!FORYOU_LIMITS.includes(value) || value === store.foryouLimit) return;
    store.foryouLimit = value;
    saveStore();
    render();
  });
}

function init() {
  bindEvents();
  const start = IS_VIEWER ? initViewer : initPopup;
  start().catch((err) => {
    console.error(err);
    showMessage('初始化失败', err && err.message ? err.message : String(err));
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
