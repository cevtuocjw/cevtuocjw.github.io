/*
 * Runs inside the page (via chrome.scripting.executeScript, after core.js).
 * Returns { items, pageKind, pageLabel, pageUrl, pageTitle, pageHeight, mode, stats }.
 *
 * Two modes:
 *  - Google News: keyed off /read/<token> and Google's own story-cluster ids.
 *  - Everything else: generic article-link heuristics. No site-specific DOM
 *    selectors, because news sites redesign their class names constantly.
 *    Known sites only get a URL-shape confidence boost (core.js profiles).
 */
(() => {
  'use strict';

  const core = globalThis.__CEVTUO_PGN_CORE_V2__;
  if (!core) throw new Error('Cevtuo-PGN core.js was not injected');

  const cleanText = (s) => (s || '').replace(/\s+/g, ' ').trim();

  /* ============================================================
   * Google News
   * ============================================================ */

  // /read/ is what news.google.com uses today; keep the older shapes as fallbacks.
  const ARTICLE_PATH = /^\/(?:read|articles|rss\/articles)\/[^/?#]+/;
  // Games on Google News live under /games, /puzzles, ... and link out to
  // puzzles.google.com. They must never enter the link list.
  const GAME_URL = /(?:^|\/)(?:games?|puzzles?|crossword|sudoku|wordle|word-search|play)(?:\/|$)/i;
  const GN_TIME_RE = /^\d+\s+(?:minute|hour|day|week|month|year)s?\s+ago$/i;
  const GN_UI_TEXT = /^(more|see more|see more headlines and perspectives|sign in|google news)$/i;

  function googleArticleUrl(href) {
    if (!href) return null;
    let u;
    try {
      u = new URL(href, location.href);
    } catch {
      return null;
    }
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    if (!core.isGoogleNewsHost(u.hostname)) return null;
    if (!ARTICLE_PATH.test(u.pathname)) return null;
    if (GAME_URL.test(u.pathname)) return null;
    // Drop ?hl=&gl=&ceid= so every copied line is a clean article link.
    return location.origin + u.pathname.replace(/\/$/, '');
  }

  // Google puts "channel_story_360:<id>" inside a base64 jslog payload on the
  // card wrapper. This is the most precise cluster id available.
  function storyIdFromJslog(el) {
    if (!el || !el.getAttribute) return '';
    const jslog = el.getAttribute('jslog');
    if (!jslog) return '';
    const m = jslog.match(/3:([A-Za-z0-9+/=]+)/);
    if (!m) return '';
    try {
      const decoded = atob(m[1]);
      const hit = decoded.match(/channel_story_360:([A-Za-z0-9_-]+)/);
      return hit ? hit[1] : '';
    } catch {
      return '';
    }
  }

  function storyIdsFromLinks(el) {
    if (!el || !el.querySelectorAll) return [];
    const ids = new Set();
    for (const a of el.querySelectorAll('a[href*="/stories/"]')) {
      const m = (a.getAttribute('href') || '').match(/\/stories\/([^/?#]+)/);
      if (m) ids.add(m[1]);
    }
    return [...ids];
  }

  // Walk up from the headline. The first level that has an unambiguous story id
  // wins; if a level shows several different stories, it is a section wrapper
  // and must not be used.
  function storyIdFor(anchor) {
    let node = anchor;
    for (let depth = 0; node && depth < 8; depth++) {
      const fromJslog = storyIdFromJslog(node);
      if (fromJslog) return fromJslog;
      const ids = storyIdsFromLinks(node);
      if (ids.length === 1) return ids[0];
      if (ids.length > 1) return '';
      node = node.parentElement;
    }
    return '';
  }

  function selectedTabText() {
    const tab = document.querySelector(
      '[role="tab"][aria-selected="true"], [role="tab"][aria-selected="true"] *'
    );
    return cleanText(tab && tab.innerText);
  }

  function kindFromLabel(label) {
    const text = (label || '').toLowerCase();
    if (!text) return '';
    if (/for you|为你|為你|推荐|推薦/.test(text)) return 'foryou';
    if (/following|追踪|追蹤|关注|關注/.test(text)) return 'following';
    if (/^home$|首页|首頁/.test(text)) return 'home';
    return '';
  }

  function detectGooglePage() {
    const path = location.pathname.replace(/\/+$/, '');
    const tabLabel = selectedTabText();
    const fromTab = kindFromLabel(tabLabel);
    if (fromTab) {
      return {
        kind: fromTab,
        label:
          tabLabel ||
          (fromTab === 'home' ? 'Home' : fromTab === 'foryou' ? 'For you' : 'Following'),
      };
    }
    if (/^\/foryou(\/|$)/.test(path)) return { kind: 'foryou', label: 'For you' };
    if (/^\/following(\/|$)/.test(path)) return { kind: 'following', label: 'Following' };
    if (path === '' || path === '/home') return { kind: 'home', label: 'Home' };
    return { kind: 'other', label: 'News' };
  }

  function parseAriaMeta(ariaLabel) {
    const meta = { source: '', time: '' };
    if (!ariaLabel) return meta;
    const parts = ariaLabel.split(/\s+-\s+/);
    const timeIndex = parts.findIndex((p) => GN_TIME_RE.test(p.trim()));
    if (timeIndex > 0) {
      meta.time = parts[timeIndex].trim();
      meta.source = parts[timeIndex - 1].trim();
    }
    return meta;
  }

  function isHidden(a) {
    if (a.closest('[aria-hidden="true"]')) return true;
    const style = getComputedStyle(a);
    if (style.display === 'none' || style.visibility === 'hidden') return true;
    return a.offsetParent === null && style.position !== 'fixed';
  }

  function googleSnapshot() {
    const seenUrls = new Set();
    const seenTitles = new Set();
    const seenStories = new Set();
    const items = [];
    const stats = { candidates: 0, duplicates: 0, duplicatesByStory: 0, games: 0 };

    for (const a of document.querySelectorAll('a[href]')) {
      const href = a.getAttribute('href');
      if (!href) continue;

      const url = googleArticleUrl(href);
      if (!url) {
        if (GAME_URL.test((href.split('?')[0] || '').toLowerCase())) stats.games++;
        continue;
      }
      stats.candidates++;

      if (isHidden(a)) continue;

      const title = cleanText(a.innerText || a.textContent);
      if (!title || title.length < 3 || GN_UI_TEXT.test(title)) continue;

      const meta = parseAriaMeta(a.getAttribute('aria-label') || '');
      const storyId = storyIdFor(a);

      if (seenUrls.has(url)) {
        stats.duplicates++;
        continue;
      }
      const titleKey = core.normTitle(title);
      if (titleKey && seenTitles.has(titleKey)) {
        stats.duplicates++;
        continue;
      }
      if (storyId && seenStories.has(storyId)) {
        stats.duplicates++;
        stats.duplicatesByStory++;
        continue;
      }

      seenUrls.add(url);
      if (titleKey) seenTitles.add(titleKey);
      if (storyId) seenStories.add(storyId);

      items.push({ title, url, source: meta.source, time: meta.time, storyId });
    }

    const page = detectGooglePage();

    return {
      items,
      pageKind: page.kind,
      pageLabel: page.label,
      pageUrl: location.href,
      pageTitle: document.title,
      // The pull-to-load loop uses this to tell "feed ended" from "screen was
      // all duplicates": if the page keeps growing, there is more to read.
      pageHeight: document.documentElement.scrollHeight,
      mode: 'google',
      stats,
    };
  }

  /* ============================================================
   * Generic news sites
   * ============================================================ */

  const DATE_PATH = /\/(?:19|20)\d{2}\/(?:0?[1-9]|1[0-2])\/(?:0?[1-9]|[12]\d|3[01])(?:\/|$)/;
  const DATE_DASH = /\/(?:19|20)\d{2}-(?:0?[1-9]|1[0-2])-(?:0?[1-9]|[12]\d|3[01])(?:\/|$)/;
  const DATE_MONTH = /\/(?:19|20)\d{2}\/(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\/\d{1,2}(?:\/|$)/i;
  const ARTICLE_SEGMENT = /\/(?:article|articles|story|stories|content|read|entry|detail|post|posts|news\/article)\//i;
  const CATEGORY_PATH = /\/(?:tag|tags|topic|topics|category|categories|section|sections|author|authors|profile|people|search|login|signin|signup|register|subscribe|subscription|newsletters?|account|settings|help|about|contact|privacy|terms|cookies?|rss|feed|sitemap|video|videos|podcast|podcasts|audio|gallery|photos?|games?|puzzles?|weather|advertise|shop|store|jobs?|events?|competitions?|offers?|login|logout|cart|checkout)(?:\/|$)/i;

  const UI_TEXT = /^(?:home|news|world|business|markets|opinion|tech|technology|science|health|sports?|culture|lifestyle|travel|politics|videos?|podcasts?|audio|more|menu|search|sign in|sign up|log in|login|subscribe|subscription|newsletters?|e-?paper|latest|trending|most read|editor'?s picks|editors'? picks|all sections|see all|view all|read more|learn more|show more|load more|next|previous|back|share|comment|comments|advertisement|sponsored|homepage|国际|国内|新闻|财经|科技|体育|娱乐|视频|更多|登录|注册|订阅|首页|返回|展开|收起)$/i;

  const JUNK_ANCESTOR =
    '[class*="breadcrumb" i], [class*="pagination" i], [class*="social" i], [class*="share" i], [class*="newsletter" i], [class*="subscribe" i], [class*="promo" i], [class*="advert" i], [class*="sponsor" i], [class*="paywall" i], [class*="modal" i], [class*="cookie" i], [class*="outbrain" i], [class*="taboola" i], [id*="nav" i], [id*="menu" i]';

  const SITE_SUFFIX =
    /\s*(?:\||-|–|—|·)\s*(?:the\s+)?(?:new\s+york\s+times|nytimes|financial\s+times|ft\.com|bbc|guardian|reuters|associated\s+press|ap\s+news|washington\s+post|wall\s+street\s+journal|wsj|bloomberg|cnn|cnbc|nbc\s+news|cbs\s+news|fox\s+news|al\s+jazeera|economist|the\s+times|telegraph|independent|politico|axios|fortune|forbes|business\s+insider|scmp|south\s+china\s+morning\s+post|nikkei|straits\s+times|cnn\s+international)\s*$/i;

  const TIME_AGO =
    /\s*(?:[|–—-]\s*)?\d+\s*(?:min|mins|minute|minutes|hour|hours|day|days|week|weeks|month|months|year|years)\s+ago\s*$/i;

  function cleanTitle(value) {
    let t = cleanText(value);
    if (!t) return '';
    t = t.replace(/^(?:read|view|more)\s*[:：]\s*/i, '');
    t = t.replace(/\s*(?:opens?\s+in\s+(?:a\s+)?new\s+(?:tab|window))\s*$/i, '');
    t = t.replace(TIME_AGO, '');
    const withoutSite = t.replace(SITE_SUFFIX, '').trim();
    return withoutSite.length >= 8 ? withoutSite : t;
  }

  function isPlausibleTitle(t) {
    if (!t || t.length < 8 || t.length > 300) return false;
    if (UI_TEXT.test(t)) return false;
    // "VIEW ALL STORIES" often points at an article-shaped hub URL; it is a
    // navigation control, not a headline.
    if (/^(?:view|see|show|read)\s+all(?:\s+(?:stories|articles|news|headlines|results))?$/i.test(t)) return false;
    if (/^(?:more|load|show|view|see)\s+(?:stories|articles|news|headlines|results)$/i.test(t)) return false;
    if (/^[\d\s.,:;!?%$€£¥+\-–—()]+$/.test(t)) return false;
    return true;
  }

  // A card heading often contains a short kicker ("Analysis", "Voting")
  // followed by the real headline. innerText glues the two together without a
  // space, so take the first substantial leaf inside the heading when there is
  // one: "AnalysisHow Israel..." becomes "How Israel...".
  function bestHeadingText(heading) {
    if (!heading) return '';
    const full = cleanText(heading.innerText || heading.textContent);
    if (!full) return '';

    const leaves = [...heading.querySelectorAll('*')]
      .filter((el) => el.children.length === 0)
      .map((el) => cleanText(el.innerText || el.textContent))
      .filter(Boolean);

    for (const text of leaves) {
      if (text.length >= 40 && full.includes(text)) return text;
    }
    return full;
  }

  function titleFromAnchor(a) {
    const heading = a.querySelector('h1, h2, h3, h4');
    const innerLines = (a.innerText || '').split(/\n+/).map(cleanText).filter(Boolean);
    const img = a.querySelector('img[alt]');
    const alt = img && !/^(?:image|photo|picture|illustration|video|graphic|logo)\b/i.test(img.alt || '')
      ? cleanText(img.alt)
      : '';

    // A card headline (h2) outranks a liveblog update headline (h3) even when
    // the update is longer. Any heading outranks an image caption in aria-label.
    const headingLevel = heading ? Number(heading.tagName.slice(1)) || 4 : 4;
    const picks = [
      { value: bestHeadingText(heading), weight: 4, quality: 45 - headingLevel },
      { value: innerLines[0] || '', weight: 3, quality: 30 },
      { value: a.getAttribute('aria-label') || '', weight: 2, quality: 20 },
      { value: a.getAttribute('title') || '', weight: 1, quality: 10 },
      { value: alt, weight: 0, quality: 0 },
    ];

    let best = '';
    let bestScore = -1;
    let quality = 0;
    for (const pick of picks) {
      const title = cleanTitle(pick.value);
      if (!isPlausibleTitle(title)) continue;
      const score = pick.weight * 1000 + Math.min(title.length, 300);
      if (score > bestScore) {
        best = title;
        bestScore = score;
        quality = pick.quality;
      }
    }
    return { title: best, quality };
  }

  function timeFromAnchor(a) {
    let node = a;
    for (let depth = 0; node && depth < 4; depth++, node = node.parentElement) {
      const time = node.querySelector && node.querySelector('time');
      if (!time) continue;
      const value = cleanText(time.getAttribute('datetime') || time.textContent);
      if (value) return value.length > 40 ? value.slice(0, 40) : value;
    }
    return '';
  }

  function isVisible(a) {
    if (a.closest('[hidden], [aria-hidden="true"]')) return false;
    const rect = a.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) return false;
    const style = getComputedStyle(a);
    return style.display !== 'none' && style.visibility !== 'hidden';
  }

  function scoreLink(a, u, title, profile) {
    const path = u.pathname;
    const last = path.split('/').filter(Boolean).pop() || '';
    let score = 0;

    if (profile && profile.article && profile.article.test(path)) score += 6;
    if (DATE_PATH.test(path)) score += 4;
    if (DATE_DASH.test(path)) score += 3;
    if (DATE_MONTH.test(path)) score += 3;
    if (ARTICLE_SEGMENT.test(path)) score += 2;

    const slugish = /[a-z0-9]+(?:-[a-z0-9]+){2,}/i.test(last) && last.length >= 15;
    if (slugish) score += 2;
    if (/\d{5,}/.test(last)) score += 1;
    if (/\.(?:s?html?|php|aspx?)$/i.test(last)) score += 1;

    if (CATEGORY_PATH.test(path)) score -= 5;
    if (path === '/' || path.length < 2) score -= 6;

    if (title.length >= 15) score += 2;
    if (title.length >= 30) score += 1;

    const sameSite = core.sameSiteHost(u.hostname, location.hostname);
    if (!sameSite) {
      score -= 3;
      if (core.isKnownNewsHost(u.hostname)) score += 2;
    }

    if (a.closest('article')) score += 3;
    else if (a.closest('main, [role="main"], [role="feed"]')) score += 2;

    if (a.closest('nav, [role="navigation"], [role="menu"], [role="menubar"], [role="banner"]')) {
      score -= 8;
    }
    if (a.closest('footer, [role="contentinfo"]')) score -= 8;
    if (a.closest('header') && !a.closest('article')) score -= 6;
    if (a.closest('aside') && score < 8) score -= 4;
    if (a.closest(JUNK_ANCESTOR)) score -= 6;

    return score;
  }

  function genericSnapshot() {
    const profile = core.profileFor(location.hostname);
    const host = core.stripWww(location.hostname);
    const site = core.siteKey(location.hostname);
    const pageLabel = profile ? profile.label : host;
    const source = profile ? profile.label : host;
    const stats = { candidates: 0, duplicates: 0, external: 0, skipped: 0 };

    const byUrl = new Map();

    for (const a of document.querySelectorAll('a[href]')) {
      const href = a.getAttribute('href');
      if (!href || href.startsWith('#')) continue;

      const url = core.canonicalize(href, location.href);
      if (!url) continue;

      let parsed;
      try {
        parsed = new URL(url);
      } catch {
        continue;
      }
      // Canonicalization can leave the current site's own query params, but a
      // link to a login/search endpoint is never an article.
      if (core.isBlockedHost(parsed.hostname)) {
        stats.skipped++;
        continue;
      }
      if (CATEGORY_PATH.test(parsed.pathname) && !profile?.article?.test(parsed.pathname)) {
        stats.skipped++;
        continue;
      }

      const { title, quality: titleQuality } = titleFromAnchor(a);
      if (!title) {
        stats.skipped++;
        continue;
      }
      if (!isVisible(a)) {
        stats.skipped++;
        continue;
      }

      stats.candidates++;
      const sameSite = core.sameSiteHost(parsed.hostname, location.hostname);
      if (!sameSite) stats.external++;

      const score = scoreLink(a, parsed, title, profile);
      const minScore = sameSite ? 4 : 6;
      if (score < minScore) {
        stats.skipped++;
        continue;
      }

      const candidate = {
        title,
        url,
        source,
        time: timeFromAnchor(a),
        storyId: '',
        // A heading beats an image caption even when the caption is longer:
        // CNN-style photo cards use the caption as aria-label on the same URL.
        quality: titleQuality * 1e6 + score * 1000 + title.length,
      };

      const previous = byUrl.get(url);
      if (!previous || candidate.quality > previous.quality) byUrl.set(url, candidate);
      else stats.duplicates++;
    }

    // URL-level best candidate first, then the shared title/story dedupe.
    const items = core.mergeItems(
      [],
      [...byUrl.values()].map(({ quality, ...item }) => item)
    );
    stats.duplicates += [...byUrl.values()].length - items.length;

    return {
      items,
      pageKind: 'site:' + site,
      pageLabel,
      pageUrl: location.href,
      pageTitle: document.title,
      pageHeight: document.documentElement.scrollHeight,
      mode: 'generic',
      stats,
    };
  }

  return core.isGoogleNewsHost(location.hostname) ? googleSnapshot() : genericSnapshot();
})();
