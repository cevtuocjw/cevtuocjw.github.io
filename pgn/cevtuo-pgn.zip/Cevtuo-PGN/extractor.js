/*
 * Runs inside the Google News page (via chrome.scripting.executeScript).
 * Returns { items, pageKind, pageLabel, pageUrl, pageTitle, stats }.
 *
 * The page is a c-wiz SPA whose class names are generated hashes, so we key off
 * stable things instead: article URL shape (/read/<token>), link text, and the
 * aria-label metadata ("Title - Source - 2 hours ago - ...").
 *
 * Every article card carries Google's own story-cluster id: either inside the
 * jslog payload ("channel_story_360:<id>") or in a nearby /stories/<id> link.
 * Four headlines about the same event share one id, so we keep only the first
 * headline per story - that is the "same news, one link" rule.
 */
(() => {
  'use strict';

  // /read/ is what news.google.com uses today; keep the older shapes as fallbacks.
  const ARTICLE_PATH = /^\/(?:read|articles|rss\/articles)\/[^/?#]+/;
  // Games on Google News live under /games, /puzzles, ... and link out to
  // puzzles.google.com. They must never enter the link list.
  const GAME_URL = /(?:^|\/)(?:games?|puzzles?|crossword|sudoku|wordle|word-search|play)(?:\/|$)/i;
  const TIME_RE = /^\d+\s+(?:minute|hour|day|week|month|year)s?\s+ago$/i;
  const UI_TEXT = /^(more|see more|see more headlines and perspectives|sign in|google news)$/i;

  const cleanText = (s) => (s || '').replace(/\s+/g, ' ').trim();

  function articleUrl(href) {
    if (!href) return null;
    let u;
    try {
      u = new URL(href, location.href);
    } catch {
      return null;
    }
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    if (u.hostname !== 'news.google.com' && !u.hostname.endsWith('.news.google.com')) {
      return null;
    }
    if (!ARTICLE_PATH.test(u.pathname)) return null;
    if (GAME_URL.test(u.pathname)) return null;
    // Drop ?hl=&gl=&ceid= so every copied line is a clean article link.
    return 'https://news.google.com' + u.pathname.replace(/\/$/, '');
  }

  // Google puts "channel_story_360:<id>" inside a base64 jslog payload on the
  // card wrapper. This is the most precise cluster id available.
  function storyIdFromJslog(el) {
    if (!el || !el.getAttribute) return '';
    const jslog = el.getAttribute('jslog');
    if (!jslog) return '';
    const m = jslog.match(/3:([A-Za-z0-9+/=]+)/);
    if (!m) return '';
    try {
      const decoded = atob(m[1]);
      const hit = decoded.match(/channel_story_360:([A-Za-z0-9_-]+)/);
      return hit ? hit[1] : '';
    } catch {
      return '';
    }
  }

  function storyIdsFromLinks(el) {
    if (!el || !el.querySelectorAll) return [];
    const ids = new Set();
    for (const a of el.querySelectorAll('a[href*="/stories/"]')) {
      const m = (a.getAttribute('href') || '').match(/\/stories\/([^/?#]+)/);
      if (m) ids.add(m[1]);
    }
    return [...ids];
  }

  // Walk up from the headline. The first level that has an unambiguous story id
  // wins; if a level shows several different stories, it is a section wrapper
  // and must not be used.
  function storyIdFor(anchor) {
    let node = anchor;
    for (let depth = 0; node && depth < 8; depth++) {
      const fromJslog = storyIdFromJslog(node);
      if (fromJslog) return fromJslog;
      const ids = storyIdsFromLinks(node);
      if (ids.length === 1) return ids[0];
      if (ids.length > 1) return '';
      node = node.parentElement;
    }
    return '';
  }

  function selectedTabText() {
    const tab = document.querySelector(
      '[role="tab"][aria-selected="true"], [role="tab"][aria-selected="true"] *'
    );
    return cleanText(tab && tab.innerText);
  }

  function kindFromLabel(label) {
    const text = (label || '').toLowerCase();
    if (!text) return '';
    if (/for you|为你|為你|推荐|推薦/.test(text)) return 'foryou';
    if (/following|追踪|追蹤|关注|關注/.test(text)) return 'following';
    if (/^home$|首页|首頁/.test(text)) return 'home';
    return '';
  }

  function detectPage() {
    const path = location.pathname.replace(/\/+$/, '');
    const tabLabel = selectedTabText();
    const fromTab = kindFromLabel(tabLabel);
    if (fromTab) {
      return {
        kind: fromTab,
        label:
          tabLabel ||
          (fromTab === 'home' ? 'Home' : fromTab === 'foryou' ? 'For you' : 'Following'),
      };
    }
    if (/^\/foryou(\/|$)/.test(path)) return { kind: 'foryou', label: 'For you' };
    if (/^\/following(\/|$)/.test(path)) return { kind: 'following', label: 'Following' };
    if (path === '' || path === '/home') return { kind: 'home', label: 'Home' };
    return { kind: 'other', label: 'News' };
  }

  function parseAriaMeta(ariaLabel) {
    const meta = { source: '', time: '' };
    if (!ariaLabel) return meta;
    const parts = ariaLabel.split(/\s+-\s+/);
    const timeIndex = parts.findIndex((p) => TIME_RE.test(p.trim()));
    if (timeIndex > 0) {
      meta.time = parts[timeIndex].trim();
      meta.source = parts[timeIndex - 1].trim();
    }
    return meta;
  }

  function isHidden(a) {
    if (a.closest('[aria-hidden="true"]')) return true;
    const style = getComputedStyle(a);
    if (style.display === 'none' || style.visibility === 'hidden') return true;
    return a.offsetParent === null && style.position !== 'fixed';
  }

  const normTitle = (s) =>
    s
      .normalize('NFKC')
      .toLowerCase()
      .replace(/[‘’]/g, "'")
      .replace(/[“”]/g, '"')
      .replace(/[^\p{L}\p{N}]+/gu, ' ')
      .trim();

  const seenUrls = new Set();
  const seenTitles = new Set();
  const seenStories = new Set();
  const items = [];
  const stats = { candidates: 0, duplicates: 0, duplicatesByStory: 0, games: 0 };

  for (const a of document.querySelectorAll('a[href]')) {
    const href = a.getAttribute('href');
    if (!href) continue;

    const url = articleUrl(href);
    if (!url) {
      if (GAME_URL.test((href.split('?')[0] || '').toLowerCase())) stats.games++;
      continue;
    }
    stats.candidates++;

    if (isHidden(a)) continue;

    const title = cleanText(a.innerText || a.textContent);
    if (!title || title.length < 3 || UI_TEXT.test(title)) continue;

    const meta = parseAriaMeta(a.getAttribute('aria-label') || '');
    const storyId = storyIdFor(a);

    if (seenUrls.has(url)) {
      stats.duplicates++;
      continue;
    }
    const titleKey = normTitle(title);
    if (titleKey && seenTitles.has(titleKey)) {
      stats.duplicates++;
      continue;
    }
    if (storyId && seenStories.has(storyId)) {
      stats.duplicates++;
      stats.duplicatesByStory++;
      continue;
    }

    seenUrls.add(url);
    if (titleKey) seenTitles.add(titleKey);
    if (storyId) seenStories.add(storyId);

    items.push({ title, url, source: meta.source, time: meta.time, storyId });
  }

  const page = detectPage();

  return {
    items,
    pageKind: page.kind,
    pageLabel: page.label,
    pageUrl: location.href,
    pageTitle: document.title,
    stats,
  };
})();
