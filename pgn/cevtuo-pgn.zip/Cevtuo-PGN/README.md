# Cevtuo-PGN

一键抓取 Google News 当前页面上的文章链接。**首页（Home）和 For you 各自是一份独立清单**：分开抓取、分开勾选、分开删除、分开复制，不会混在一起。

已按 SmartURLs 的「复制为纯链接」思路实现：复制结果**每行只有一个链接**，不带标题、来源、时间。

## 已安装

这个扩展已经装进你的默认 Chrome（`Default` 配置，Jingwei 账号）：

- 打开 `chrome://extensions`，能看到 **Cevtuo-PGN 1.1.0**
- 工具栏里有蓝色列表图标「Cevtuo-PGN · Google News 链接」
- 如果图标没显示，点工具栏的拼图图标 → 把「Cevtuo-PGN」固定到工具栏

扩展是以「未打包」方式加载的，**源码目录不能删也不能移动**：
`/Users/cjw/Documents/Codex/google-news-link-grabber`

## 用法

1. 打开 Google News 的 **Home** 或 **For you** 页面（已登录状态）。
2. 点工具栏上的「Cevtuo-PGN」图标。
3. 弹窗会自动抓取当前页面，并显示标题、链接、来源和时间。
4. 顶部出现分页标签：
   - `首页 46`
   - `For you 30`
   点哪个就只显示哪一份清单。
5. **For you 数量**：标签下方有 `20 / 30 / 50` 三个选项，默认 **30**；按页面顺序取前 N 条（已删除的条目会自动由后面的补上）。
6. 操作：
   - 左侧复选框：取消勾选 = 这条不复制（可随时勾回来）
   - 右侧 `×`：从这份清单删除（底部「恢复删除」可找回）
   - 底部「复制已选链接」：把当前页选中项复制到剪贴板，**每行一个纯链接**
   - `全选 / 取消全选`
   - `↻`：重新抓取当前页面（会保留同一页的删除与勾选状态）
   - `⇣`：先自动向下滚动加载更多，再抓取
   - `⤢`：在大标签页里查看（列表更长、可搜索、复制同一个按钮）

首页和 For you 的删除、勾选互相独立：在 For you 删一条，首页仍是原来的数量。

## 抓取规则

- 只收 Google News 的文章链接：`/read/…`、`/articles/…`、`/rss/articles/…`
- 链接统一为 `https://news.google.com/read/<token>`，去掉 `?hl=&gl=&ceid=` 之类参数
- 自动去重：
  - 同一个文章 URL 只留一条
  - 标题规范化后相同（忽略大小写、标点、空格）只留一条
  - **同一新闻事件只留一条**：读取 Google News 卡片 `jslog` 里的 story cluster id（`channel_story_360:<id>`），同一 cluster 的多家媒体报道只保留页面顺序里的第一条；找不到 cluster id 时退回到最近的 `/stories/<id>` 链接
- 过滤游戏内容：`/games/`、`/puzzles/`、`puzzles.google.com`、单词/数独/填字等链接不会进入清单
- 跳过没有标题的缩略图链接、隐藏元素和纯 UI 链接
- 页面是 Google News 的 SPA，文章链接的 class 名是随机哈希，所以选择器基于 URL 形状和 `aria-label`，不依赖具体 class

## 数据保存

- 使用 `chrome.storage.local`，键为 `gnStore`
- 每个页面类型单独保存：`home` / `foryou` / `following` / `other`
- For you 的条数选择（20/30/50）也保存在同一个键里，重启浏览器后仍然生效
- 重新抓取时，只要链接还在，原来的删除和取消勾选状态会保留

## 文件结构

```
manifest.json     MV3 清单
extractor.js      注入 Google News 页面执行，返回文章列表和页面类型
app.js            弹窗与查看页共用的逻辑（清单、删除、复制、分页标签、条数）
popup.html        工具栏弹窗
viewer.html       大窗口查看页
styles.css        样式
icons/            16/32/48/128 图标
```

## 修改后如何生效

1. 改完代码保存。
2. 打开 `chrome://extensions`。
3. 在 Cevtuo-PGN 卡片上点「重新加载」。
4. 回到 Google News 页面，重新打开插件。

## 已知边界

- 只抓取当前已经渲染的内容；`⇣` 会滚动加载更多，但不会无限加载。
- 链接保留 Google News 的 `/read/` 形式，点开后会跳转到原始媒体页面。
- 只支持 `news.google.com` 页面。
