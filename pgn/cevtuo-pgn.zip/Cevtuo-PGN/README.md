# Cevtuo-PGN

一键抓取**任意新闻网站**当前页面上的文章链接。Google News、nytimes.com、ft.com、bbc.com、CNN、Guardian、Al Jazeera、SCMP、TechCrunch……都可以用同一个按钮。

复制结果**每行只有一个链接**，不带标题、来源、时间。

## 2.0.1 修复

- **Google News 下拉更耐心**：连续 **6 轮**没有新条目/新高度才停（原来 3 轮）。Google News 的下一屏经常在滚到底后几秒才出现，旧规则会在 22 条左右提前收工。现在会等它出现；真的到底了会提示“已到页面底部，共 N 条”。
- **原始链接解析修复**：新增 `tabs` 权限，并补上“活跃标签页是 Google News 就直接用它”的回退。之前即使勾了「原始链接」，也可能因为找不到 Google News 标签页而静默回退成 `news.google.com/read/…`。复制后的提示现在会明确写：全部是原文、部分解析失败、或原文解析失败的原因。
- 新增回归断言：Google News 延迟加载批次、全选数量、复制结果中不得残留 `news.google.com`。

## 2.0 新增

- **不再只认 Google News**：任意 http/https 新闻页面都能抓。
- **按站点分册**：Google News 的 Home / For you / Following 各自一册，每个新闻站点也各自一册，互不覆盖。
- **下拉选够**：`20 / 30 / 50 / 100` 条，或 `全部（拉到底）`。
- **拉到底并全选**：选「全部」后点一次按钮，自动滚动整页、合并每一屏、滚动结束后全选。
- **三层去重**：URL 规范化去重、标题规范化去重、Google News story cluster 去重。
- **清空可恢复**：`清空` 只是把条目放进「恢复删除」，不会真的丢链接。

## 已安装 / 重新加载

这个扩展已经以「未打包」方式装在默认 Chrome（`Default` 配置）里，源码目录不能删也不能移动：

`/Users/cjw/Documents/Codex/google-news-link-grabber`

改完代码后：

1. 打开 `chrome://extensions`。
2. 在 **Cevtuo-PGN 2.0.1** 卡片上点「重新加载」。
3. 回到任意新闻页面，重新打开插件。

2.0.1 需要读取 http/https 页面的权限（`host_permissions`）以及标签页 URL 的 `tabs` 权限，Chrome 可能会提示“读取和更改您在所有网站上的数据”和“读取您的浏览记录”。这两项分别用于：在任意新闻站点抓链接、在后台 Google News 标签页里解析原文地址。扩展只读取页面上的链接和 Google News 标签页，不上传、不请求文章正文。

## 用法

1. 打开任意新闻页面（首页、栏目页、搜索结果页都可以）。
2. 点工具栏上的「Cevtuo-PGN」图标。
3. 弹窗自动抓取当前页，并显示标题、链接、来源和时间。
4. 顶部标签按清单分页：
   - `GNews 首页`
   - `GNews For you`
   - `GNews Following`
   - `NYTimes` / `Financial Times` / `BBC`……（每个站点一册）
   点哪个就只显示哪一份清单。
5. **抓取数量**（标签下方）：
   - `20 / 30 / 50 / 100`：自动下拉，直到清单里**至少**有这么多条（滚动按屏推进，可能略多）。Google News 的 For you 会严格显示前 N 条；普通站点会保留已经收集到的全部条目。
   - `全部（拉到底）`：一直滚动到页面底部，直到连续 3 轮没有新条目、没有新高度，或到达 3 分钟 / 120 轮上限。
6. **`⇣ 抓取到 N 条` / `⇣ 拉到底并全选`**：
   - 数字模式：滚动加载到目标数量。
   - 全部模式：滚动到底后**自动全选**，可以直接复制。
   - 抓完会把页面滚回你原来的位置。
7. 操作：
   - 左侧复选框：取消勾选 = 这条不复制（可随时勾回来）
   - 右侧 `×`：从这份清单删除（底部「恢复删除」可找回）
   - 底部「复制已选链接」：把当前清单选中项复制到剪贴板，**每行一个纯链接**
   - `全选 / 取消全选`
   - `清空`：把当前清单全部放进「恢复删除」，可一键找回
   - `↻`：重新抓取当前页面（保留同一清单的删除与勾选状态）
   - `⤢`：在大标签页里查看（列表更长、可搜索、复制同一个按钮）
   - **原始链接**（仅 Google News 条目显示，默认开）：复制前把 `news.google.com/read/…` 解析成 BBC / Guardian 等媒体原文地址，再复制；成功解析的链接会写回列表并缓存，下次不再重复解析。

### 「下拉选够」适合什么情况

适合：首页/栏目页这种“一屏只渲染一部分、往下滚才继续加载”的信息流。它解决的是“我不想自己滚 20 屏再回来复制”。

不适合：一打开就是完整列表的页面（例如某些搜索结果页）。这种情况下抓一轮就已经全了，下拉会在连续 3 轮没有新内容后自动停，不会无限跑。

注意：少数网站是无限信息流（永远滚不到底）。「全部」模式最多跑 3 分钟 / 120 轮，到点就停并保留已经抓到的内容，不会把页面卡死。

## 普通新闻站点是怎么抓的

不依赖任何站点固定的 class 名（新闻站改版很频繁），而是看链接本身和它所在的位置：

- **URL 形状加分**：日期路径（`/2026/11/03/`、`/2026-11-03/`、`/2026/nov/03/`）、文章段（`/article/`、`/story/`、`/content/`、`/read/`、`/posts/` 等）、长 slug、数字 ID、`.html` 后缀。
- **标题加分**：标题来自 `h1`–`h4` 优先，其次是链接文本、`aria-label`、`title`、图片 `alt`；标题太短或只是导航词（Home / Business / Subscribe / Search…）会被排除。
- **位置加减分**：`<article>` / `<main>` 内加分；`<nav>`、页头、页脚、面包屑、分页、分享栏、订阅推广、广告位减分。
- **已知站点档案**：NYTimes、FT、WSJ、Bloomberg、Reuters、AP、Guardian、BBC、Washington Post、CNN、CNBC、Al Jazeera、Economist、SCMP、Nikkei、Straits Times、澎湃、财新、36Kr、TechCrunch、The Verge、Wired……用 URL 形状额外加分；站点改版时仍然回退到通用规则。
- **排除**：社交分享（X/Twitter、Facebook、LinkedIn、WhatsApp、Telegram…）、登录/注册/订阅/搜索/标签/作者页、视频/播客/图库列表、广告与追踪域名。
- **URL 规范化**：去掉 `utm_*`、`fbclid`、`gclid`、`smid`、`update`、`amp` 等追踪/分页参数和 `#hash`，统一末尾斜杠。参数里可能是文章 ID 的（例如 `?id=123`）会保留。

### 去重规则（三层）

1. **URL**：规范化后完全相同只留一条。
2. **标题**：忽略大小写、标点、空格后相同只留一条（同一新闻被不同卡片、图片链接、Load more 重复渲染时只剩一条）。
3. **Google News story cluster**：读取卡片 `jslog` 里的 `channel_story_360:<id>`（或附近 `/stories/<id>`），同一事件的多家媒体报道只留页面顺序里的第一条。

普通站点同一事件的不同标题（例如“Fed signals cuts”和“Fed holds rates”）不会被强行合并——那需要跨站语义聚类，误杀风险比收益高。

## Google News 的原始链接

Google News 的 `/read/<token>` 是带签名的跳转页，光有 token 解不开。插件会：

1. 在**已打开的 Google News 页面里**读取该文章的 `data-n-a-sg` / `data-n-a-ts`（同源请求，避免被 Google 以 400 拒绝）；
2. 调 Google 自己的 `batchexecute`（`Fbv4je`）拿到媒体原文 URL；
3. 按 token 缓存在本地（最多 600 条），之后复制不再请求。

因此解析需要**至少开着一个 Google News 标签页**；失败的条目会保留 Google News 链接，状态栏会显示原因。首次解析 30 条大约要十几秒，之后走缓存是瞬时的。普通站点的链接本来就是原文地址，不需要解析，底部的「原始链接」开关会自动隐藏。

## 数据保存

- 使用 `chrome.storage.local`，键为 `pgnStore`（首次运行会自动读取旧的 `gnStore`）。
- 每个清单单独保存：Google News 为 `home` / `foryou` / `following` / `other`，普通站点为 `site:<域名>`。
- 普通站点的 `site:<域名>` 清单会**累积**：今天抓 NYTimes 首页、明天抓 NYTimes 商业版，新条目会合并进来，重复自动去掉。想重新开始点「清空」。
- 抓取数量、勾选/删除状态、Google News 解析缓存都保存在本地；重启浏览器后仍然生效。

## 文件结构

```
manifest.json        MV3 清单（2.0.1：http/https 全站 host_permissions + tabs）
core.js              共享规则：URL 规范化、站点档案、标题/故事去重
extractor.js         注入页面执行：Google News 模式 + 通用新闻站点模式
app.js               弹窗与查看页共用的逻辑（清单、抓取、下拉、复制、分页标签）
popup.html           工具栏弹窗
viewer.html          大窗口查看页
styles.css           样式
verify/index.html    浏览器内自检页（模拟 NYTimes / FT / 无限滚动）
tests/               无头测试与模拟页面
icons/               16/32/48/128 图标
```

## 自检

无头测试（需要本机有 Playwright；脚本会先找常规安装，再找本机现有的 Playwright）：

```bash
cd /Users/cjw/Documents/Codex/google-news-link-grabber
node tests/extract-test.mjs   # 抓取规则、去重、Google News 回归
node tests/ui-test.mjs        # 弹窗：下拉、全选、清空、恢复、延迟批次、原文链接
```

当前结果：`extract-test` **31 项全过**；`ui-test` **22 项全过**（其中 6 项专门覆盖 Google News 延迟批次与原文链接复制）。Google News 的登录态页面无法在无头浏览器里直接复现，所以这两类回归用「真实页面探针 + 确定性 chrome.* 桩」组合验证。

浏览器自检页：

```bash
cd /Users/cjw/Documents/Codex/google-news-link-grabber
python3 -m http.server 8133 --bind 127.0.0.1
# 打开 http://127.0.0.1:8133/verify/
```

自检页会在三个 iframe 里真实运行 `core.js` + `extractor.js`，核对：

- NYTimes 模拟页：6 条；导航/分类/搜索/分享都不进清单；重复标题只留一条。
- FT 模拟页：3 条；只保留 `/content/<uuid>`；`utm_source` 被剥掉。
- 无限滚动模拟页：初始 6 条；Load more + 滚到底后合并为 10 条；同一 URL / 同一标题各只留一条。

## 已知边界

- **付费墙网站**（FT、WSJ 等）：链接能抓，正文不抓；能否打开取决于你的登录状态。
- **反爬/机器人验证**：扩展跑在你自己已登录的 Chrome 里；用无头浏览器直接访问 NYTimes/FT 可能拿到 403，这不代表扩展不行。
- **懒加载在 Tab / 轮播里的内容**：页面滚动不会触发隐藏 Tab 里的加载；先手动切到那个 Tab 再抓。
- **无限信息流**：永远滚不到底的站点会在 3 分钟 / 120 轮后停止，保留已抓内容。
- **话题聚合页**偶尔会被当成一条链接（例如 Al Jazeera 的 “US Midterm Elections 2026”）。它确实是一个可用的新闻入口；不想要就点 `×` 删掉。
- **同一事件的不同标题**（普通站点）不合并；只合并同一 URL、同一规范化标题、同一 Google story cluster。
